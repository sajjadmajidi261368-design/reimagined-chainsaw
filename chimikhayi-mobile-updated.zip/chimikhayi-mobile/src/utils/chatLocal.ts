import AsyncStorage from '@react-native-async-storage/async-storage';

/**
 * Local (on-device) chat state:
 *  - drafts: a conversation the user opened (e.g. after sending an offer) but hasn't written to yet,
 *    plus any unsent text. They show up in the Messages list as "پیش‌نویس".
 *  - hidden: conversations the user deleted. The server has no delete endpoint, so deleting hides the
 *    messages up to a point in time on this device; newer messages bring the conversation back.
 * Everything is scoped per user id so accounts on the same phone never see each other's data.
 */
export type DraftThread = {
  key: string;
  requestId: string | number;
  peerId: string | number;
  peerName: string;
  requestTitle: string;
  peerAvatar?: string;
  text: string;
  /** true when the thread only exists locally (no message has been sent yet). */
  local: boolean;
  updatedAt: number;
};

export type ThreadRef = Pick<DraftThread, 'requestId' | 'peerId' | 'peerName' | 'requestTitle' | 'peerAvatar'>;

const DRAFTS_PREFIX = 'chimikhayi.chat.drafts.';
const HIDDEN_PREFIX = 'chimikhayi.chat.hidden.';

export const threadKey = (requestId: string | number, peerId: string | number) => `${requestId}:${peerId}`;

async function readJson<T>(key: string, fallback: T): Promise<T> {
  try {
    const raw = await AsyncStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}
async function writeJson(key: string, value: unknown): Promise<void> {
  try {
    await AsyncStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Local convenience data only; failing to persist must never break chatting.
  }
}

export async function loadDrafts(userId: string | number): Promise<Record<string, DraftThread>> {
  return readJson<Record<string, DraftThread>>(`${DRAFTS_PREFIX}${userId}`, {});
}
async function saveDrafts(userId: string | number, drafts: Record<string, DraftThread>) {
  await writeJson(`${DRAFTS_PREFIX}${userId}`, drafts);
}

/** Registers a conversation that has no message yet so it appears in Messages as a draft. */
export async function registerDraftThread(userId: string | number, thread: ThreadRef): Promise<void> {
  const drafts = await loadDrafts(userId);
  const key = threadKey(thread.requestId, thread.peerId);
  const existing = drafts[key];
  drafts[key] = { ...thread, key, text: existing?.text ?? '', local: existing?.local ?? true, updatedAt: Date.now() };
  await saveDrafts(userId, drafts);
}

export async function getDraftText(userId: string | number, requestId: string | number, peerId: string | number): Promise<string> {
  const drafts = await loadDrafts(userId);
  return drafts[threadKey(requestId, peerId)]?.text ?? '';
}

/** Saves unsent text. Empty text on a non-local thread removes the entry; on a local thread it keeps the placeholder. */
export async function saveDraftText(userId: string | number, thread: ThreadRef, text: string): Promise<void> {
  const drafts = await loadDrafts(userId);
  const key = threadKey(thread.requestId, thread.peerId);
  const existing = drafts[key];
  if (!text.trim()) {
    if (!existing) return;
    if (existing.local) drafts[key] = { ...existing, text: '', updatedAt: Date.now() };
    else delete drafts[key];
  } else {
    drafts[key] = { ...thread, key, text, local: existing?.local ?? false, updatedAt: Date.now() };
  }
  await saveDrafts(userId, drafts);
}

/** Called after a message was really sent: the server now owns the thread. */
export async function removeDraft(userId: string | number, requestId: string | number, peerId: string | number): Promise<void> {
  const drafts = await loadDrafts(userId);
  const key = threadKey(requestId, peerId);
  if (!drafts[key]) return;
  delete drafts[key];
  await saveDrafts(userId, drafts);
}

export async function loadHidden(userId: string | number): Promise<Record<string, number>> {
  return readJson<Record<string, number>>(`${HIDDEN_PREFIX}${userId}`, {});
}

/** Hides every message up to `upTo` (epoch ms) of this conversation on this device and drops its draft. */
export async function hideThread(userId: string | number, requestId: string | number, peerId: string | number, upTo: number): Promise<void> {
  const key = threadKey(requestId, peerId);
  const hidden = await loadHidden(userId);
  hidden[key] = Math.max(hidden[key] ?? 0, upTo);
  await writeJson(`${HIDDEN_PREFIX}${userId}`, hidden);
  await removeDraft(userId, requestId, peerId);
}

export async function getHiddenUpTo(userId: string | number, requestId: string | number, peerId: string | number): Promise<number> {
  const hidden = await loadHidden(userId);
  return hidden[threadKey(requestId, peerId)] ?? 0;
}
