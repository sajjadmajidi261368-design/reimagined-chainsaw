import AsyncStorage from '@react-native-async-storage/async-storage';
import type { User } from '../store/authStore';

/**
 * Trust levels are built from verification steps:
 *   0  registered (mobile verified by OTP)      -> 1 star
 *   1  identity: national code + ID card photo  -> 2 stars
 *   2  face check: selfie holding the ID card   -> 3 stars
 *   3  business: company info + documents       -> 4 stars
 *   4  approved by the Chimikhayi team          -> 5 stars
 *
 * Steps 1-3 are tracked from what the user submitted (stored locally and inferred from
 * the profile fields the server already returns). Step 4 comes from the server flag
 * (`is_verified` / `verified` / `level`), because only the team can approve documents.
 */
export type KycStepId = 'identity' | 'selfie' | 'business';
export type KycProgress = { identity: boolean; selfie: boolean; business: boolean; submittedAt?: string };

export type TrustStep = { id: 'registered' | KycStepId | 'approved'; title: string; hint: string; points: number; done: boolean };
export type TrustSummary = {
  score: number;
  stars: number;
  level: number;
  levelLabel: string;
  nextHint: string | null;
  approved: boolean;
  steps: TrustStep[];
};

const STORAGE_PREFIX = 'chimikhayi.kyc.progress.';

export function emptyProgress(): KycProgress {
  return { identity: false, selfie: false, business: false };
}

export async function loadKycProgress(userId: string | number): Promise<KycProgress> {
  try {
    const raw = await AsyncStorage.getItem(`${STORAGE_PREFIX}${userId}`);
    if (!raw) return emptyProgress();
    const parsed = JSON.parse(raw) as Partial<KycProgress>;
    return {
      identity: parsed.identity === true,
      selfie: parsed.selfie === true,
      business: parsed.business === true,
      submittedAt: typeof parsed.submittedAt === 'string' ? parsed.submittedAt : undefined,
    };
  } catch {
    return emptyProgress();
  }
}

export async function saveKycProgress(userId: string | number, progress: KycProgress): Promise<void> {
  try {
    await AsyncStorage.setItem(`${STORAGE_PREFIX}${userId}`, JSON.stringify(progress));
  } catch {
    // Progress is a convenience cache; the server stays the source of truth.
  }
}

export function isServerVerified(user: User): boolean {
  const flag = user.is_verified ?? user.verified;
  if (flag === true || flag === 1 || flag === '1') return true;
  if (flag === false || flag === 0 || flag === '0') return false;
  return Boolean(user.level && user.level.toLowerCase() !== 'bronze');
}

/** Validates the Iranian national code (کد ملی) including its check digit. */
export function isValidNationalCode(code: string): boolean {
  if (!/^\d{10}$/.test(code)) return false;
  if (/^(\d)\1{9}$/.test(code)) return false;
  let sum = 0;
  for (let i = 0; i < 9; i += 1) sum += Number(code[i]) * (10 - i);
  const remainder = sum % 11;
  const check = Number(code[9]);
  return remainder < 2 ? check === remainder : check === 11 - remainder;
}

const LEVEL_LABELS = ['ثبت‌نام‌شده', 'هویت پایه', 'هویت تصدیق‌شده', 'کسب‌وکار ثبت‌شده', 'تأییدشده توسط چی میخوای'];

export function computeTrust(user: User | null, stored: KycProgress): TrustSummary {
  // Profile fields returned by the server prove earlier submissions made before levels existed.
  const hasLegacyIdentity = Boolean(user?.national_id && String(user.national_id).trim());
  const hasLegacyBusiness = Boolean(user?.company_name && user.landline && user.address);
  const approved = user ? isServerVerified(user) : false;

  const identity = stored.identity || hasLegacyIdentity || approved;
  const selfie = stored.selfie || approved;
  const business = stored.business || hasLegacyBusiness || approved;

  const steps: TrustStep[] = [
    { id: 'registered', title: 'ثبت‌نام و تأیید شماره', hint: 'شمارهٔ همراه شما با کد یک‌بارمصرف تأیید شده است.', points: 20, done: Boolean(user) },
    { id: 'identity', title: 'هویت فردی', hint: 'نام کامل، کد ملی و تصویر کارت ملی', points: 20, done: identity },
    { id: 'selfie', title: 'تأیید چهره', hint: 'عکس سلفی همراه با کارت ملی', points: 15, done: selfie },
    { id: 'business', title: 'اطلاعات کسب‌وکار', hint: 'نام شرکت، تلفن ثابت، نشانی و مدرک فعالیت', points: 25, done: business },
    { id: 'approved', title: 'تأیید نهایی', hint: 'پس از بررسی مدارک توسط تیم چی میخوای فعال می‌شود.', points: 20, done: approved },
  ];

  const score = steps.reduce((sum, step) => sum + (step.done ? step.points : 0), 0);
  const level = approved ? 4 : business ? 3 : selfie ? 2 : identity ? 1 : 0;
  const stars = level + 1;

  let nextHint: string | null = null;
  if (!identity) nextHint = 'با ثبت کد ملی و تصویر کارت ملی به سطح «هویت پایه» برسید.';
  else if (!selfie) nextHint = 'یک سلفی همراه کارت ملی بفرستید تا ستارهٔ سوم فعال شود.';
  else if (!business) nextHint = 'اطلاعات و مدرک کسب‌وکار را کامل کنید تا ستارهٔ چهارم فعال شود.';
  else if (!approved) nextHint = 'مدارک شما در انتظار تأیید نهایی است؛ پس از بررسی، ستارهٔ پنجم فعال می‌شود.';

  return { score, stars, level, levelLabel: LEVEL_LABELS[level], nextHint, approved, steps };
}
