import type { User } from '../store/authStore';

/** ترخیص‌کار همان تأمین‌کننده است؛ فقط برچسب متفاوت دارد. */
export function isSupplierSide(user?: Pick<User, 'role' | 'is_broker'> | null): boolean {
  if (!user) return false;
  if (user.role === 'supplier' || user.role === 'broker') return true;
  return user.is_broker === 1 || user.is_broker === true || user.is_broker === '1';
}

export function isBuyer(user?: Pick<User, 'role'> | null): boolean {
  return user?.role === 'buyer';
}

export function roleLabel(user?: Pick<User, 'role' | 'is_broker'> | null): string {
  if (!user) return '';
  if (user.role === 'buyer') return 'خریدار';
  if (user.role === 'broker' || user.is_broker === 1 || user.is_broker === true || user.is_broker === '1') return 'ترخیص‌کار';
  return 'تأمین‌کننده';
}
