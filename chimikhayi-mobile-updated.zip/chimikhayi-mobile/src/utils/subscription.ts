import type { User } from '../store/authStore';

export type SubscriptionInfo = {
  /** true when the account has an active paid subscription (or is a buyer, who never pays). */
  active: boolean;
  /** Short value for the stats row: «فعال» / «غیرفعال» / «رایگان». */
  label: string;
  /** Optional extra line: plan name or expiry date. */
  detail?: string;
};

const TRUE_WORDS = new Set(['1', 'true', 'yes', 'active', 'paid', 'premium', 'فعال']);

function truthy(value: unknown): boolean {
  if (value === true || value === 1) return true;
  return typeof value === 'string' && TRUE_WORDS.has(value.trim().toLowerCase());
}

function firstDefined(record: Record<string, unknown>, keys: string[]): unknown {
  for (const key of keys) if (record[key] !== undefined && record[key] !== null && record[key] !== '') return record[key];
  return undefined;
}

/**
 * The profile endpoint's subscription field names aren't documented, so several likely spellings are
 * read. If none is present the supplier is treated as having no active subscription.
 */
export function subscriptionInfo(user: User): SubscriptionInfo {
  if (user.role === 'buyer') return { active: true, label: 'رایگان', detail: 'ثبت درخواست برای خریداران رایگان است' };

  const record = user as unknown as Record<string, unknown>;
  const flag = firstDefined(record, ['subscription_active', 'has_subscription', 'is_subscribed', 'is_premium', 'is_paid', 'subscribed']);
  const status = firstDefined(record, ['subscription_status', 'sub_status', 'plan_status']);
  const expiryRaw = firstDefined(record, ['subscription_expires_at', 'subscription_expires', 'subscription_end', 'subscription_expiry', 'premium_until', 'plan_expires_at', 'expires_at']);
  const plan = firstDefined(record, ['plan_name', 'subscription_plan', 'plan']);

  let expiry: Date | null = null;
  if (typeof expiryRaw === 'string' || typeof expiryRaw === 'number') {
    const parsed = new Date(typeof expiryRaw === 'string' ? expiryRaw.replace(' ', 'T') : Number(expiryRaw) * (Number(expiryRaw) < 1e12 ? 1000 : 1));
    if (!Number.isNaN(parsed.getTime())) expiry = parsed;
  }

  let active = false;
  if (flag !== undefined) active = truthy(flag);
  else if (status !== undefined) active = truthy(status);
  else if (expiry) active = expiry.getTime() > Date.now();

  // An explicit expiry in the past always wins over a stale "active" flag.
  if (expiry && expiry.getTime() <= Date.now()) active = false;

  const details: string[] = [];
  if (plan !== undefined && String(plan).trim()) details.push(String(plan).trim());
  if (expiry) details.push(`${active ? 'تا' : 'منقضی در'} ${expiry.toLocaleDateString('fa-IR')}`);
  return { active, label: active ? 'فعال' : 'غیرفعال', detail: details.length ? details.join(' · ') : undefined };
}
