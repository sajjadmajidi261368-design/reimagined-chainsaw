/**
 * The PHP API wraps lists in different envelopes (`data`, `items`, `requests`, ...).
 * Walks the response breadth-first and returns the first array it finds.
 */
export function extractArray<T>(value: unknown, arrayKeys: string[]): T[] {
  const queue: unknown[] = [value];
  const visited = new Set<object>();
  while (queue.length) {
    const current = queue.shift();
    if (Array.isArray(current)) return current as T[];
    if (!current || typeof current !== 'object' || visited.has(current)) continue;
    visited.add(current);
    const record = current as Record<string, unknown>;
    for (const key of arrayKeys) if (Array.isArray(record[key])) return record[key] as T[];
    for (const key of ['data', 'result', 'payload', 'response', 'request', 'offers']) {
      const nested = record[key];
      if (nested && typeof nested === 'object') queue.push(nested);
    }
  }
  return [];
}

export function findNumber(value: unknown, field: string): number | undefined {
  const queue: unknown[] = [value];
  const visited = new Set<object>();
  while (queue.length) {
    const current = queue.shift();
    if (!current || typeof current !== 'object' || Array.isArray(current) || visited.has(current)) continue;
    visited.add(current);
    const record = current as Record<string, unknown>;
    if (record[field] !== undefined) {
      const parsed = Number(record[field]);
      if (Number.isFinite(parsed)) return parsed;
    }
    for (const key of ['data', 'result', 'payload', 'response']) if (record[key] && typeof record[key] === 'object') queue.push(record[key]);
  }
  return undefined;
}
