import React, { useState } from 'react';
import { ActivityIndicator, Alert, Image, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import * as DocumentPicker from 'expo-document-picker';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ApiError, api } from '../api/api';
import { mediaUrl } from '../api/media';
import type { DashboardStackParamList } from '../navigation/DashboardStackNavigator';
import { useAuthStore } from '../store/authStore';
import { COLORS } from '../theme/colors';

type Props = NativeStackScreenProps<DashboardStackParamList, 'ProfileEdit'>;

export function ProfileEditScreen({ navigation }: Props) {
  const user = useAuthStore((state) => state.user);
  const updateUser = useAuthStore((state) => state.updateUser);
  const [name, setName] = useState(user?.name ?? '');
  const [avatarAsset, setAvatarAsset] = useState<DocumentPicker.DocumentPickerAsset | null>(null);
  const [busy, setBusy] = useState(false);

  if (!user) return <SafeAreaView style={styles.safeArea} />;
  const savedAvatar = mediaUrl(user.avatar_url ?? user.avatar);
  const preview = avatarAsset?.uri ?? savedAvatar;
  const roleLabel = user.role === 'buyer' ? 'خریدار' : user.role === 'broker' ? 'ترخیص‌کار' : 'تأمین‌کننده';

  const pickAvatar = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({ type: 'image/*', multiple: false, copyToCacheDirectory: true });
      if (!result.canceled && result.assets[0]) {
        const asset = result.assets[0];
        if (asset.size && asset.size > 3 * 1024 * 1024) {
          Alert.alert('حجم تصویر زیاد است', 'تصویر باید کمتر از ۳ مگابایت باشد.');
          return;
        }
        setAvatarAsset(asset);
      }
    } catch {
      Alert.alert('انتخاب تصویر انجام نشد', 'لطفاً دوباره تلاش کنید.');
    }
  };

  const save = async () => {
    const cleanName = name.trim();
    if (cleanName.length < 2) return Alert.alert('نام معتبر نیست', 'نام باید دست‌کم دو نویسه باشد.');
    setBusy(true);
    try {
      const profileResult = await api.updateProfile({ name: cleanName });
      let nextAvatar = user.avatar_url ?? user.avatar ?? null;
      if (avatarAsset) {
        const formData = new FormData();
        const file = {
          uri: avatarAsset.uri,
          name: avatarAsset.name || 'avatar.jpg',
          type: avatarAsset.mimeType || 'image/jpeg',
        } as unknown as Blob;
        formData.append('avatar', file);
        const avatarResult = await api.uploadAvatar(formData);
        nextAvatar = avatarResult.user?.avatar_url ?? avatarResult.avatar_url ?? nextAvatar;
      }
      updateUser({ ...(profileResult.user ?? {}), name: profileResult.user?.name ?? profileResult.name ?? cleanName, avatar_url: nextAvatar });
      Alert.alert('پروفایل ذخیره شد', 'تغییرات پروفایل با موفقیت ثبت شد.', [{ text: 'باشه', onPress: () => navigation.goBack() }]);
    } catch (error) {
      Alert.alert('ذخیره انجام نشد', error instanceof ApiError ? error.message : 'لطفاً اتصال را بررسی و دوباره تلاش کنید.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} style={styles.headerButton} accessibilityLabel="بازگشت"><MaterialCommunityIcons name="arrow-right" size={22} color={COLORS.text} /></Pressable>
        <Text style={styles.headerTitle}>ویرایش پروفایل</Text>
        <View style={styles.headerButton} />
      </View>
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          <View style={styles.hero}>
            {preview ? <Image source={{ uri: preview }} style={styles.avatar} /> : <View style={styles.avatarFallback}><Text style={styles.avatarInitial}>{(name || '؟')[0]}</Text></View>}
            <Pressable onPress={() => void pickAvatar()} style={styles.avatarButton}><MaterialCommunityIcons name="camera-outline" size={16} color={COLORS.primaryDark} /><Text style={styles.avatarButtonText}>{avatarAsset ? 'تصویر انتخاب شد · تغییر' : 'تغییر تصویر'}</Text></Pressable>
          </View>
          <View style={styles.card}>
            <Text style={styles.label}>نام / نام شرکت</Text>
            <TextInput value={name} onChangeText={setName} placeholder="نام نمایشی شما" placeholderTextColor="#A8A29E" textAlign="right" style={styles.input} maxLength={120} returnKeyType="done" />
            <Text style={styles.label}>شمارهٔ همراه</Text>
            <View style={styles.readOnly}><Text style={styles.readOnlyText}>{user.mobile}</Text><MaterialCommunityIcons name="lock-outline" size={16} color={COLORS.muted} /></View>
            <Text style={styles.label}>نقش حساب</Text>
            <View style={styles.readOnly}><Text style={styles.readOnlyText}>{roleLabel}</Text><MaterialCommunityIcons name="lock-outline" size={16} color={COLORS.muted} /></View>
          </View>
          <View style={styles.note}><MaterialCommunityIcons name="information-outline" size={17} color={COLORS.primaryDark} /><Text style={styles.noteText}>شمارهٔ همراه و نقش حساب طبق قوانین حساب کاربری تغییرپذیر نیستند. ویرایش پروفایل با endpointهای فعال سایت شامل نام و تصویر پروفایل است.</Text></View>
        </ScrollView>
        <View style={styles.footer}><Pressable disabled={busy} onPress={() => void save()} style={({ pressed }) => [styles.saveButton, pressed && { opacity: 0.86 }, busy && styles.disabled]}>{busy ? <ActivityIndicator color="#fff" /> : <><MaterialCommunityIcons name="content-save-outline" size={18} color="#fff" /><Text style={styles.saveText}>ذخیرهٔ تغییرات</Text></>}</Pressable></View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.background },
  flex: { flex: 1 },
  header: { minHeight: 56, paddingHorizontal: 17, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: '#EEEAE1' },
  headerButton: { width: 38, height: 38, borderRadius: 13, backgroundColor: '#fff', borderWidth: 1, borderColor: COLORS.border, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { fontFamily: 'VazirmatnBold', fontSize: 14, color: COLORS.text },
  content: { padding: 17, paddingBottom: 24 },
  hero: { alignItems: 'center', paddingVertical: 18, backgroundColor: '#211B10', borderRadius: 20, marginBottom: 13 },
  avatar: { width: 88, height: 88, borderRadius: 30, backgroundColor: '#F4E9C9' },
  avatarFallback: { width: 88, height: 88, borderRadius: 30, backgroundColor: '#F4E9C9', alignItems: 'center', justifyContent: 'center' },
  avatarInitial: { fontFamily: 'VazirmatnBold', fontSize: 32, color: COLORS.primaryDark },
  avatarButton: { flexDirection: 'row-reverse', alignItems: 'center', gap: 6, marginTop: 11, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 12, backgroundColor: '#F4E9C9' },
  avatarButtonText: { fontFamily: 'VazirmatnBold', fontSize: 9, color: COLORS.primaryDark },
  card: { padding: 16, backgroundColor: '#fff', borderRadius: 18, borderWidth: 1, borderColor: '#EAE6DC' },
  label: { fontFamily: 'VazirmatnMedium', fontSize: 11, color: COLORS.text, textAlign: 'right', marginBottom: 6, marginTop: 8 },
  input: { minHeight: 45, fontFamily: 'Vazirmatn', fontSize: 11, color: COLORS.text, backgroundColor: COLORS.background, borderWidth: 1, borderColor: COLORS.border, borderRadius: 12, paddingHorizontal: 11, paddingVertical: 10 },
  readOnly: { minHeight: 43, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', borderWidth: 1, borderColor: '#E7E5E4', borderRadius: 12, backgroundColor: '#F5F5F4', paddingHorizontal: 11 },
  readOnlyText: { fontFamily: 'Vazirmatn', fontSize: 11, color: COLORS.muted, textAlign: 'right' },
  note: { flexDirection: 'row-reverse', gap: 7, alignItems: 'flex-start', padding: 12, borderRadius: 13, backgroundColor: '#FFFBEB', borderWidth: 1, borderColor: '#F4E9C9', marginTop: 12 },
  noteText: { flex: 1, fontFamily: 'Vazirmatn', fontSize: 9, lineHeight: 17, color: '#78350F', textAlign: 'right' },
  footer: { paddingHorizontal: 17, paddingVertical: 10, borderTopWidth: 1, borderTopColor: COLORS.border, backgroundColor: 'rgba(250,250,249,0.98)' },
  saveButton: { minHeight: 49, flexDirection: 'row-reverse', justifyContent: 'center', alignItems: 'center', gap: 7, borderRadius: 14, backgroundColor: COLORS.primaryDark },
  saveText: { fontFamily: 'VazirmatnBold', fontSize: 12, color: '#fff' },
  disabled: { opacity: 0.65 },
});
