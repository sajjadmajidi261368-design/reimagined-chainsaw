import React, { useState } from 'react';
import { ActivityIndicator, Alert, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ApiError } from '../api/api';
import { RootStackParamList } from '../navigation/RootNavigator';
import { UserRole, useAuthStore } from '../store/authStore';
import { COLORS } from '../theme/colors';

type Props = NativeStackScreenProps<RootStackParamList, 'Register'>;
const roles: { id: UserRole; label: string }[] = [
  { id: 'buyer', label: 'خریدار' },
  { id: 'supplier', label: 'تأمین‌کننده' },
  { id: 'broker', label: 'ترخیص‌کار' },
];
const digitsOnly = (value: string) => value.replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d))).replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));

export function RegisterScreen({ navigation }: Props) {
  const register = useAuthStore((s) => s.register);
  const busy = useAuthStore((s) => s.busy);
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<UserRole>('buyer');

  const onRegister = async () => {
    const normalizedMobile = digitsOnly(mobile).replace(/[\s-]/g, '');
    if (name.trim().length < 2) return Alert.alert('نام معتبر نیست', 'نام و نام خانوادگی را وارد کنید.');
    if (!/^0?9\d{9}$/.test(normalizedMobile)) return Alert.alert('شماره معتبر نیست', 'شماره موبایل را به‌صورت ۰۹۱۲۱۲۳۴۵۶۷ وارد کنید.');
    if (password.length < 6) return Alert.alert('رمز عبور کوتاه است', 'رمز عبور باید حداقل ۶ کاراکتر باشد.');
    try {
      // ترخیص‌کار = تأمین‌کننده؛ بک‌اند اغلب role=broker را قبول نمی‌کند و OTP ارسال نمی‌شود.
      const apiRole = role === 'broker' ? 'supplier' : role;
      await register({ name: name.trim(), mobile: normalizedMobile, password, role: apiRole, is_broker: role === 'broker' ? 1 : 0 });
      navigation.replace('Otp', { mobile: normalizedMobile });
    } catch (error) {
      Alert.alert('ثبت‌نام ناموفق', error instanceof ApiError ? error.message : 'لطفاً دوباره تلاش کنید.');
    }
  };

  return (
    <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
        <Pressable onPress={() => navigation.goBack()}><Text style={styles.back}>بازگشت ←</Text></Pressable>
        <View style={styles.headingRow}><View style={styles.goldDot} /><View style={styles.headingCopy}><Text style={styles.title}>حساب تازه، فرصت‌های تازه</Text><Text style={styles.subtitle}>برای ورود به بازار چی میخوای؟ ثبت‌نام کنید</Text></View></View>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>اطلاعات حساب</Text>
          <Text style={styles.label}>نام و نام خانوادگی</Text>
          <TextInput value={name} onChangeText={setName} placeholder="نام شما" placeholderTextColor="#A8A29E" textAlign="right" style={styles.input} autoComplete="name" returnKeyType="next" />
          <Text style={styles.label}>شماره موبایل</Text>
          <TextInput value={mobile} onChangeText={setMobile} placeholder="مثلاً ۰۹۱۲۱۲۳۴۵۶۷" placeholderTextColor="#A8A29E" keyboardType="phone-pad" textAlign="right" style={styles.input} autoComplete="tel" maxLength={14} />
          <Text style={styles.label}>رمز عبور</Text>
          <TextInput value={password} onChangeText={setPassword} placeholder="حداقل ۶ کاراکتر" placeholderTextColor="#A8A29E" secureTextEntry textAlign="right" style={styles.input} autoComplete="new-password" />
          <Text style={styles.label}>نوع حساب کاربری</Text>
          <View style={styles.roles}>
            {roles.map((item) => <Pressable key={item.id} accessibilityRole="radio" accessibilityState={{ selected: role === item.id }} onPress={() => setRole(item.id)} style={[styles.role, role === item.id && styles.roleSelected]}><Text style={[styles.roleText, role === item.id && styles.roleTextSelected]}>{item.label}</Text></Pressable>)}
          </View>
          <Pressable onPress={onRegister} disabled={busy} style={({ pressed }) => [styles.button, pressed && styles.pressed, busy && styles.disabled]}>
            {busy ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>ارسال کد تأیید</Text>}
          </Pressable>
          <Text style={styles.note}>با ادامه، کد تأیید به شماره موبایل شما ارسال می‌شود.</Text>
        </View>
        <View style={styles.secureRow}><Text style={styles.secure}>اطلاعات شما با اتصال امن ارسال می‌شود</Text><Text style={styles.secureIcon}>◆</Text></View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: COLORS.background },
  container: { flexGrow: 1, paddingHorizontal: 22, paddingTop: 20, paddingBottom: 30 },
  back: { fontFamily: 'VazirmatnMedium', color: COLORS.primaryDark, fontSize: 14, textAlign: 'left', marginBottom: 18 },
  headingRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 12, marginBottom: 22 },
  goldDot: { width: 8, height: 45, borderRadius: 5, backgroundColor: COLORS.primary },
  headingCopy: { flex: 1 },
  title: { fontFamily: 'VazirmatnBold', fontSize: 21, textAlign: 'right', color: COLORS.text },
  subtitle: { fontFamily: 'Vazirmatn', fontSize: 12, textAlign: 'right', color: COLORS.muted, marginTop: 3 },
  card: { backgroundColor: COLORS.surface, borderRadius: 22, borderWidth: 1, borderColor: '#E7E2D6', padding: 20, shadowColor: '#1C1917', shadowOpacity: 0.07, shadowRadius: 18, shadowOffset: { width: 0, height: 9 }, elevation: 3 },
  cardTitle: { fontFamily: 'VazirmatnBold', fontSize: 16, color: COLORS.text, textAlign: 'right', marginBottom: 16 },
  label: { fontFamily: 'VazirmatnMedium', fontSize: 12, color: COLORS.text, textAlign: 'right', marginBottom: 6 },
  input: { fontFamily: 'Vazirmatn', fontSize: 13, color: COLORS.text, backgroundColor: '#FAFAF9', borderColor: COLORS.border, borderWidth: 1, borderRadius: 13, paddingHorizontal: 13, paddingVertical: 11, marginBottom: 13 },
  roles: { flexDirection: 'row-reverse', gap: 7, marginBottom: 19 },
  role: { flex: 1, borderColor: COLORS.border, borderWidth: 1, borderRadius: 12, paddingVertical: 11, alignItems: 'center', backgroundColor: '#fff' },
  roleSelected: { borderColor: COLORS.primary, backgroundColor: '#FFFBEB' },
  roleText: { fontFamily: 'Vazirmatn', fontSize: 11, color: COLORS.muted },
  roleTextSelected: { fontFamily: 'VazirmatnBold', color: COLORS.primaryDark },
  button: { backgroundColor: COLORS.primaryDark, borderRadius: 14, minHeight: 51, alignItems: 'center', justifyContent: 'center', shadowColor: COLORS.primaryDark, shadowOpacity: 0.18, shadowRadius: 8, shadowOffset: { width: 0, height: 4 }, elevation: 2 },
  buttonText: { fontFamily: 'VazirmatnBold', color: '#fff', fontSize: 14 },
  pressed: { opacity: 0.85 }, disabled: { opacity: 0.65 },
  note: { fontFamily: 'Vazirmatn', fontSize: 10, color: COLORS.muted, textAlign: 'center', marginTop: 10 },
  secureRow: { flexDirection: 'row-reverse', justifyContent: 'center', alignItems: 'center', gap: 6, marginTop: 18 },
  secure: { fontFamily: 'Vazirmatn', fontSize: 10, color: COLORS.muted },
  secureIcon: { fontSize: 8, color: COLORS.success },
});
