import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useAuthStore } from '../store/authStore';
import { COLORS } from '../theme/colors';

export function AuthenticatedPlaceholder() {
  const user = useAuthStore((s) => s.user);
  const logout = useAuthStore((s) => s.logout);
  return (
    <View style={styles.container}>
      <Text style={styles.title}>خوش آمدید، {user?.name ?? 'کاربر'}!</Text>
      <Text style={styles.body}>ورود با موفقیت انجام شد. صفحه‌های اصلی در مرحلهٔ بعد اضافه می‌شوند.</Text>
      <Pressable onPress={logout} style={styles.button}><Text style={styles.buttonText}>خروج از حساب</Text></Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 28, backgroundColor: COLORS.background },
  title: { fontFamily: 'VazirmatnBold', fontSize: 22, color: COLORS.text, textAlign: 'center' },
  body: { fontFamily: 'Vazirmatn', fontSize: 14, color: COLORS.muted, textAlign: 'center', lineHeight: 24, marginTop: 12, marginBottom: 24 },
  button: { borderRadius: 14, backgroundColor: COLORS.primary, paddingHorizontal: 28, paddingVertical: 14 },
  buttonText: { fontFamily: 'VazirmatnBold', color: '#fff', fontSize: 14 },
});
