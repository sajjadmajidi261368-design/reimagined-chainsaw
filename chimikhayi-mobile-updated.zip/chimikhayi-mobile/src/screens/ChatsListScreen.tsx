import React, { useCallback, useMemo, useState } from 'react';
import { ActivityIndicator, Alert, FlatList, Image, Pressable, RefreshControl, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useFocusEffect } from '@react-navigation/native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ApiError, api, type AppNotification, type ChatThread, type ChatsResult, type MyOfferItem, type MyOffersResult, type NotificationsResult } from '../api/api';
import { mediaUrl } from '../api/media';
import type { MessagesStackParamList } from '../navigation/MessagesStackNavigator';
import { useAuthStore } from '../store/authStore';
import { COLORS } from '../theme/colors';
import { extractArray } from '../utils/collections';
import { LOST_OFFER_MESSAGE } from './ChatRoomScreen';
import { hideThread, loadDrafts, loadHidden, removeDraft, threadKey } from '../utils/chatLocal';
import { isSupplierSide } from '../utils/roles';

type Props = NativeStackScreenProps<MessagesStackParamList, 'Chats'>;
type TabKey = 'messages' | 'notifications';
type Outcome = 'won' | 'lost';
type ThreadItem = ChatThread & { isDraft?: boolean; draftText?: string; outcome?: Outcome };

function getChats(result: ChatsResult): ChatThread[] {
  if (Array.isArray(result)) return result;
  return result.chats ?? result.data ?? result.items ?? [];
}

function allowed(value?: boolean | number | string): boolean {
  return value === true || value === 1 || value === '1';
}

/** فقط وقتی سرور صریحاً بسته کرده باشد قفل می‌شود؛ نبودن فیلد یعنی باز */
function isExplicitlyClosed(value?: boolean | number | string): boolean {
  if (value === false || value === 0 || value === '0') return true;
  const s = String(value ?? '').toLowerCase();
  return s === 'false' || s === 'no' || s === 'off';
}

function isAdminOrSupportThread(thread: ChatThread): boolean {
  const blob = `${thread.peer_name ?? ''} ${thread.request_title ?? ''} ${thread.last_message ?? ''}`.toLocaleLowerCase('fa-IR');
  if (/پشتیبانی|ادمین|اعلان|support|admin|system|تیم پشتیبانی/.test(blob)) return true;
  const peerId = String(thread.peer_id ?? '');
  const requestId = String(thread.request_id ?? '');
  return peerId === '0' || peerId === '-1' || requestId === '0' || requestId === '-1';
}

function extractNotifications(result: NotificationsResult): AppNotification[] {
  if (Array.isArray(result)) return result;
  return result.notifications ?? result.messages ?? result.data ?? result.items ?? [];
}

function isNotificationUnread(item: AppNotification): boolean {
  if (item.is_read === false || item.is_read === 0 || item.is_read === '0') return true;
  if (item.is_read === true || item.is_read === 1 || item.is_read === '1') return false;
  return true; // unknown → treat as unread until opened
}

function parseDate(value?: string | null): Date | null {
  if (!value) return null;
  const parsed = new Date(value.replace(' ', 'T'));
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

function timeAgo(date?: string | null): string {
  if (!date) return '';
  const parsed = parseDate(date);
  if (!parsed) return date;
  const minutes = Math.max(0, Math.floor((Date.now() - parsed.getTime()) / 60000));
  if (minutes < 1) return 'اکنون';
  if (minutes < 60) return `${minutes.toLocaleString('fa-IR')} دقیقه پیش`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours.toLocaleString('fa-IR')} ساعت پیش`;
  const days = Math.floor(hours / 24);
  if (days === 1) return 'دیروز';
  if (days < 7) return `${days.toLocaleString('fa-IR')} روز پیش`;
  return parsed.toLocaleDateString('fa-IR');
}

function onlyThreadsWithMyOffers(threads: ChatThread[], offersResult: MyOffersResult): ChatThread[] {
  const offers = extractArray<MyOfferItem>(offersResult, ['offers', 'items', 'results', 'rows', 'data']);
  if (offers.length === 0) return [];
  const requestIds = new Set<string>();
  const titles = new Set<string>();
  offers.forEach((offer) => {
    if (offer.request_id !== undefined && offer.request_id !== null) requestIds.add(String(offer.request_id));
    const title = (offer.request_title ?? offer.title ?? '').trim();
    if (title) titles.add(title);
  });
  if (requestIds.size > 0) return threads.filter((thread) => requestIds.has(String(thread.request_id)));
  if (titles.size > 0) return threads.filter((thread) => titles.has((thread.request_title ?? '').trim()));
  return threads;
}

/** وضعیت پیشنهادهای من: درخواست → won/lost (فقط برای درخواست‌هایی که خریدار یکی را پذیرفته) */
function lostOffers(offersResult: MyOffersResult | null): MyOfferItem[] {
  if (!offersResult) return [];
  return extractArray<MyOfferItem>(offersResult, ['offers', 'items', 'results', 'rows', 'data'])
    .filter((offer) => String(offer.status ?? '').toLowerCase() === 'rejected');
}

function outcomeByRequest(offersResult: MyOffersResult | null): Map<string, Outcome> {
  const map = new Map<string, Outcome>();
  if (!offersResult) return map;
  extractArray<MyOfferItem>(offersResult, ['offers', 'items', 'results', 'rows', 'data']).forEach((offer) => {
    if (offer.request_id === undefined || offer.request_id === null) return;
    const status = String(offer.status ?? '').toLowerCase();
    if (status === 'accepted') map.set(String(offer.request_id), 'won');
    else if (status === 'rejected') map.set(String(offer.request_id), 'lost');
  });
  return map;
}

const LOST_READ_PREFIX = 'chimikhayi.lostOfferNotifRead.';

export function ChatsListScreen({ navigation }: Props) {
  const logout = useAuthStore((s) => s.logout);
  const user = useAuthStore((s) => s.user);
  const isBuyer = user?.role === 'buyer';
  const [tab, setTab] = useState<TabKey>('messages');
  const [chats, setChats] = useState<ThreadItem[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [failedAvatars, setFailedAvatars] = useState<Set<string>>(new Set());
  const [query, setQuery] = useState('');
  const [unreadOnly, setUnreadOnly] = useState(false);
  const [openedNotifId, setOpenedNotifId] = useState<string | null>(null);
  const [markingAll, setMarkingAll] = useState(false);

  const loadData = useCallback(async (refresh = false) => {
    refresh ? setRefreshing(true) : setLoading(true);
    setError(null);
    try {
      const current = useAuthStore.getState().user;
      if (!current?.id) {
        setChats([]);
        setNotifications([]);
        setError('برای دیدن پیام‌ها وارد حساب شوید.');
        return;
      }
      const userId = current.id;

      // هر درخواست جداگانه؛ خرابی اعلان‌ها نباید پیام‌ها را از کار بیندازد
      let chatsResult: ChatsResult = [];
      try {
        chatsResult = await api.getChats();
      } catch (cause) {
        if (cause instanceof ApiError && cause.code === 'auth') {
          logout();
          return;
        }
        throw cause;
      }

      const [offersResult, notifResult, hidden, drafts] = await Promise.all([
        isSupplierSide(current)
          ? api.getMyOffers().catch((cause: unknown) => {
              if (cause instanceof ApiError && cause.code === 'auth') throw cause;
              return null;
            })
          : Promise.resolve(null),
        api.getNotifications().catch((cause: unknown) => {
          if (cause instanceof ApiError && cause.code === 'auth') throw cause;
          return [] as NotificationsResult;
        }),
        loadHidden(userId),
        loadDrafts(userId),
      ]);

      const serverNotifications = extractNotifications(notifResult ?? []);
      const alreadyNotified = serverNotifications.some((n) => (n.message ?? n.body ?? n.content ?? '').includes('پیشنهاد دیگری انتخاب شد'));
      let lostNotifications: AppNotification[] = [];
      if (!alreadyNotified) {
        let readIds: string[] = [];
        try { readIds = JSON.parse((await AsyncStorage.getItem(`${LOST_READ_PREFIX}${userId}`)) ?? '[]') as string[]; } catch { readIds = []; }
        lostNotifications = lostOffers(offersResult ?? null).map((offer) => ({
          id: `lost-${offer.id}`,
          title: 'پیشنهاد دیگری انتخاب شد',
          message: LOST_OFFER_MESSAGE,
          created_at: offer.created_at,
          is_read: readIds.includes(`lost-${offer.id}`) ? 1 : 0,
          type: 'offer_lost',
        }));
      }
      setNotifications([...lostNotifications, ...serverNotifications]);

      let threads: ThreadItem[] = getChats(chatsResult);

      // برای خریدار: اگر get_my_chats ناقص بود، از پیشنهادهای درخواست‌های خودش thread بساز
      if (current.role === 'buyer') {
        try {
          const myReqResult = await api.getMyRequests();
          const myRequests = Array.isArray(myReqResult)
            ? myReqResult
            : (myReqResult as { requests?: unknown[]; data?: unknown[]; items?: unknown[] }).requests
              ?? (myReqResult as { data?: unknown[] }).data
              ?? (myReqResult as { items?: unknown[] }).items
              ?? [];
          const existingKeys = new Set(threads.map((th) => threadKey(th.request_id, th.peer_id)));
          const buyerOutcomes = new Map<string, Outcome>();
          for (const raw of myRequests as Array<Record<string, unknown>>) {
            const requestId = raw.id as string | number | undefined;
            if (requestId === undefined || requestId === null) continue;
            const title = String(raw.title ?? 'درخواست');
            // اگر خود لیست offers داشت
            const embedded = (raw.offers as Array<Record<string, unknown>> | undefined) ?? [];
            let offers = embedded;
            if (!offers.length && Number(raw.offers_count ?? 0) > 0) {
              try {
                const detail = await api.getRequest(requestId);
                const req = ('request' in detail && detail.request)
                  ? detail.request
                  : ('data' in detail && detail.data)
                    ? detail.data
                    : detail as { offers?: Array<Record<string, unknown>> };
                offers = (req.offers as Array<Record<string, unknown>> | undefined) ?? [];
              } catch {
                offers = [];
              }
            }
            for (const offer of offers) {
              const peerId = offer.supplier_id as string | number | undefined;
              if (peerId === undefined || peerId === null) continue;
              const key = threadKey(requestId, peerId);
              const offerStatus = String(offer.status ?? '').toLowerCase();
              if (offerStatus === 'accepted') buyerOutcomes.set(key, 'won');
              else if (offerStatus === 'rejected') buyerOutcomes.set(key, 'lost');
              if (existingKeys.has(key)) continue;
              existingKeys.add(key);
              threads.push({
                request_id: requestId,
                peer_id: peerId,
                peer_name: String(offer.supplier_name ?? 'تأمین‌کننده'),
                request_title: title,
                last_message: null,
                last_message_at: String(raw.created_at ?? new Date().toISOString()),
                unread_count: 0,
                allow_chat: (offer.allow_chat as boolean | number | string | undefined) ?? 1,
              });
            }
          }
          threads = threads.map((th) => {
            const outcome = buyerOutcomes.get(threadKey(th.request_id, th.peer_id));
            return outcome ? { ...th, outcome } : th;
          });
        } catch {
          // لیست سرور کافی است؛ غنی‌سازی اختیاری است
        }
      }

      const adminThreads = threads.filter(isAdminOrSupportThread);
      const normalThreads = threads.filter((th) => !isAdminOrSupportThread(th));
      let filteredNormal = normalThreads;
      if (isSupplierSide(current) && offersResult) {
        filteredNormal = onlyThreadsWithMyOffers(normalThreads, offersResult);
        const outcomes = outcomeByRequest(offersResult);
        filteredNormal = filteredNormal.map((th) => {
          const outcome = outcomes.get(String(th.request_id));
          return outcome ? { ...th, outcome } : th;
        });
      }
      threads = [...adminThreads, ...filteredNormal];

      const serverKeys = new Set<string>();
      threads = threads
        .filter((thread) => {
          const key = threadKey(thread.request_id, thread.peer_id);
          serverKeys.add(key);
          // hidden[key] = timestamp up to which messages are hidden on this device
          return hidden[key] === undefined;
        })
        .map((thread) => {
          const key = threadKey(thread.request_id, thread.peer_id);
          const draft = drafts[key];
          return draft?.text ? { ...thread, draftText: draft.text } : thread;
        });

      const draftThreads: ThreadItem[] = Object.values(drafts)
        .filter((draft) => !serverKeys.has(draft.key) && (draft.local || Boolean(draft.text)))
        .map((draft) => ({
          request_id: draft.requestId,
          peer_id: draft.peerId,
          peer_name: draft.peerName,
          peer_avatar: draft.peerAvatar ?? null,
          request_title: draft.requestTitle,
          last_message: null,
          last_message_at: new Date(draft.updatedAt).toISOString(),
          unread_count: 0,
          allow_chat: 1,
          isDraft: true,
          draftText: draft.text,
        }));

      threads = [...threads, ...draftThreads].sort(
        (a, b) => (parseDate(b.last_message_at)?.getTime() ?? 0) - (parseDate(a.last_message_at)?.getTime() ?? 0),
      );
      setChats(threads);
    } catch (cause) {
      if (cause instanceof ApiError && cause.code === 'auth') {
        logout();
        return;
      }
      const message = cause instanceof ApiError
        ? cause.message
        : cause instanceof Error
          ? cause.message
          : 'دریافت داده‌ها با خطا روبه‌رو شد.';
      setError(message);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [logout]);

  useFocusEffect(useCallback(() => { void loadData(); }, [loadData]));

  const messageUnread = useMemo(
    () => chats.reduce((sum, chat) => sum + (Number(chat.unread_count ?? 0) || 0), 0),
    [chats],
  );
  const notifUnread = useMemo(
    () => notifications.filter(isNotificationUnread).length,
    [notifications],
  );

  const visibleChats = useMemo(() => {
    const needle = query.trim().toLocaleLowerCase('fa-IR');
    return chats.filter((chat) => {
      if (unreadOnly && !(Number(chat.unread_count ?? 0) > 0)) return false;
      if (!needle) return true;
      return [chat.peer_name, chat.request_title, chat.last_message]
        .filter(Boolean)
        .join(' ')
        .toLocaleLowerCase('fa-IR')
        .includes(needle);
    });
  }, [chats, query, unreadOnly]);

  const confirmDelete = (item: ThreadItem) => {
    Alert.alert(
      'حذف گفتگو',
      item.isDraft
        ? 'این پیش‌نویس حذف شود؟'
        : 'پیام‌های این گفتگو از این دستگاه پاک می‌شوند. اگر طرف مقابل پیام تازه‌ای بفرستد، گفتگو دوباره نمایش داده می‌شود.',
      [
        { text: 'انصراف', style: 'cancel' },
        {
          text: 'حذف',
          style: 'destructive',
          onPress: () => {
            void (async () => {
              const uid = useAuthStore.getState().user?.id;
              if (!uid) return;
              const key = threadKey(item.request_id, item.peer_id);
              if (item.isDraft) await removeDraft(uid, item.request_id, item.peer_id);
              else await hideThread(uid, item.request_id, item.peer_id, Date.now());
              setChats((prev) => prev.filter((c) => threadKey(c.request_id, c.peer_id) !== key));
            })();
          },
        },
      ],
    );
  };

  const openChat = (item: ThreadItem) => {
    // قاعده ساده و قطعی:
    // آگهی باز (بدون outcome) → چت برای همه باز
    // آگهی بسته + برنده (won) → باز
    // آگهی بسته + بازنده (lost) → بسته
    const canChat = item.outcome !== 'lost';
    navigation.navigate('ChatRoom', {
      requestId: item.request_id,
      peerId: item.peer_id,
      peerName: item.peer_name,
      requestTitle: item.request_title,
      peerAvatar: item.peer_avatar ? String(item.peer_avatar) : undefined,
      allowChat: canChat,
      outcome: item.outcome,
    });
  };

  const openNotification = async (item: AppNotification) => {
    const id = String(item.id);
    setOpenedNotifId((prev) => (prev === id ? null : id));
    if (!isNotificationUnread(item)) return;
    setNotifications((prev) =>
      prev.map((n) => (String(n.id) === id ? { ...n, is_read: 1 } : n)),
    );
    if (id.startsWith('lost-')) {
      const uid = useAuthStore.getState().user?.id;
      try {
        const key = `${LOST_READ_PREFIX}${uid}`;
        const ids = JSON.parse((await AsyncStorage.getItem(key)) ?? '[]') as string[];
        await AsyncStorage.setItem(key, JSON.stringify(Array.from(new Set([...ids, id]))));
      } catch { /* ignore */ }
      return;
    }
    try {
      await api.markNotificationRead(item.id);
    } catch {
      // local mark still applies
    }
  };

  const markAllRead = async () => {
    if (notifUnread === 0) return;
    setMarkingAll(true);
    setNotifications((prev) => prev.map((n) => ({ ...n, is_read: 1 })));
    try {
      const uid = useAuthStore.getState().user?.id;
      const lostIds = notifications.map((n) => String(n.id)).filter((id) => id.startsWith('lost-'));
      if (lostIds.length) await AsyncStorage.setItem(`${LOST_READ_PREFIX}${uid}`, JSON.stringify(lostIds)).catch(() => undefined);
      await api.markAllNotificationsRead();
    } catch {
      // local mark still applies
    } finally {
      setMarkingAll(false);
    }
  };

  const renderChat = ({ item }: { item: ThreadItem }) => {
    const unread = Number(item.unread_count ?? 0) > 0;
    const avatarUri = item.peer_avatar ? mediaUrl(String(item.peer_avatar)) : '';
    const avatarFailed = avatarUri ? failedAvatars.has(avatarUri) : true;
    return (
      <Pressable
        onPress={() => openChat(item)}
        style={({ pressed }) => [styles.chatCard, unread && styles.chatCardUnread, pressed && styles.pressed]}
      >
        <View style={styles.peerAvatarWrap}>
          {avatarUri && !avatarFailed ? (
            <Image
              source={{ uri: avatarUri }}
              style={styles.peerAvatar}
              onError={() => setFailedAvatars((prev) => new Set(prev).add(avatarUri))}
            />
          ) : (
            <View style={styles.peerAvatarFallback}>
              <Text style={styles.peerInitial}>{(item.peer_name || '؟')[0]}</Text>
            </View>
          )}
        </View>
        <View style={styles.chatBody}>
          <View style={styles.chatTop}>
            <Text style={styles.peerName} numberOfLines={1}>{item.peer_name || 'کاربر'}</Text>
            <View style={styles.timeRow}>
              {item.isDraft ? (
                <View style={styles.draftBadge}><Text style={styles.draftBadgeText}>پیش‌نویس</Text></View>
              ) : null}
              <Text style={[styles.time, unread && styles.timeUnread]}>{timeAgo(item.last_message_at)}</Text>
            </View>
          </View>
          {item.request_title ? (
            <View style={styles.requestRow}>
              <MaterialCommunityIcons name="file-document-outline" size={12} color={COLORS.primaryDark} />
              <Text style={styles.requestTitle} numberOfLines={1}>{item.request_title}</Text>
            </View>
          ) : null}
          <View style={styles.lastRow}>
            <Text style={[styles.lastMessage, unread && styles.lastMessageUnread, item.isDraft && styles.lastMessageDraft]} numberOfLines={1}>
              {item.isDraft ? (item.draftText || 'پیش‌نویس...') : (item.last_message || '—')}
            </Text>
            {unread ? (
              <View style={styles.unreadBadge}>
                <Text style={styles.unreadText}>{Number(item.unread_count).toLocaleString('fa-IR')}</Text>
              </View>
            ) : null}
          </View>
        </View>
        <Pressable onPress={() => confirmDelete(item)} hitSlop={8} style={styles.deleteButton}>
          <MaterialCommunityIcons name="trash-can-outline" size={18} color={COLORS.primaryDark} />
        </Pressable>
      </Pressable>
    );
  };

  const renderNotification = ({ item }: { item: AppNotification }) => {
    const id = String(item.id);
    const unread = isNotificationUnread(item);
    const expanded = openedNotifId === id;
    const body = (item.message ?? item.body ?? item.content ?? '').trim();
    const title = (item.title ?? item.from_name ?? item.sender_name ?? 'اعلان پشتیبانی').trim();
    return (
      <Pressable
        onPress={() => void openNotification(item)}
        style={({ pressed }) => [
          styles.notifCard,
          unread && styles.notifCardUnread,
          expanded && styles.notifCardExpanded,
          pressed && styles.pressed,
        ]}
      >
        <View style={[styles.notifIcon, unread && styles.notifIconUnread]}>
          <MaterialCommunityIcons name={unread ? 'bell-badge-outline' : 'bell-outline'} size={20} color={COLORS.primaryDark} />
        </View>
        <View style={styles.notifCopy}>
          <View style={styles.notifTop}>
            <Text style={[styles.notifCardTitle, unread && styles.notifCardTitleUnread]} numberOfLines={1}>{title}</Text>
            {unread ? <View style={styles.dot} /> : null}
          </View>
          {body ? (
            <Text style={styles.notifCardBody} numberOfLines={expanded ? 12 : 2}>{body}</Text>
          ) : null}
          <Text style={styles.notifTime}>{timeAgo(item.created_at)}</Text>
        </View>
      </Pressable>
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        <View style={styles.state}><ActivityIndicator color={COLORS.primary} size="large" /></View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <View style={styles.header}>
        <View style={styles.headerIcon}>
          <MaterialCommunityIcons name="message-text-outline" size={22} color={COLORS.primaryDark} />
        </View>
        <View style={styles.headerCopy}>
          <Text style={styles.title}>پیام‌ها</Text>
          <Text style={styles.subtitle}>
            {isBuyer ? 'گفتگو با تأمین‌کنندگان پیشنهاددهنده' : 'گفتگو و اعلان‌های حساب شما'}
          </Text>
        </View>
      </View>

      {/* Instagram-like segmented tabs */}
      <View style={styles.tabBar}>
        <Pressable
          onPress={() => setTab('messages')}
          style={[styles.tabItem, tab === 'messages' && styles.tabItemActive]}
        >
          <MaterialCommunityIcons
            name={tab === 'messages' ? 'message-text' : 'message-text-outline'}
            size={18}
            color={tab === 'messages' ? COLORS.primaryDark : COLORS.muted}
          />
          <Text style={[styles.tabLabel, tab === 'messages' && styles.tabLabelActive]}>پیام‌ها</Text>
          {messageUnread > 0 ? (
            <View style={styles.tabBadge}><Text style={styles.tabBadgeText}>{messageUnread.toLocaleString('fa-IR')}</Text></View>
          ) : null}
        </Pressable>
        <Pressable
          onPress={() => setTab('notifications')}
          style={[styles.tabItem, tab === 'notifications' && styles.tabItemActive]}
        >
          <MaterialCommunityIcons
            name={tab === 'notifications' ? 'bell' : 'bell-outline'}
            size={18}
            color={tab === 'notifications' ? COLORS.primaryDark : COLORS.muted}
          />
          <Text style={[styles.tabLabel, tab === 'notifications' && styles.tabLabelActive]}>اعلان‌ها</Text>
          {notifUnread > 0 ? (
            <View style={styles.tabBadge}><Text style={styles.tabBadgeText}>{notifUnread.toLocaleString('fa-IR')}</Text></View>
          ) : null}
        </Pressable>
      </View>

      {tab === 'messages' ? (
        <>
          <View style={styles.toolbar}>
            <View style={styles.searchBox}>
              <MaterialCommunityIcons name="magnify" size={18} color={COLORS.muted} />
              <TextInput
                value={query}
                onChangeText={setQuery}
                placeholder="جست‌وجوی نام یا عنوان درخواست..."
                placeholderTextColor={COLORS.muted}
                style={styles.searchInput}
                textAlign="right"
              />
              {query ? (
                <Pressable onPress={() => setQuery('')} hitSlop={8}>
                  <MaterialCommunityIcons name="close-circle" size={16} color={COLORS.muted} />
                </Pressable>
              ) : null}
            </View>
            <Pressable
              onPress={() => setUnreadOnly((v) => !v)}
              style={[styles.filterChip, unreadOnly && styles.filterChipActive]}
            >
              <MaterialCommunityIcons name="email-mark-as-unread" size={15} color={unreadOnly ? '#fff' : COLORS.primaryDark} />
              <Text style={[styles.filterChipText, unreadOnly && styles.filterChipTextActive]}>نخوانده</Text>
            </Pressable>
          </View>
          {error ? (
            <View style={styles.state}>
              <Text style={styles.stateTitle}>خطا</Text>
              <Text style={styles.stateText}>{error}</Text>
              <Pressable onPress={() => void loadData()} style={styles.retryButton}>
                <Text style={styles.retryText}>تلاش مجدد</Text>
              </Pressable>
            </View>
          ) : (
            <FlatList
              data={visibleChats}
              keyExtractor={(item, index) => `chat-${item.request_id}-${item.peer_id}-${index}`}
              renderItem={renderChat}
              contentContainerStyle={styles.listContent}
              showsVerticalScrollIndicator={false}
              refreshControl={
                <RefreshControl refreshing={refreshing} onRefresh={() => void loadData(true)} tintColor={COLORS.primary} colors={[COLORS.primary]} />
              }
              ListEmptyComponent={
                <View style={styles.state}>
                  <View style={styles.emptyIcon}>
                    <MaterialCommunityIcons name="chat-outline" size={28} color={COLORS.primaryDark} />
                  </View>
                  <Text style={styles.stateTitle}>گفتگویی نیست</Text>
                  <Text style={styles.stateText}>وقتی پیامی رد و بدل شود، اینجا نمایش داده می‌شود.</Text>
                </View>
              }
            />
          )}
        </>
      ) : (
        <>
          <View style={styles.notifToolbar}>
            <Text style={styles.notifToolbarHint}>
              {notifUnread > 0
                ? `${notifUnread.toLocaleString('fa-IR')} اعلان خوانده‌نشده`
                : 'همه اعلان‌ها خوانده شده‌اند'}
            </Text>
            <Pressable
              onPress={() => void markAllRead()}
              disabled={notifUnread === 0 || markingAll}
              style={[styles.markAllBtn, (notifUnread === 0 || markingAll) && styles.markAllBtnDisabled]}
            >
              {markingAll ? (
                <ActivityIndicator size="small" color="#fff" />
              ) : (
                <>
                  <MaterialCommunityIcons name="check-all" size={16} color={notifUnread === 0 ? COLORS.muted : '#fff'} />
                  <Text style={[styles.markAllText, notifUnread === 0 && styles.markAllTextDisabled]}>خواندن همه</Text>
                </>
              )}
            </Pressable>
          </View>
          <FlatList
            data={notifications}
            keyExtractor={(item, index) => `notif-${item.id}-${index}`}
            renderItem={renderNotification}
            contentContainerStyle={styles.listContent}
            showsVerticalScrollIndicator={false}
            refreshControl={
              <RefreshControl refreshing={refreshing} onRefresh={() => void loadData(true)} tintColor={COLORS.primary} colors={[COLORS.primary]} />
            }
            ListEmptyComponent={
              <View style={styles.state}>
                <View style={styles.emptyIcon}>
                  <MaterialCommunityIcons name="bell-outline" size={28} color={COLORS.primaryDark} />
                </View>
                <Text style={styles.stateTitle}>اعلانی نیست</Text>
                <Text style={styles.stateText}>پیام‌های ادمین و پشتیبانی اینجا نمایش داده می‌شوند.</Text>
              </View>
            }
          />
        </>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.background },
  header: {
    minHeight: 68,
    paddingHorizontal: 18,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 11,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#EEEAE1',
  },
  headerIcon: {
    width: 40,
    height: 40,
    borderRadius: 14,
    backgroundColor: '#F4E9C9',
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerCopy: { flex: 1 },
  title: { fontFamily: 'VazirmatnBold', fontSize: 17, color: COLORS.text, textAlign: 'right' },
  subtitle: { fontFamily: 'Vazirmatn', fontSize: 9, lineHeight: 15, color: COLORS.muted, textAlign: 'right', marginTop: 1 },

  tabBar: {
    flexDirection: 'row-reverse',
    marginHorizontal: 15,
    marginTop: 12,
    padding: 4,
    borderRadius: 16,
    backgroundColor: '#F3F0E8',
  },
  tabItem: {
    flex: 1,
    minHeight: 42,
    borderRadius: 13,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
  },
  tabItemActive: {
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOpacity: 0.06,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  tabLabel: { fontFamily: 'VazirmatnMedium', fontSize: 12, color: COLORS.muted },
  tabLabelActive: { fontFamily: 'VazirmatnBold', color: COLORS.primaryDark },
  tabBadge: {
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    paddingHorizontal: 5,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tabBadgeText: { fontFamily: 'VazirmatnBold', fontSize: 8, color: '#fff' },

  toolbar: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 15,
    paddingTop: 12,
  },
  searchBox: {
    flex: 1,
    minHeight: 42,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 7,
    paddingHorizontal: 11,
    borderRadius: 13,
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: COLORS.border,
  },
  searchInput: { flex: 1, fontFamily: 'Vazirmatn', fontSize: 10, color: COLORS.text, paddingVertical: 8 },
  filterChip: {
    minHeight: 42,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 11,
    borderRadius: 13,
    backgroundColor: '#F4E9C9',
  },
  filterChipActive: { backgroundColor: COLORS.primaryDark },
  filterChipText: { fontFamily: 'VazirmatnBold', fontSize: 9, color: COLORS.primaryDark },
  filterChipTextActive: { color: '#fff' },

  notifToolbar: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 15,
    paddingTop: 12,
    gap: 10,
  },
  notifToolbarHint: { fontFamily: 'Vazirmatn', fontSize: 10, color: COLORS.muted, textAlign: 'right', flex: 1 },
  markAllBtn: {
    minHeight: 36,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    borderRadius: 12,
    backgroundColor: COLORS.primaryDark,
  },
  markAllBtnDisabled: { backgroundColor: '#EFEBE3' },
  markAllText: { fontFamily: 'VazirmatnBold', fontSize: 10, color: '#fff' },
  markAllTextDisabled: { color: COLORS.muted },

  listContent: { padding: 15, paddingBottom: 28, flexGrow: 1 },

  chatCard: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 11,
    paddingHorizontal: 12,
    paddingVertical: 13,
    borderRadius: 17,
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#EAE6DC',
    marginBottom: 10,
  },
  chatCardUnread: { borderColor: '#E4C66C', backgroundColor: '#FFFDF6' },
  pressed: { opacity: 0.86 },
  peerAvatarWrap: { width: 48, height: 48 },
  peerAvatar: { width: 48, height: 48, borderRadius: 17, backgroundColor: '#F4E9C9' },
  peerAvatarFallback: {
    width: 48,
    height: 48,
    borderRadius: 17,
    backgroundColor: '#F4E9C9',
    alignItems: 'center',
    justifyContent: 'center',
  },
  peerInitial: { fontFamily: 'VazirmatnBold', fontSize: 20, color: COLORS.primaryDark },
  chatBody: { flex: 1, minWidth: 0 },
  chatTop: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', gap: 8 },
  peerName: { flex: 1, fontFamily: 'VazirmatnBold', fontSize: 12, color: COLORS.text, textAlign: 'right' },
  time: { fontFamily: 'Vazirmatn', fontSize: 8, color: COLORS.muted },
  timeUnread: { color: COLORS.primaryDark, fontFamily: 'VazirmatnBold' },
  requestRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 4, marginTop: 3 },
  requestTitle: { flex: 1, fontFamily: 'VazirmatnMedium', fontSize: 9, color: COLORS.primaryDark, textAlign: 'right' },
  lastRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 7, marginTop: 4 },
  lastMessage: { flex: 1, fontFamily: 'Vazirmatn', fontSize: 9, color: COLORS.muted, textAlign: 'right' },
  lastMessageUnread: { color: COLORS.text, fontFamily: 'VazirmatnMedium' },
  lastMessageDraft: { color: COLORS.primaryDark },
  deleteButton: {
    width: 34,
    height: 34,
    borderRadius: 11,
    backgroundColor: '#FEF3C7',
    alignItems: 'center',
    justifyContent: 'center',
  },
  timeRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  draftBadge: { paddingHorizontal: 7, paddingVertical: 2, borderRadius: 8, backgroundColor: '#FEE2E2' },
  draftBadgeText: { fontFamily: 'VazirmatnBold', fontSize: 8, color: '#B91C1C' },
  unreadBadge: {
    minWidth: 19,
    height: 19,
    paddingHorizontal: 5,
    borderRadius: 10,
    backgroundColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  unreadText: { fontFamily: 'VazirmatnBold', fontSize: 8, color: '#fff' },

  notifCard: {
    flexDirection: 'row-reverse',
    gap: 11,
    padding: 13,
    borderRadius: 16,
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#EAE6DC',
    marginBottom: 10,
  },
  notifCardUnread: { backgroundColor: '#FFFBEB', borderColor: '#F0D48A' },
  notifCardExpanded: { borderColor: COLORS.primaryDark },
  notifIcon: {
    width: 40,
    height: 40,
    borderRadius: 14,
    backgroundColor: '#F4E9C9',
    alignItems: 'center',
    justifyContent: 'center',
  },
  notifIconUnread: { backgroundColor: '#FDE68A' },
  notifCopy: { flex: 1 },
  notifTop: { flexDirection: 'row-reverse', alignItems: 'center', gap: 6 },
  notifCardTitle: { flex: 1, fontFamily: 'VazirmatnMedium', fontSize: 12, color: COLORS.text, textAlign: 'right' },
  notifCardTitleUnread: { fontFamily: 'VazirmatnBold' },
  notifCardBody: { fontFamily: 'Vazirmatn', fontSize: 10, color: '#57534E', textAlign: 'right', marginTop: 4, lineHeight: 17 },
  notifTime: { fontFamily: 'Vazirmatn', fontSize: 8, color: COLORS.muted, textAlign: 'right', marginTop: 6 },
  dot: { width: 8, height: 8, borderRadius: 4, backgroundColor: COLORS.primary },

  state: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 22, gap: 9 },
  emptyIcon: {
    width: 64,
    height: 64,
    borderRadius: 22,
    backgroundColor: '#F4E9C9',
    alignItems: 'center',
    justifyContent: 'center',
  },
  stateTitle: { fontFamily: 'VazirmatnBold', fontSize: 13, color: COLORS.text, textAlign: 'center' },
  stateText: { fontFamily: 'Vazirmatn', fontSize: 10, lineHeight: 19, color: COLORS.muted, textAlign: 'center' },
  retryButton: { marginTop: 3, backgroundColor: COLORS.primaryDark, borderRadius: 11, paddingHorizontal: 17, paddingVertical: 8 },
  retryText: { fontFamily: 'VazirmatnBold', color: '#fff', fontSize: 10 },
});
