import React, { useState } from 'react';
import { ActivityIndicator, Alert, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ApiError } from '../api/api';
import { RootStackParamList } from '../navigation/RootNavigator';
import { useAuthStore } from '../store/authStore';
import { COLORS } from '../theme/colors';

type Props = NativeStackScreenProps<RootStackParamList, 'Login'>;
const digitsOnly = (value: string) => value.replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d))).replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));

export function LoginScreen({ navigation }: Props) {
  const login = useAuthStore((s) => s.login);
  const busy = useAuthStore((s) => s.busy);
  const [mobile, setMobile] = useState('');
  const [password, setPassword] = useState('');

  const onLogin = async () => {
    const username = digitsOnly(mobile).replace(/[\s-]/g, '');
    if (!/^0?9\d{9}$/.test(username) || !password) return Alert.alert('اطلاعات نامعتبر است', 'شماره موبایل معتبر و رمز عبور را وارد کنید.');
    try {
      await login(username, password);
    } catch (error) {
      const message = error instanceof ApiError ? error.message : 'ورود انجام نشد. دوباره تلاش کنید.';
      Alert.alert('ورود ناموفق', message);
    }
  };

  return (
    <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
        <View style={styles.brandMark}><Text style={styles.brandIcon}>تأمین کالا</Text></View>
        <Text style={styles.title}>چی میخوای؟</Text>
        <Text style={styles.subtitle}>به بازار هوشمند کسب‌وکارها خوش آمدید</Text>
        <View style={styles.card}>
          <Text style={styles.cardTitle}>ورود به حساب</Text>
          <Text style={styles.label}>نام کاربری (شماره موبایل)</Text>
          <TextInput value={mobile} onChangeText={setMobile} placeholder="مثلاً ۰۹۱۲۱۲۳۴۵۶۷" keyboardType="phone-pad" textAlign="right" style={styles.input} autoComplete="tel" />
          <Text style={styles.label}>رمز عبور</Text>
          <TextInput value={password} onChangeText={setPassword} placeholder="رمز عبور خود را وارد کنید" secureTextEntry textAlign="right" style={styles.input} autoComplete="password" />
          <Pressable onPress={onLogin} disabled={busy} style={({ pressed }) => [styles.button, pressed && styles.pressed, busy && styles.disabled]}>
            {busy ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>ورود</Text>}
          </Pressable>
          <View style={styles.signupRow}><Text style={styles.muted}>حساب کاربری ندارید؟ </Text><Pressable onPress={() => navigation.navigate('Register')}><Text style={styles.link}>ثبت‌نام کنید</Text></Pressable></View>
        </View>
        <Text style={styles.footer}>بازار معکوس تامین و تقاضای کسب‌وکارها</Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: COLORS.background },
  container: { flexGrow: 1, justifyContent: 'center', paddingHorizontal: 24, paddingVertical: 32 },
  brandMark: { alignSelf: 'center', minWidth: 124, height: 46, paddingHorizontal: 14, borderRadius: 16, backgroundColor: COLORS.primary, alignItems: 'center', justifyContent: 'center', marginBottom: 12 },
  brandIcon: { fontFamily: 'VazirmatnBold', fontSize: 16, color: '#fff' },
  title: { fontFamily: 'VazirmatnBold', fontSize: 28, textAlign: 'center', color: COLORS.text },
  subtitle: { fontFamily: 'Vazirmatn', fontSize: 14, textAlign: 'center', color: COLORS.muted, marginTop: 4, marginBottom: 28 },
  card: { backgroundColor: COLORS.surface, borderRadius: 22, borderWidth: 1, borderColor: COLORS.border, padding: 22, shadowColor: '#292524', shadowOpacity: 0.06, shadowRadius: 16, shadowOffset: { width: 0, height: 8 }, elevation: 2 },
  cardTitle: { fontFamily: 'VazirmatnBold', fontSize: 19, color: COLORS.text, textAlign: 'right', marginBottom: 18 },
  label: { fontFamily: 'VazirmatnMedium', fontSize: 13, color: COLORS.text, textAlign: 'right', marginBottom: 7 },
  input: { fontFamily: 'Vazirmatn', fontSize: 14, color: COLORS.text, backgroundColor: '#FAFAF9', borderColor: COLORS.border, borderWidth: 1, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 13, marginBottom: 16 },
  button: { backgroundColor: COLORS.primary, borderRadius: 14, minHeight: 52, alignItems: 'center', justifyContent: 'center', marginTop: 4 },
  buttonText: { fontFamily: 'VazirmatnBold', color: '#fff', fontSize: 16 },
  pressed: { opacity: 0.85 }, disabled: { opacity: 0.65 },
  signupRow: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: 18 },
  muted: { fontFamily: 'Vazirmatn', fontSize: 13, color: COLORS.muted },
  link: { fontFamily: 'VazirmatnBold', fontSize: 13, color: COLORS.primaryDark },
  footer: { fontFamily: 'Vazirmatn', fontSize: 12, color: COLORS.muted, textAlign: 'center', marginTop: 24 },
});
