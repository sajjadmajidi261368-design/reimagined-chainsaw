import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, FlatList, Image, Linking, Modal, Pressable, RefreshControl, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ApiError, api, type OpenRequest, type OpenRequestsResult } from '../api/api';
import type { HomeStackParamList } from '../navigation/HomeStackNavigator';
import { useAuthStore } from '../store/authStore';
import { mediaUrl } from '../api/media';
import { COLORS } from '../theme/colors';
import { ABOUT_PAGE, CONTACT_PAGE, ENAMAD_PAGE, PRIVACY_PAGE, SUPPORT_EMAIL, SUPPORT_PAGE, TERMS_PAGE, type SitePage } from '../content/sitePages';

type Props = NativeStackScreenProps<HomeStackParamList, 'Home'>;
type Category = { title: string; icon: keyof typeof MaterialCommunityIcons.glyphMap };
const CATEGORIES: Category[] = [
  { title: 'مواد دارویی', icon: 'pill' },
  { title: 'پتروشیمی', icon: 'flask-outline' },
  { title: 'قطعات خودرو', icon: 'car-cog' },
  { title: 'مواد اولیه', icon: 'test-tube' },
  { title: 'لوازم خانگی', icon: 'fridge-outline' },
  { title: 'تجهیزات صنعتی', icon: 'factory' },
  { title: 'مصالح ساختمانی', icon: 'home-city-outline' },
  { title: 'مواد غذایی', icon: 'food-apple-outline' },
  { title: 'ماشین‌آلات', icon: 'cog-outline' },
  { title: 'بسته‌بندی', icon: 'package-variant-closed' },
  { title: 'نساجی', icon: 'tshirt-crew-outline' },
  { title: 'سایر', icon: 'dots-grid' },
];

function getRequests(result: OpenRequestsResult): OpenRequest[] {
  if (Array.isArray(result)) return result;
  return result.requests ?? result.data ?? result.items ?? [];
}

export function HomeScreen({ navigation }: Props) {
  const logout = useAuthStore((s) => s.logout);
  const user = useAuthStore((s) => s.user);
  const [requests, setRequests] = useState<OpenRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchText, setSearchText] = useState('');
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [failedImages, setFailedImages] = useState<Set<string>>(new Set());
  const [menuVisible, setMenuVisible] = useState(false);
  const [sitePage, setSitePage] = useState<SitePage | null>(null);

  const openDashboard = (screen: 'Settings') => {
    setMenuVisible(false);
    const tabs = navigation.getParent() as unknown as { navigate: (name: string, params?: object) => void } | undefined;
    tabs?.navigate('Dashboard', { screen });
  };
  const openSite = (page: SitePage) => {
    setMenuVisible(false);
    setSitePage(page);
  };
  const emailSupport = () => {
    void Linking.openURL(`mailto:${SUPPORT_EMAIL}`).catch(() => undefined);
  };

  const visibleRequests = useMemo(() => {
    const query = searchText.trim().toLocaleLowerCase('fa-IR');
    return requests.filter((request) => {
      const text = [request.title, request.category_name, request.category, request.province, request.description]
        .filter(Boolean).join(' ').toLocaleLowerCase('fa-IR');
      const matchesSearch = !query || text.includes(query);
      const category = `${request.category_name ?? ''} ${request.category ?? ''}`;
      const matchesCategory = !activeCategory || activeCategory === 'سایر'
        ? !activeCategory || !CATEGORIES.slice(0, -1).some((item) => category.includes(item.title))
        : category.includes(activeCategory);
      return matchesSearch && matchesCategory;
    });
  }, [activeCategory, requests, searchText]);

  const loadRequests = useCallback(async (refresh = false) => {
    refresh ? setRefreshing(true) : setLoading(true);
    setError(null);
    try {
      const result = await api.getOpenRequests();
      setRequests(getRequests(result));
    } catch (cause) {
      if (cause instanceof ApiError && cause.code === 'auth') {
        logout();
        return;
      }
      setError(cause instanceof ApiError ? cause.message : 'دریافت درخواست‌ها با خطا روبه‌رو شد.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [logout]);

  useEffect(() => { void loadRequests(); }, [loadRequests]);

  const renderRequest = ({ item }: { item: OpenRequest }) => {
    const firstFile = item.files?.find((file) => {
      const url = typeof file === 'string' ? file : file.url ?? file.path;
      const type = typeof file === 'string' ? '' : file.type ?? file.ext ?? '';
      return Boolean(url) && (/image/i.test(type) || /\.(png|jpe?g|webp|gif)(?:\?|$)/i.test(url ?? ''));
    });
    const imagePath = firstFile ? (typeof firstFile === 'string' ? firstFile : firstFile.url ?? firstFile.path) : undefined;
    const image = mediaUrl(imagePath);
    const hasImage = Boolean(image && !failedImages.has(String(item.id)));
    return (
    <Pressable onPress={() => navigation.navigate('RequestDetail', { requestId: item.id })} style={({ pressed }) => [styles.requestCard, pressed && styles.cardPressed]}>
      <View style={styles.cardContentRow}>
      {hasImage ? <Image source={{ uri: image }} resizeMode="cover" onError={() => setFailedImages((old) => new Set(old).add(String(item.id)))} style={styles.requestThumbnail} /> : <View style={styles.requestThumbnailFallback}><MaterialCommunityIcons name="image-outline" size={22} color={COLORS.muted} /></View>}
      <View style={styles.requestContent}>
      <View style={styles.cardTop}>
        <View style={styles.openBadge}><View style={styles.openDot} /><Text style={styles.openText}>باز</Text></View>
        <Text style={styles.categoryTag} numberOfLines={1}>{item.category_name ?? item.category ?? 'دسته‌بندی نشده'}</Text>
      </View>
      <Text style={styles.requestTitle} numberOfLines={2}>{item.title || 'درخواست بدون عنوان'}</Text>
      <View style={styles.cardMeta}>
        <View style={styles.metaItem}><MaterialCommunityIcons name="map-marker-outline" size={16} color={COLORS.muted} /><Text style={styles.metaText} numberOfLines={1}>{item.province || 'استان نامشخص'}</Text></View>
        <View style={styles.metaDivider} />
        <View style={styles.metaItem}><MaterialCommunityIcons name="weight-kilogram" size={16} color={COLORS.muted} /><Text style={styles.metaText} numberOfLines={1}>{item.quantity ?? '—'} {item.unit ?? ''}</Text></View>
      </View>
      <View style={styles.cardBottom}><Text style={styles.cardHint}>مشاهدهٔ جزئیات</Text><MaterialCommunityIcons name="arrow-left" size={16} color={COLORS.primaryDark} /></View>
      </View>
      </View>
    </Pressable>
    );
  };

  const listHeader = (
    <>
      <View style={styles.hero}>
        <View style={styles.heroDecoration} />
        <Text style={styles.heroEyebrow}>تنها پلتفرم تخصصی تأمین کالا</Text>
        <Text style={styles.heroTitle}>چی میخوای؟</Text>
        <Text style={styles.heroCopy}>درخواستت را ثبت کن، پیشنهادهای مناسب را بگیر.</Text>
        <View style={styles.searchBox}>
          <MaterialCommunityIcons name="magnify" size={22} color={COLORS.primaryDark} />
          <TextInput value={searchText} onChangeText={setSearchText} placeholder="جست‌وجوی کالا یا درخواست..." placeholderTextColor="#A8A29E" style={styles.searchInput} textAlign="right" returnKeyType="search" />
          <Pressable accessibilityLabel="پاک‌کردن جست‌وجو و دسته‌بندی" onPress={() => { setSearchText(''); setActiveCategory(null); }} style={styles.searchFilter}><MaterialCommunityIcons name={searchText || activeCategory ? 'close' : 'tune-variant'} size={18} color="#fff" /></Pressable>
        </View>
      </View>
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>دسته‌بندی‌ها</Text>
        <Text style={styles.sectionKicker}>انتخاب حوزه</Text>
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.categoriesRow}>
        {CATEGORIES.map((category) => (
          <Pressable key={category.title} onPress={() => setActiveCategory((active) => active === category.title ? null : category.title)} style={styles.categoryItem}>
            <View style={[styles.categoryIcon, activeCategory === category.title && styles.categoryIconActive]}><MaterialCommunityIcons name={category.icon} size={22} color={COLORS.primaryDark} /></View>
            <Text style={styles.categoryName}>{category.title}</Text>
          </Pressable>
        ))}
      </ScrollView>
      <View style={[styles.sectionHeader, styles.requestsHeading]}>
        <View style={styles.countPill}><Text style={styles.countText}>{visibleRequests.length.toLocaleString('fa-IR')} درخواست</Text></View>
        <View><Text style={styles.sectionTitle}>آخرین درخواست‌ها</Text><Text style={styles.sectionKicker}>فرصت‌های تازهٔ بازار</Text></View>
      </View>
    </>
  );

  let emptyContent: React.ReactElement | null = null;
  if (loading && requests.length === 0) {
    emptyContent = <View style={styles.stateBox}><ActivityIndicator size="large" color={COLORS.primary} /><Text style={styles.stateText}>در حال دریافت درخواست‌ها...</Text></View>;
  } else if (error) {
    emptyContent = <View style={styles.stateBox}><MaterialCommunityIcons name="cloud-alert-outline" size={32} color={COLORS.danger} /><Text style={styles.stateTitle}>بارگذاری انجام نشد</Text><Text style={styles.stateText}>{error}</Text><Pressable onPress={() => void loadRequests()} style={styles.retryButton}><Text style={styles.retryText}>تلاش دوباره</Text></Pressable></View>;
  } else if (visibleRequests.length === 0) {
    const filtered = Boolean(searchText.trim() || activeCategory);
    emptyContent = <View style={styles.stateBox}><MaterialCommunityIcons name={filtered ? 'filter-remove-outline' : 'inbox-outline'} size={32} color={COLORS.muted} /><Text style={styles.stateTitle}>{filtered ? 'نتیجه‌ای پیدا نشد' : 'هنوز درخواستی ثبت نشده'}</Text><Text style={styles.stateText}>{filtered ? 'عبارت جست‌وجو یا دسته‌بندی دیگری را امتحان کنید.' : 'بعداً دوباره سر بزنید؛ درخواست‌های تازه اینجا نمایش داده می‌شوند.'}</Text></View>;
  }

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <View style={styles.topBar}>
        <View style={styles.logoRow}><Image source={require('../../assets/app-icon.png')} resizeMode="contain" style={styles.logoImage} /><View><Text style={styles.logoTitle}>چی میخوای</Text><Text style={styles.logoCaption}>تأمین کالا</Text></View></View>
        <Pressable accessibilityLabel="تنظیمات و اطلاعات" onPress={() => setMenuVisible(true)} style={styles.menuButton}><MaterialCommunityIcons name="menu-open" size={19} color={COLORS.primaryDark} /><Text style={styles.menuButtonText}>بیشتر</Text></Pressable>
      </View>
      <FlatList
        data={visibleRequests}
        keyExtractor={(item, index) => String(item.id ?? index)}
        renderItem={renderRequest}
        ListHeaderComponent={listHeader}
        ListEmptyComponent={emptyContent}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => void loadRequests(true)} tintColor={COLORS.primary} colors={[COLORS.primary]} />}
      />
      <Modal visible={menuVisible} transparent animationType="fade" onRequestClose={() => setMenuVisible(false)}>
        <View style={styles.menuBackdrop}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setMenuVisible(false)} accessibilityLabel="بستن منو" />
          <View style={styles.menuSheet}>
            <View style={styles.menuHeader}><Pressable onPress={() => setMenuVisible(false)} style={styles.menuClose}><MaterialCommunityIcons name="close" size={20} color={COLORS.text} /></Pressable><View style={styles.menuHeaderCopy}><Text style={styles.menuTitle}>دسترسی‌های سریع</Text><Text style={styles.menuSubtitle}>تنظیمات و اطلاعات چی میخوای</Text></View></View>
            <Pressable onPress={() => openDashboard('Settings')} style={styles.menuRow}><View style={styles.menuIcon}><MaterialCommunityIcons name="cog-outline" size={19} color={COLORS.primaryDark} /></View><View style={styles.menuCopy}><Text style={styles.menuItemTitle}>تنظیمات حساب</Text><Text style={styles.menuItemHint}>اعلان‌ها و گزینه‌های حساب</Text></View><MaterialCommunityIcons name="chevron-left" size={19} color={COLORS.muted} /></Pressable>
            <View style={styles.menuDivider} />
            <Pressable onPress={() => openSite(ABOUT_PAGE)} style={styles.menuRow}><View style={styles.menuIcon}><MaterialCommunityIcons name="information-outline" size={19} color={COLORS.primaryDark} /></View><View style={styles.menuCopy}><Text style={styles.menuItemTitle}>دربارهٔ ما</Text><Text style={styles.menuItemHint}>ایده و روش کار چی میخوای</Text></View><MaterialCommunityIcons name="chevron-left" size={16} color={COLORS.muted} /></Pressable>
            <Pressable onPress={() => openSite(SUPPORT_PAGE)} style={styles.menuRow}><View style={styles.menuIcon}><MaterialCommunityIcons name="help-circle-outline" size={19} color={COLORS.primaryDark} /></View><View style={styles.menuCopy}><Text style={styles.menuItemTitle}>پشتیبانی و پرسش‌های متداول</Text><Text style={styles.menuItemHint}>پاسخ پرسش‌های رایج</Text></View><MaterialCommunityIcons name="chevron-left" size={16} color={COLORS.muted} /></Pressable>
            <Pressable onPress={() => openSite(CONTACT_PAGE)} style={styles.menuRow}><View style={styles.menuIcon}><MaterialCommunityIcons name="phone-outline" size={19} color={COLORS.primaryDark} /></View><View style={styles.menuCopy}><Text style={styles.menuItemTitle}>تماس با ما</Text><Text style={styles.menuItemHint}>آدرس، تلفن و ایمیل پشتیبانی</Text></View><MaterialCommunityIcons name="chevron-left" size={16} color={COLORS.muted} /></Pressable>
            <Pressable onPress={() => openSite(TERMS_PAGE)} style={styles.menuRow}><View style={styles.menuIcon}><MaterialCommunityIcons name="file-document-outline" size={19} color={COLORS.primaryDark} /></View><View style={styles.menuCopy}><Text style={styles.menuItemTitle}>قوانین و مقررات</Text><Text style={styles.menuItemHint}>حقوق و تعهدات کاربران</Text></View><MaterialCommunityIcons name="chevron-left" size={16} color={COLORS.muted} /></Pressable>
            <Pressable onPress={() => openSite(PRIVACY_PAGE)} style={styles.menuRow}><View style={styles.menuIcon}><MaterialCommunityIcons name="shield-lock-outline" size={19} color={COLORS.primaryDark} /></View><View style={styles.menuCopy}><Text style={styles.menuItemTitle}>حریم خصوصی</Text><Text style={styles.menuItemHint}>اطلاعات شما چگونه محافظت می‌شود</Text></View><MaterialCommunityIcons name="chevron-left" size={16} color={COLORS.muted} /></Pressable>
            <Pressable onPress={() => openSite(ENAMAD_PAGE)} style={styles.menuRow}><View style={styles.menuIcon}><MaterialCommunityIcons name="check-decagram-outline" size={19} color={COLORS.primaryDark} /></View><View style={styles.menuCopy}><Text style={styles.menuItemTitle}>نماد اعتماد (اینماد)</Text><Text style={styles.menuItemHint}>تعهدات ما در برابر شما</Text></View><MaterialCommunityIcons name="chevron-left" size={16} color={COLORS.muted} /></Pressable>
          </View>
        </View>
      </Modal>
      <Modal visible={Boolean(sitePage)} animationType="slide" onRequestClose={() => setSitePage(null)}>
        <SafeAreaView style={styles.siteModal} edges={['top', 'bottom']}>
          <View style={styles.siteHeader}>
            <Pressable onPress={() => setSitePage(null)} style={styles.siteClose} accessibilityLabel="بازگشت"><MaterialCommunityIcons name="arrow-right" size={21} color={COLORS.text} /></Pressable>
            <View style={styles.siteHeaderCopy}><Text style={styles.siteTitle}>{sitePage?.title ?? ''}</Text><Text style={styles.siteSubtitle}>چی میخوای · تأمین کالا</Text></View>
            <View style={styles.siteClose} />
          </View>
          <ScrollView style={styles.siteBody} contentContainerStyle={styles.siteContent} showsVerticalScrollIndicator={false}>
            {sitePage?.intro ? <View style={styles.siteIntro}><Text style={styles.siteIntroText}>{sitePage.intro}</Text></View> : null}
            {(sitePage?.sections ?? []).map((section, index) => (
              <View key={`${section.heading ?? 'section'}-${index}`} style={styles.siteSection}>
                {section.heading ? <View style={styles.siteHeadingRow}><View style={styles.siteHeadingDot} /><Text style={styles.siteHeading}>{section.heading}</Text></View> : null}
                {section.body ? (section.body === SUPPORT_EMAIL
                  ? <Pressable onPress={emailSupport}><Text selectable style={[styles.siteText, styles.siteLink]}>{section.body}</Text></Pressable>
                  : <Text selectable style={styles.siteText}>{section.body}</Text>) : null}
                {section.bullets?.map((bullet) => <View key={bullet} style={styles.siteBulletRow}><Text selectable style={[styles.siteText, styles.siteBulletText]}>{bullet}</Text><MaterialCommunityIcons name="check-circle-outline" size={16} color={COLORS.primaryDark} style={styles.siteBulletIcon} /></View>)}
              </View>
            ))}
            <Pressable onPress={emailSupport} style={styles.siteFooter}><MaterialCommunityIcons name="email-outline" size={17} color={COLORS.primaryDark} /><Text style={styles.siteFooterText}>{`پرسش دیگری دارید؟ ${SUPPORT_EMAIL}`}</Text></Pressable>
          </ScrollView>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.background },
  topBar: { minHeight: 62, paddingHorizontal: 20, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', backgroundColor: COLORS.background, borderBottomWidth: 1, borderBottomColor: '#EEEAE1' },
  logoRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 10 },
  logoImage: { width: 42, height: 42, borderRadius: 12, backgroundColor: '#fff' },
  logoTitle: { fontFamily: 'VazirmatnBold', fontSize: 16, textAlign: 'right', color: COLORS.text },
  logoCaption: { fontFamily: 'Vazirmatn', fontSize: 9, textAlign: 'right', color: COLORS.muted, marginTop: -2 },
  menuButton: { minHeight: 38, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', gap: 5, paddingHorizontal: 10, borderRadius: 13, backgroundColor: '#fff', borderWidth: 1, borderColor: COLORS.border },
  menuButtonText: { fontFamily: 'VazirmatnMedium', fontSize: 9, color: COLORS.primaryDark },
  menuBackdrop: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(20,18,15,0.48)' },
  menuSheet: { maxHeight: '86%', paddingHorizontal: 16, paddingTop: 13, paddingBottom: 24, borderTopLeftRadius: 24, borderTopRightRadius: 24, backgroundColor: COLORS.background },
  menuHeader: { flexDirection: 'row-reverse', alignItems: 'center', gap: 10, paddingBottom: 10 },
  menuClose: { width: 35, height: 35, alignItems: 'center', justifyContent: 'center', borderRadius: 12, backgroundColor: '#fff', borderWidth: 1, borderColor: COLORS.border },
  menuHeaderCopy: { flex: 1 },
  menuTitle: { fontFamily: 'VazirmatnBold', fontSize: 13, color: COLORS.text, textAlign: 'right' },
  menuSubtitle: { fontFamily: 'Vazirmatn', fontSize: 8, color: COLORS.muted, textAlign: 'right', marginTop: 2 },
  menuRow: { minHeight: 49, flexDirection: 'row-reverse', alignItems: 'center', gap: 9, paddingHorizontal: 8, borderRadius: 12 },
  menuIcon: { width: 34, height: 34, borderRadius: 11, alignItems: 'center', justifyContent: 'center', backgroundColor: '#F4E9C9' },
  menuCopy: { flex: 1 },
  menuItemTitle: { fontFamily: 'VazirmatnMedium', fontSize: 9, color: COLORS.text, textAlign: 'right' },
  menuItemHint: { fontFamily: 'Vazirmatn', fontSize: 7, color: COLORS.muted, textAlign: 'right', marginTop: 1 },
  menuDivider: { height: 1, backgroundColor: '#E7E5E4', marginVertical: 7 },
  siteModal: { flex: 1, backgroundColor: '#fff' },
  siteHeader: { minHeight: 58, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', gap: 9, paddingHorizontal: 14, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: COLORS.border },
  siteClose: { width: 36, height: 36, borderRadius: 12, backgroundColor: COLORS.background, alignItems: 'center', justifyContent: 'center' },
  siteHeaderCopy: { flex: 1 },
  siteTitle: { fontFamily: 'VazirmatnBold', fontSize: 12, color: COLORS.text, textAlign: 'right' },
  siteSubtitle: { fontFamily: 'Vazirmatn', fontSize: 8, color: COLORS.muted, textAlign: 'right', marginTop: 1 },
  siteBody: { flex: 1, backgroundColor: '#fff' },
  siteContent: { paddingHorizontal: 20, paddingTop: 18, paddingBottom: 30 },
  siteIntro: { padding: 15, borderRadius: 18, backgroundColor: '#211B10', marginBottom: 16 },
  siteIntroText: { fontFamily: 'VazirmatnMedium', fontSize: 12, lineHeight: 24, color: '#FFFDF6', textAlign: 'right', writingDirection: 'rtl' },
  siteSection: { marginBottom: 17 },
  siteHeadingRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 7, marginBottom: 7 },
  siteHeadingDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: COLORS.primary },
  siteHeading: { flex: 1, fontFamily: 'VazirmatnBold', fontSize: 13, color: COLORS.text, textAlign: 'right' },
  siteBulletRow: { flexDirection: 'row-reverse', alignItems: 'flex-start', gap: 7, marginTop: 4 },
  siteBulletIcon: { marginTop: 5 },
  siteBulletText: { flex: 1 },
  siteLink: { color: COLORS.primaryDark, textDecorationLine: 'underline' },
  siteFooter: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', gap: 7, marginTop: 6, padding: 12, borderRadius: 14, backgroundColor: '#FFFBEB', borderWidth: 1, borderColor: '#F4E9C9' },
  siteFooterText: { fontFamily: 'VazirmatnMedium', fontSize: 10, color: COLORS.primaryDark },
  siteText: { fontFamily: 'Vazirmatn', fontSize: 12, lineHeight: 27, color: COLORS.text, textAlign: 'right', writingDirection: 'rtl' },
  listContent: { paddingBottom: 20 },
  hero: { marginHorizontal: 18, marginTop: 17, marginBottom: 23, padding: 19, borderRadius: 23, backgroundColor: '#211B10', overflow: 'hidden' },
  heroDecoration: { position: 'absolute', width: 170, height: 170, borderRadius: 85, borderWidth: 1, borderColor: 'rgba(212,160,23,0.22)', top: -94, left: -48 },
  heroEyebrow: { fontFamily: 'VazirmatnMedium', fontSize: 10, color: '#E4C66C', textAlign: 'right' },
  heroTitle: { fontFamily: 'VazirmatnBold', fontSize: 27, color: '#FFFDF6', textAlign: 'right', marginTop: 2 },
  heroCopy: { fontFamily: 'Vazirmatn', fontSize: 11, color: '#D6D3D1', textAlign: 'right', marginTop: 1, marginBottom: 15 },
  searchBox: { flexDirection: 'row-reverse', alignItems: 'center', gap: 8, minHeight: 48, backgroundColor: '#fff', borderRadius: 14, paddingHorizontal: 11 },
  searchInput: { flex: 1, fontFamily: 'Vazirmatn', fontSize: 11, paddingVertical: 9, color: COLORS.text },
  searchFilter: { width: 32, height: 32, borderRadius: 10, backgroundColor: COLORS.primaryDark, alignItems: 'center', justifyContent: 'center' },
  sectionHeader: { paddingHorizontal: 20, flexDirection: 'row-reverse', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  sectionTitle: { fontFamily: 'VazirmatnBold', fontSize: 15, textAlign: 'right', color: COLORS.text },
  sectionKicker: { fontFamily: 'Vazirmatn', fontSize: 10, textAlign: 'right', color: COLORS.muted, marginTop: 1 },
  categoriesRow: { paddingHorizontal: 18, flexDirection: 'row-reverse', gap: 10, paddingBottom: 23 },
  categoryItem: { width: 76, alignItems: 'center', gap: 6 },
  categoryIcon: { width: 54, height: 54, borderRadius: 18, backgroundColor: '#F4E9C9', alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: '#EADAA9' },
  categoryIconActive: { backgroundColor: '#E4C66C', borderColor: COLORS.primaryDark, borderWidth: 2 },
  categoryName: { fontFamily: 'Vazirmatn', fontSize: 9, color: COLORS.text, textAlign: 'center' },
  requestsHeading: { marginTop: 1, marginBottom: 12 },
  countPill: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20, backgroundColor: '#F5F5F4' },
  countText: { fontFamily: 'VazirmatnMedium', fontSize: 9, color: COLORS.muted },
  requestCard: { backgroundColor: COLORS.surface, borderRadius: 18, borderWidth: 1, borderColor: '#EAE6DC', padding: 15, marginHorizontal: 18, marginBottom: 11, shadowColor: '#292524', shadowOpacity: 0.035, shadowRadius: 8, shadowOffset: { width: 0, height: 3 }, elevation: 1 },
  cardContentRow: { flexDirection: 'row-reverse', alignItems: 'flex-start', gap: 11 },
  requestContent: { flex: 1, minWidth: 0 },
  requestThumbnail: { width: 82, height: 82, borderRadius: 13, backgroundColor: '#E7E5E4' },
  requestThumbnailFallback: { width: 82, height: 82, borderRadius: 13, backgroundColor: '#F5F5F4', alignItems: 'center', justifyContent: 'center' },
  cardPressed: { opacity: 0.82, transform: [{ scale: 0.99 }] },
  cardTop: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between' },
  openBadge: { flexDirection: 'row-reverse', alignItems: 'center', gap: 5, backgroundColor: '#DCFCE7', paddingHorizontal: 9, paddingVertical: 4, borderRadius: 20 },
  openDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: COLORS.success },
  openText: { fontFamily: 'VazirmatnBold', fontSize: 9, color: '#15803D' },
  categoryTag: { fontFamily: 'VazirmatnMedium', fontSize: 10, color: COLORS.primaryDark, backgroundColor: '#FFFBEB', paddingHorizontal: 9, paddingVertical: 4, borderRadius: 9, maxWidth: '70%' },
  requestTitle: { fontFamily: 'VazirmatnBold', fontSize: 14, textAlign: 'right', color: COLORS.text, marginTop: 12, marginBottom: 11 },
  cardMeta: { flexDirection: 'row-reverse', alignItems: 'center', gap: 12 },
  metaItem: { flexDirection: 'row-reverse', alignItems: 'center', gap: 4, flexShrink: 1 },
  metaText: { fontFamily: 'Vazirmatn', fontSize: 10, color: COLORS.muted },
  metaDivider: { width: 1, height: 14, backgroundColor: COLORS.border },
  cardBottom: { marginTop: 12, paddingTop: 9, borderTopWidth: 1, borderTopColor: '#F5F5F4', flexDirection: 'row-reverse', alignItems: 'center', gap: 4 },
  cardHint: { fontFamily: 'VazirmatnMedium', color: COLORS.primaryDark, fontSize: 10 },
  stateBox: { marginHorizontal: 18, marginTop: 6, marginBottom: 20, alignItems: 'center', justifyContent: 'center', minHeight: 155, padding: 20, backgroundColor: '#fff', borderRadius: 18, borderWidth: 1, borderColor: COLORS.border, gap: 8 },
  stateTitle: { fontFamily: 'VazirmatnBold', color: COLORS.text, fontSize: 13, textAlign: 'center' },
  stateText: { fontFamily: 'Vazirmatn', color: COLORS.muted, fontSize: 11, textAlign: 'center', lineHeight: 19 },
  retryButton: { marginTop: 4, borderRadius: 11, backgroundColor: COLORS.primaryDark, paddingHorizontal: 17, paddingVertical: 8 },
  retryText: { fontFamily: 'VazirmatnBold', color: '#fff', fontSize: 11 },
});
