import React, { useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Alert, Linking, Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { WebView, type WebViewNavigation } from 'react-native-webview';
import type { PricingStackParamList } from '../navigation/PricingStackNavigator';
import { COLORS } from '../theme/colors';

type Props = NativeStackScreenProps<PricingStackParamList, 'Checkout'>;

const HIDE_SITE_CHROME = `
(function(){
  var css = 'header,#header,#site-header,.site-header,.main-header,.mobile-header,.desktop-header,.navbar,.site-navbar,.main-nav,.site-nav,.top-nav,.topbar,.top-bar,[data-site-header],nav,[role="navigation"],footer,#footer,#site-footer,.site-footer,.main-footer,.mobile-bottom-nav,.mobileBottomNav,.bottom-nav,.bottomNav,.bottom-navigation,.bottomNavigation,.tab-bar,.tabBar,#mobile-bottom-nav,#mobileBottomNav,#bottom-nav,#bottomNav,[data-mobile-bottom-nav],[class*="sticky-bottom"],[id*="sticky-bottom"],.fixed.bottom-0,.fixed.inset-x-0{display:none!important;visibility:hidden!important;height:0!important;max-height:0!important;min-height:0!important;pointer-events:none!important}body{padding-bottom:0!important;padding-top:0!important;margin-bottom:0!important;margin-top:0!important}';
  function apply(){
    if(!document.documentElement) return;
    var id='chimikhayi-app-webview-chrome';
    var style=document.getElementById(id);
    if(!style){style=document.createElement('style');style.id=id;(document.head||document.documentElement).appendChild(style);}
    style.textContent=css;
    document.querySelectorAll('header,nav,[role="navigation"],footer,#header,#site-header,#footer,#site-footer,.navbar,.site-navbar,.main-nav,.site-nav,.mobile-bottom-nav,.mobileBottomNav,.bottom-nav,.bottomNav,.bottom-navigation,.bottomNavigation,.tab-bar,.tabBar,.fixed.bottom-0,.fixed.inset-x-0,[class*="sticky-bottom"],[id*="sticky-bottom"]').forEach(function(el){
      var r=el.getBoundingClientRect(), s=getComputedStyle(el);
      if(el.tagName==='HEADER'||el.tagName==='FOOTER'||el.tagName==='NAV'||el.getAttribute('role')==='navigation'||s.position==='fixed'||s.position==='sticky') el.remove();
    });
    document.body && document.body.style.setProperty('padding-bottom','0','important');
    document.body && document.body.style.setProperty('padding-top','0','important');
  }
  apply();
  if(document.documentElement)new MutationObserver(apply).observe(document.documentElement,{childList:true,subtree:true});
  document.addEventListener('DOMContentLoaded',apply,{once:true});
  window.addEventListener('load',apply);
})();true;
`;

export function PaymentCheckoutScreen({ route, navigation }: Props) {
  const webRef = useRef<WebView>(null);
  const loadTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const [loading, setLoading] = useState(true);
  const [pageError, setPageError] = useState(false);
  const [host, setHost] = useState('chimikhayi.ir');
  const [started, setStarted] = useState(false);
  const { planName, price } = route.params;
  const priceText = useMemo(() => Number(price).toLocaleString('fa-IR'), [price]);

  useEffect(() => () => { if (loadTimer.current) clearTimeout(loadTimer.current); }, []);

  const handleLoadStart = () => {
    if (loadTimer.current) clearTimeout(loadTimer.current);
    setLoading(true);
    setPageError(false);
    loadTimer.current = setTimeout(() => { setLoading(false); setPageError(true); }, 30000);
  };

  const handleLoadEnd = () => {
    if (loadTimer.current) clearTimeout(loadTimer.current);
    loadTimer.current = null;
    setLoading(false);
    setPageError(false);
  };

  const startPayment = () => {
    const plan = JSON.stringify(planName);
    const amount = Math.round(Number(price));
    webRef.current?.injectJavaScript(`(function(){
      if (typeof window.goToPayment !== 'function' || typeof window.redirectToBitpay !== 'function') {
        window.ReactNativeWebView && window.ReactNativeWebView.postMessage(JSON.stringify({type:'payment-unavailable'}));
        return true;
      }
      window.goToPayment(${plan}, ${amount});
      window.setTimeout(function(){
        var button=document.getElementById('btn-final-pay');
        var selected=button && Number(button.getAttribute('data-amount'))===${amount};
        if(selected){ button.click(); }
        else if(window.ReactNativeWebView){ window.ReactNativeWebView.postMessage(JSON.stringify({type:'payment-login-required'})); }
      },250);
      return true;
    })(); true;`);
    setStarted(true);
  };

  const onNavigationStateChange = (state: WebViewNavigation) => {
    try { setHost(new URL(state.url).host || 'chimikhayi.ir'); } catch { setHost('chimikhayi.ir'); }
  };

  const shouldStartNavigation = (request: { url: string }) => {
    const target = request.url;
    if (target === 'about:blank' || target.startsWith('data:') || target.startsWith('blob:')) return true;
    try {
      const destination = new URL(target);
      const internalHost = destination.hostname === 'chimikhayi.ir' || destination.hostname === 'www.chimikhayi.ir';
      if (destination.protocol === 'https:' && internalHost) return true;
      if (destination.protocol === 'http:' && internalHost) {
        const secureUrl = `https://chimikhayi.ir${destination.pathname}${destination.search}${destination.hash}`;
        webRef.current?.injectJavaScript(`window.location.replace(${JSON.stringify(secureUrl)}); true;`);
        return false;
      }
      if (destination.protocol === 'https:' || destination.protocol === 'http:' || destination.protocol === 'tel:' || destination.protocol === 'mailto:') {
        setLoading(false);
        openExternal(target);
      }
    } catch {
      return false;
    }
    return false;
  };

  const openExternal = (url: string) => {
    try {
      const protocol = new URL(url).protocol;
      if (!['https:', 'http:', 'tel:', 'mailto:'].includes(protocol)) return;
      void Linking.openURL(url).catch(() => Alert.alert('بازکردن پیوند انجام نشد', 'مرورگر یا برنامهٔ مقصد در دسترس نیست.'));
    } catch {
      // Ignore non-URL window requests.
    }
  };

  const handleOpenWindow = (url: string) => {
    try {
      const target = new URL(url);
      if (target.protocol === 'https:' && ['chimikhayi.ir', 'www.chimikhayi.ir'].includes(target.hostname)) {
        webRef.current?.injectJavaScript(`window.location.href=${JSON.stringify(url)}; true;`);
        return;
      }
    } catch { /* Invalid targets are handled by openExternal. */ }
    openExternal(url);
  };

  const handleWebMessage = (event: { nativeEvent: { data: string } }) => {
    try {
      const message = JSON.parse(event.nativeEvent.data) as { type?: string };
      if (message.type === 'payment-login-required') {
        Alert.alert('ورود به وب‌سایت لازم است', 'برای ادامهٔ پرداخت، ابتدا در وب‌سایت chimikhayi.ir با حساب تأمین‌کننده وارد شوید. نشست ورود برنامه و وب‌سایت جداست.');
      } else if (message.type === 'payment-unavailable') {
        Alert.alert('پرداخت در دسترس نیست', 'درگاه پرداخت در سمت وب‌سایت آماده نیست. لطفاً پس از فعال‌شدن درگاه دوباره تلاش کنید.');
      }
    } catch { /* Ignore unrelated page messages. */ }
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} style={styles.backButton} accessibilityLabel="بازگشت"><MaterialCommunityIcons name="arrow-right" size={22} color={COLORS.text} /></Pressable>
        <View style={styles.headerCopy}><Text style={styles.title}>پرداخت اشتراک</Text><Text style={styles.subtitle}>اتصال امن به وب‌سایت {host}</Text></View>
        <View style={styles.secureIcon}><MaterialCommunityIcons name="lock-check-outline" size={19} color={COLORS.success} /></View>
      </View>
      <View style={styles.planBar}><View><Text style={styles.planLabel}>پلن {planName}</Text><Text style={styles.planHint}>قیمت پایه · مالیات در مرحلهٔ پرداخت محاسبه می‌شود</Text></View><Text style={styles.price}>{priceText} تومان</Text></View>
      {pageError ? (
        <View style={styles.errorState}><MaterialCommunityIcons name="cloud-alert-outline" size={36} color={COLORS.danger} /><Text style={styles.errorTitle}>صفحهٔ پرداخت بارگذاری نشد</Text><Text style={styles.errorText}>اتصال اینترنت را بررسی و دوباره تلاش کنید.</Text><Pressable onPress={() => { setPageError(false); setLoading(true); webRef.current?.reload(); }} style={styles.retryButton}><Text style={styles.retryText}>تلاش دوباره</Text></Pressable></View>
      ) : (
        <View style={styles.webViewWrap}>
          <WebView
            ref={webRef}
            source={{ uri: 'https://chimikhayi.ir/#pricing' }}
            javaScriptEnabled
            domStorageEnabled
            sharedCookiesEnabled
            thirdPartyCookiesEnabled
            onLoadStart={handleLoadStart}
            onLoadEnd={handleLoadEnd}
            onError={() => { setLoading(false); setPageError(true); }}
            onHttpError={(event) => { if (event.nativeEvent.statusCode >= 500) setPageError(true); }}
            onNavigationStateChange={onNavigationStateChange}
            onShouldStartLoadWithRequest={shouldStartNavigation}
            onOpenWindow={(event) => handleOpenWindow(event.nativeEvent.targetUrl)}
            onMessage={handleWebMessage}
            injectedJavaScriptBeforeContentLoaded={HIDE_SITE_CHROME}
            injectedJavaScript={HIDE_SITE_CHROME}
            startInLoadingState
            renderLoading={() => <View style={styles.webLoading}><ActivityIndicator size="large" color={COLORS.primary} /></View>}
            setSupportMultipleWindows={false}
            allowsBackForwardNavigationGestures
          />
          {loading ? <View pointerEvents="none" style={styles.loadingCover}><ActivityIndicator size="small" color={COLORS.primaryDark} /><Text style={styles.loadingText}>در حال اتصال به صفحهٔ تعرفه‌ها...</Text></View> : null}
        </View>
      )}
      <View style={styles.footer}>
        <Text style={styles.footerHint}>{started ? 'اگر وب‌سایت درخواست ورود کرد، وارد همان حساب شوید و دوباره ادامه دهید.' : 'برای ادامه، نشست وب‌سایت شما بررسی می‌شود. دامنهٔ مقصد در بالای صفحه نمایش داده شده است.'}</Text>
        <Pressable onPress={startPayment} disabled={loading || pageError} style={({ pressed }) => [styles.continueButton, (loading || pageError) && styles.disabled, pressed && !loading && { opacity: 0.88 }]}>
          <MaterialCommunityIcons name="shield-lock-outline" size={18} color="#fff" />
          <Text style={styles.continueText}>ادامهٔ پرداخت پلن {planName}</Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.background },
  header: { minHeight: 58, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', gap: 10, paddingHorizontal: 15, borderBottomWidth: 1, borderBottomColor: '#EEEAE1', backgroundColor: '#fff' },
  backButton: { width: 37, height: 37, borderRadius: 13, backgroundColor: COLORS.background, borderWidth: 1, borderColor: COLORS.border, alignItems: 'center', justifyContent: 'center' },
  headerCopy: { flex: 1 },
  title: { fontFamily: 'VazirmatnBold', fontSize: 13, color: COLORS.text, textAlign: 'right' },
  subtitle: { fontFamily: 'Vazirmatn', fontSize: 8, color: COLORS.muted, textAlign: 'right', marginTop: 2 },
  secureIcon: { width: 34, height: 34, borderRadius: 12, alignItems: 'center', justifyContent: 'center', backgroundColor: '#ECFDF5' },
  planBar: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 15, paddingVertical: 11, backgroundColor: '#FFFBEB', borderBottomWidth: 1, borderBottomColor: '#F4E9C9' },
  planLabel: { fontFamily: 'VazirmatnBold', fontSize: 10, color: COLORS.text, textAlign: 'right' },
  planHint: { fontFamily: 'Vazirmatn', fontSize: 7, color: COLORS.muted, textAlign: 'right', marginTop: 2 },
  price: { fontFamily: 'VazirmatnBold', fontSize: 11, color: COLORS.primaryDark },
  webViewWrap: { flex: 1, backgroundColor: '#fff' },
  webLoading: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  loadingCover: { position: 'absolute', left: 0, right: 0, top: 0, height: 44, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: 'rgba(255,255,255,0.92)' },
  loadingText: { fontFamily: 'Vazirmatn', fontSize: 9, color: COLORS.muted },
  errorState: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 9, padding: 24 },
  errorTitle: { fontFamily: 'VazirmatnBold', fontSize: 13, color: COLORS.text },
  errorText: { fontFamily: 'Vazirmatn', fontSize: 10, color: COLORS.muted, textAlign: 'center' },
  retryButton: { marginTop: 3, paddingHorizontal: 17, paddingVertical: 9, borderRadius: 11, backgroundColor: COLORS.primaryDark },
  retryText: { fontFamily: 'VazirmatnBold', fontSize: 10, color: '#fff' },
  footer: { padding: 12, borderTopWidth: 1, borderTopColor: COLORS.border, backgroundColor: '#fff' },
  footerHint: { fontFamily: 'Vazirmatn', fontSize: 8, lineHeight: 16, color: COLORS.muted, textAlign: 'right', marginBottom: 8 },
  continueButton: { minHeight: 46, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', gap: 8, borderRadius: 13, backgroundColor: COLORS.primaryDark },
  continueText: { fontFamily: 'VazirmatnBold', fontSize: 10, color: '#fff' },
  disabled: { opacity: 0.55 },
});
