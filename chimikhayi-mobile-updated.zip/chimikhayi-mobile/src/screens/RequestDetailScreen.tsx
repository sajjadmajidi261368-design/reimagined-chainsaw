import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Alert, Image, Linking, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ApiError, api, type MyOfferItem, type RequestDetailResult, type RequestDetails, type RequestFile, type RequestOffer } from '../api/api';
import { mediaUrl } from '../api/media';
import type { HomeStackParamList } from '../navigation/HomeStackNavigator';
import { useAuthStore } from '../store/authStore';
import { isSupplierSide } from '../utils/roles';
import { COLORS } from '../theme/colors';
import { extractArray } from '../utils/collections';
import { registerDraftThread } from '../utils/chatLocal';

type Props = NativeStackScreenProps<HomeStackParamList, 'RequestDetail'>;

function normalizeResult(result: RequestDetailResult): { request: RequestDetails; offers: RequestOffer[] } {
  if ('request' in result && result.request) {
    return { request: result.request, offers: result.offers ?? result.request.offers ?? [] };
  }
  if ('data' in result && result.data) {
    return { request: result.data, offers: result.offers ?? result.data.offers ?? [] };
  }
  const request = result as RequestDetails;
  return { request, offers: request.offers ?? [] };
}

function fileUri(file: RequestFile): string {
  const path = typeof file === 'string' ? file : file.url ?? file.path ?? '';
  return mediaUrl(path) ?? '';
}

function safeBuyerName(request: RequestDetails): string {
  const candidates = [request.buyer_name, request.buyer?.full_name, request.buyer?.name, request.user?.full_name, request.user?.name, request.full_name, request.user_name, request.display_name, request.name];
  const valid = candidates.map((item) => typeof item === 'string' ? item.trim() : '')
    .find((item) => item.length > 0 && !/(?:^|[\\/])[^\\/]*\.php$/i.test(item));
  return valid ?? 'خریدار';
}

function statusText(status?: string): string {
  const values: Record<string, string> = { open: 'باز', pending: 'در انتظار', closed: 'بسته', accepted: 'تکمیل‌شده', cancelled: 'لغوشده' };
  return status ? values[status.toLowerCase()] ?? status : 'باز';
}

function paymentText(value?: string): string {
  if (!value) return 'نقدی';
  const labels: Record<string, string> = {
    cash: 'نقدی',
    check: 'چکی',
    cheque: 'چکی',
    check1: 'چک ۱ ماهه',
    check3: 'چک ۳ ماهه',
    check6: 'چک ۶ ماهه',
    credit: 'اعتباری',
    negotiable: 'توافقی',
    mixed: 'نقد و چک (توافقی)',
  };
  return labels[value.toLowerCase()] ?? value;
}

function permissionGranted(value?: boolean | number | string): boolean {
  return value === true || value === 1 || ['1', 'true', 'yes', 'on'].includes(String(value ?? '').toLowerCase());
}

function formatPrice(price: number | string, currency?: string): string {
  const numeric = Number(price);
  const amount = Number.isFinite(numeric) ? numeric.toLocaleString('fa-IR') : String(price);
  return `${amount}${currency ? ` ${currency}` : ' تومان'}`;
}

function InfoTile({ icon, label, value }: { icon: keyof typeof MaterialCommunityIcons.glyphMap; label: string; value: string }) {
  return (
    <View style={styles.infoTile}>
      <View style={styles.infoIcon}><MaterialCommunityIcons name={icon} size={18} color={COLORS.primaryDark} /></View>
      <Text style={styles.infoLabel}>{label}</Text>
      <Text style={styles.infoValue} numberOfLines={2}>{value}</Text>
    </View>
  );
}

export function RequestDetailScreen({ route, navigation }: Props) {
  const currentUser = useAuthStore((s) => s.user);
  const logout = useAuthStore((s) => s.logout);
  const [request, setRequest] = useState<RequestDetails | null>(null);
  const [offers, setOffers] = useState<RequestOffer[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [avatarFailed, setAvatarFailed] = useState(false);
  const [failedGalleryImages, setFailedGalleryImages] = useState<Set<string>>(new Set());
  const [sentOffer, setSentOffer] = useState<MyOfferItem | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await api.getRequest(route.params.requestId);
      const normalized = normalizeResult(result);
      setRequest(normalized.request);
      setOffers(normalized.offers);
    } catch (cause) {
      if (cause instanceof ApiError && cause.code === 'auth') {
        logout();
        return;
      }
      setError(cause instanceof ApiError ? cause.message : 'دریافت جزئیات درخواست انجام نشد.');
    } finally {
      setLoading(false);
    }
  }, [logout, route.params.requestId]);

  useEffect(() => { void load(); }, [load]);

  // Whether this supplier already sent an offer for this request. Re-checked on every focus so the
  // screen updates right after returning from the "send offer" screen.
  const refreshSentOffer = useCallback(async () => {
    const me = useAuthStore.getState().user;
    if (!me || me.role === 'buyer') return;
    try {
      const result = await api.getMyOffers();
      const list = extractArray<MyOfferItem>(result, ['offers', 'items', 'results', 'rows', 'data']);
      setSentOffer(list.find((offer) => String(offer.request_id) === String(route.params.requestId)) ?? null);
    } catch {
      // Keep whatever we already know; the request payload below is a second source.
    }
  }, [route.params.requestId]);
  useFocusEffect(useCallback(() => { void refreshSentOffer(); }, [refreshSentOffer]));

  const isOwner = Boolean(currentUser && request && String(currentUser.id) === String(request.buyer_id));
  const canMakeOffer = isSupplierSide(currentUser) && !isOwner;
  const isOfferer = Boolean(currentUser && currentUser.role !== 'buyer' && !isOwner);
  const myOfferInPayload = offers.find((offer) => currentUser && offer.supplier_id !== undefined && String(offer.supplier_id) === String(currentUser.id));
  const hasSentOffer = isOfferer && Boolean(sentOffer || myOfferInPayload);
  const showBottom = canMakeOffer || hasSentOffer;
  const gallery = useMemo(() => (request?.files ?? []).filter((file) => {
    if (typeof file === 'string') return /\.(png|jpe?g|webp|gif)(?:\?|$)/i.test(file);
    const kind = `${file.type ?? ''} ${file.ext ?? ''} ${file.url ?? file.path ?? ''}`;
    return /image|\.(png|jpe?g|webp|gif)(?:\?|$)/i.test(kind);
  }).map(fileUri).filter(Boolean), [request?.files]);

  const displayPhone = Boolean(request?.buyer_mobile?.trim()) && (isOwner || permissionGranted(request?.allow_phone));
  const buyerName = request ? safeBuyerName(request) : 'خریدار';
  const buyerAvatar = request?.buyer_avatar ?? request?.buyer?.avatar_url ?? request?.buyer?.avatar ?? request?.avatar_url ?? request?.user?.avatar_url ?? request?.user?.avatar;

  const buyerRecipientId = request ? (request.buyer_id ?? request.buyer?.id ?? request.user?.id ?? request.user_id) : undefined;
  const buyerPhoneRaw = request?.buyer_mobile ?? offers.find((offer) => offer.buyer_mobile)?.buyer_mobile ?? '';
  const phoneAllowed = permissionGranted(request?.allow_phone) || permissionGranted(myOfferInPayload?.allow_phone);

  const openChatWithBuyer = async () => {
    if (!currentUser || !request) return;
    if (buyerRecipientId === undefined || buyerRecipientId === null || String(buyerRecipientId).length === 0) {
      Alert.alert('گفتگو آماده نیست', 'شناسهٔ خریدار از سرور دریافت نشد. صفحه را دوباره باز کنید.');
      return;
    }
    const tabs = navigation.getParent() as unknown as { navigate: (name: string, params: object) => void } | undefined;
    if (!tabs) return;
    const peerAvatar = buyerAvatar ? String(buyerAvatar) : undefined;
    // If no message gets sent, the conversation stays in Messages as a draft.
    await registerDraftThread(currentUser.id, { requestId: request.id, peerId: buyerRecipientId, peerName: buyerName, requestTitle: request.title, peerAvatar });
    tabs.navigate('Messages', { screen: 'ChatRoom', params: { requestId: request.id, peerId: buyerRecipientId, peerName: buyerName, peerAvatar, requestTitle: request.title, allowChat: true } });
  };

  const callBuyer = () => {
    const digits = buyerPhoneRaw.replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d))).replace(/[^\d+]/g, '');
    if (!phoneAllowed || !/^\+?\d{10,15}$/.test(digits)) {
      Alert.alert('شمارهٔ تماس در دسترس نیست', 'خریدار هنوز شمارهٔ خود را آزاد نکرده است. از طریق چت می‌توانید از او بخواهید.', [{ text: 'بستن', style: 'cancel' }, { text: 'رفتن به چت', onPress: () => void openChatWithBuyer() }]);
      return;
    }
    // Opens the phone app's dialer with the buyer's number.
    void Linking.openURL(`tel:${digits}`).catch(() => Alert.alert('تماس برقرار نشد', 'برنامهٔ تماس در این دستگاه در دسترس نیست.'));
  };

  const sentActions = (
    <View style={styles.bottomAction}>
      <View style={styles.sentRow}>
        <Pressable onPress={callBuyer} style={({ pressed }) => [styles.sentButton, styles.callButton, pressed && { opacity: 0.86 }]} accessibilityRole="button"><MaterialCommunityIcons name="phone" size={19} color="#fff" /><Text style={styles.sentButtonText}>تماس</Text></Pressable>
        <Pressable onPress={() => void openChatWithBuyer()} style={({ pressed }) => [styles.sentButton, styles.chatButton, pressed && { opacity: 0.86 }]} accessibilityRole="button"><MaterialCommunityIcons name="message-text" size={19} color="#fff" /><Text style={styles.sentButtonText}>چت</Text></Pressable>
      </View>
      <View style={styles.dimmedOffer}><MaterialCommunityIcons name="check-circle-outline" size={16} color={COLORS.muted} /><Text style={styles.dimmedOfferText}>ارسال پیشنهاد · پیشنهاد شما ارسال شده است</Text></View>
    </View>
  );

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} style={styles.headerButton} accessibilityLabel="بازگشت"><MaterialCommunityIcons name="arrow-right" size={22} color={COLORS.text} /></Pressable>
        <Text style={styles.headerTitle}>جزئیات درخواست</Text>
        {isOwner ? (
          <Pressable
            onPress={() => {
              const tabs = navigation.getParent() as unknown as { navigate: (name: string, params?: object) => void } | undefined;
              tabs?.navigate('Dashboard', { screen: 'PostRequest', params: { requestId: request?.id } });
            }}
            style={styles.headerEditBtn}
            accessibilityLabel="ویرایش آگهی"
          >
            <MaterialCommunityIcons name="pencil-outline" size={16} color={COLORS.primaryDark} />
            <Text style={styles.headerEditText}>ویرایش</Text>
          </Pressable>
        ) : (
          <Pressable onPress={() => Alert.alert('اشتراک‌گذاری', 'اشتراک‌گذاری درخواست در مرحلهٔ بعد اضافه می‌شود.')} style={styles.headerButton} accessibilityLabel="بیشتر">
            <MaterialCommunityIcons name="share-variant-outline" size={19} color={COLORS.text} />
          </Pressable>
        )}
      </View>

      {loading && !request ? (
        <View style={styles.centerState}><ActivityIndicator size="large" color={COLORS.primary} /><Text style={styles.stateText}>در حال دریافت جزئیات درخواست...</Text></View>
      ) : error && !request ? (
        (currentUser?.role === 'buyer' && /دسترس|مجاز|اجازه|access|forbidden|403/i.test(error)) ? (
          <View style={styles.accessCard}>
            <View style={styles.accessIconWrap}>
              <MaterialCommunityIcons name="shield-account-outline" size={34} color={COLORS.primaryDark} />
            </View>
            <Text style={styles.accessTitle}>دسترسی محدود است</Text>
            <Text style={styles.accessText}>
              شما اجازهٔ مشاهدهٔ این آگهی را ندارید، مگر اینکه با حساب{' '}
              <Text style={styles.accessHighlight}>تأمین‌کننده</Text>
              {' '}یا{' '}
              <Text style={styles.accessHighlight}>ترخیص‌کار</Text>
              {' '}وارد شوید.
            </Text>
            <Text style={styles.accessSub}>
              جزئیات آگهی‌های دیگران فقط برای تأمین‌کنندگان و ترخیص‌کاران قابل مشاهده است. برای ارسال پیشنهاد باید با نقش تأمین‌کننده یا ترخیص‌کار وارد شوید.
            </Text>
            <Pressable style={styles.accessPrimary} onPress={() => navigation.goBack()}>
              <MaterialCommunityIcons name="arrow-right" size={18} color="#fff" />
              <Text style={styles.accessPrimaryText}>متوجه شدم</Text>
            </Pressable>
          </View>
        ) : (
          <View style={styles.centerState}>
            <MaterialCommunityIcons name="cloud-alert-outline" size={34} color={COLORS.danger} />
            <Text style={styles.stateTitle}>بارگذاری انجام نشد</Text>
            <Text style={styles.stateText}>{error}</Text>
            <Pressable style={styles.retryButton} onPress={() => void load()}><Text style={styles.retryText}>تلاش دوباره</Text></Pressable>
          </View>
        )

      ) : request ? (
        <>
          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={[styles.scrollContent, showBottom && styles.withBottomAction, hasSentOffer && styles.withBottomActionTall]}>
            <View style={styles.titleCard}>
              <View style={styles.titleTop}><View style={styles.statusBadge}><View style={styles.statusDot} /><Text style={styles.statusText}>{statusText(request.status)}</Text></View><Text style={styles.category}>{request.category_name ?? request.category ?? 'دسته‌بندی نشده'}</Text></View>
              <Text style={styles.requestTitle}>{request.title}</Text>
              <View style={styles.buyerRow}>
                {buyerAvatar && !avatarFailed ? <Image source={{ uri: mediaUrl(buyerAvatar) }} onError={() => setAvatarFailed(true)} style={styles.avatar} /> : <View style={styles.avatarFallback}><Text style={styles.avatarInitial}>{buyerName[0]}</Text></View>}
                <View style={styles.buyerText}><Text style={styles.buyerLabel}>ثبت‌کنندهٔ درخواست</Text><Text style={styles.buyerName}>{buyerName}</Text></View>
                {displayPhone ? <View style={styles.phoneBadge}><MaterialCommunityIcons name="phone-outline" size={14} color={COLORS.success} /><Text style={styles.phoneText}>{request.buyer_mobile}</Text></View> : null}
              </View>
            </View>

            <View style={styles.sectionCard}>
              <Text style={styles.sectionTitle}>شرح درخواست</Text>
              <Text style={styles.description}>{request.description?.trim() || 'توضیحی برای این درخواست ثبت نشده است.'}</Text>
            </View>

            {gallery.length > 0 ? (
              <View style={styles.gallerySection}>
                <View style={styles.sectionHeader}><Text style={styles.sectionHint}>تصاویر و فایل‌های پیوست</Text><Text style={styles.sectionTitle}>پیوست‌ها</Text></View>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.galleryRow}>
                  {gallery.map((uri, index) => <View key={`${uri}-${index}`} style={styles.galleryFrame}>{failedGalleryImages.has(uri) ? <View style={styles.galleryFallback}><MaterialCommunityIcons name="image-off-outline" size={24} color={COLORS.muted} /></View> : <Image source={{ uri }} resizeMode="cover" onError={() => setFailedGalleryImages((old) => new Set(old).add(uri))} style={styles.galleryImage} />}</View>)}
                </ScrollView>
              </View>
            ) : null}

            <View style={styles.detailsGrid}>
              <InfoTile icon="weight-kilogram" label="مقدار" value={`${request.quantity ?? '—'} ${request.unit ?? ''}`.trim()} />
              <InfoTile icon="cash-multiple" label="روش پرداخت" value={paymentText(request.payment_type)} />
              <InfoTile icon="map-marker-outline" label="استان" value={request.province || 'ثبت نشده'} />
              <InfoTile icon="shape-outline" label="دسته‌بندی" value={request.category_name ?? request.category ?? 'ثبت نشده'} />
            </View>

            {isOwner ? (
              <View style={styles.offersSection}>
                <View style={styles.sectionHeader}><View style={styles.offerCount}><Text style={styles.offerCountText}>{offers.length.toLocaleString('fa-IR')}</Text></View><View><Text style={styles.sectionTitle}>پیشنهادهای دریافتی</Text><Text style={styles.sectionHint}>پیشنهادهای تأمین‌کنندگان برای این درخواست</Text></View></View>
                {offers.length > 0 ? offers.map((offer) => (
                  <Pressable key={String(offer.id)} onPress={() => navigation.navigate('OfferDetail', { offerId: offer.id, requestId: request.id, offer })} style={({ pressed }) => [styles.offerCard, pressed && { opacity: 0.84 }]}>
                    <View style={styles.offerArrow}><MaterialCommunityIcons name="chevron-left" size={20} color={COLORS.primaryDark} /></View>
                    <View style={styles.offerMain}><Text style={styles.supplierName}>{offer.supplier_name || 'تأمین‌کننده'}</Text><View style={styles.offerMeta}><Text style={styles.offerMetaText}>تحویل: {offer.delivery_time ?? 'توافقی'}</Text><View style={styles.offerMetaDivider} /><Text style={styles.offerPrice}>{formatPrice(offer.price, offer.currency)}</Text></View></View>
                    <View style={styles.supplierAvatar}><Text style={styles.supplierInitial}>{(offer.supplier_name || 'ت')[0]}</Text></View>
                  </Pressable>
                )) : <View style={styles.noOffers}><MaterialCommunityIcons name="inbox-outline" size={22} color={COLORS.muted} /><Text style={styles.noOffersText}>هنوز پیشنهادی برای این درخواست ثبت نشده است.</Text></View>}
              </View>
            ) : null}
          </ScrollView>
          {hasSentOffer ? sentActions : canMakeOffer ? <View style={styles.bottomAction}><Pressable onPress={() => navigation.navigate('MakeOffer', { requestId: request.id, buyerId: request.buyer_id ?? request.buyer?.id ?? request.user?.id ?? request.user_id, buyerName, buyerAvatar: buyerAvatar ? String(buyerAvatar) : undefined, buyerMobile: request.buyer_mobile, requestTitle: request.title, allowChat: permissionGranted(request.allow_chat), allowPhone: permissionGranted(request.allow_phone) })} style={({ pressed }) => [styles.makeOfferButton, pressed && { opacity: 0.86 }]}><MaterialCommunityIcons name="send-outline" size={18} color="#fff" /><Text style={styles.makeOfferText}>ارسال پیشنهاد</Text></Pressable></View> : null}
        </>
      ) : null}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.background },
  header: { height: 56, paddingHorizontal: 17, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: '#EEEAE1' },
  headerEditBtn: { minHeight: 34, paddingHorizontal: 10, borderRadius: 11, backgroundColor: '#FFFBEB', borderWidth: 1, borderColor: '#E4C66C', flexDirection: 'row-reverse', alignItems: 'center', gap: 4 },
  headerEditText: { fontFamily: 'VazirmatnBold', fontSize: 10, color: COLORS.primaryDark },
  headerButton: { width: 38, height: 38, borderRadius: 13, backgroundColor: '#fff', borderWidth: 1, borderColor: COLORS.border, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { fontFamily: 'VazirmatnBold', fontSize: 14, color: COLORS.text },
  scrollContent: { paddingHorizontal: 17, paddingTop: 15, paddingBottom: 28 },
  withBottomAction: { paddingBottom: 104 },
  withBottomActionTall: { paddingBottom: 168 },
  titleCard: { padding: 17, borderRadius: 21, backgroundColor: '#211B10', marginBottom: 13, overflow: 'hidden' },
  titleTop: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between' },
  statusBadge: { flexDirection: 'row-reverse', alignItems: 'center', gap: 5, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20, backgroundColor: '#DCFCE7' },
  statusDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: COLORS.success },
  statusText: { fontFamily: 'VazirmatnBold', fontSize: 9, color: '#15803D' },
  category: { fontFamily: 'VazirmatnMedium', fontSize: 10, color: '#E4C66C' },
  requestTitle: { fontFamily: 'VazirmatnBold', fontSize: 20, lineHeight: 31, color: '#FFFDF6', textAlign: 'right', marginTop: 12, marginBottom: 15 },
  buyerRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 9, borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.12)', paddingTop: 12 },
  avatar: { width: 39, height: 39, borderRadius: 14, backgroundColor: '#F4E9C9' },
  avatarFallback: { width: 39, height: 39, borderRadius: 14, backgroundColor: '#F4E9C9', alignItems: 'center', justifyContent: 'center' },
  avatarInitial: { fontFamily: 'VazirmatnBold', fontSize: 18, color: COLORS.primaryDark },
  buyerText: { flex: 1 },
  buyerLabel: { fontFamily: 'Vazirmatn', fontSize: 9, color: '#C7C2B6', textAlign: 'right' },
  buyerName: { fontFamily: 'VazirmatnBold', fontSize: 12, color: '#fff', textAlign: 'right', marginTop: 1 },
  phoneBadge: { flexDirection: 'row-reverse', alignItems: 'center', gap: 4, borderRadius: 10, backgroundColor: 'rgba(16,185,129,0.13)', paddingHorizontal: 8, paddingVertical: 6 },
  phoneText: { fontFamily: 'VazirmatnMedium', fontSize: 9, color: '#A7F3D0' },
  sectionCard: { backgroundColor: '#fff', borderRadius: 18, borderWidth: 1, borderColor: '#EAE6DC', padding: 16, marginBottom: 13 },
  sectionTitle: { fontFamily: 'VazirmatnBold', fontSize: 14, color: COLORS.text, textAlign: 'right' },
  description: { fontFamily: 'Vazirmatn', fontSize: 12, lineHeight: 23, color: '#57534E', textAlign: 'right', marginTop: 8 },
  gallerySection: { marginBottom: 13 },
  sectionHeader: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 },
  sectionHint: { fontFamily: 'Vazirmatn', fontSize: 9, color: COLORS.muted, textAlign: 'right', marginTop: 2 },
  galleryRow: { flexDirection: 'row-reverse', gap: 10 },
  galleryFrame: { width: 142, height: 105, borderRadius: 15, overflow: 'hidden', backgroundColor: '#E7E5E4' },
  galleryImage: { width: 142, height: 105, borderRadius: 15, backgroundColor: '#E7E5E4' },
  galleryFallback: { width: 142, height: 105, alignItems: 'center', justifyContent: 'center', backgroundColor: '#E7E5E4' },
  detailsGrid: { flexDirection: 'row-reverse', flexWrap: 'wrap', gap: 9, marginBottom: 14 },
  infoTile: { width: '48%', minHeight: 91, backgroundColor: '#fff', borderRadius: 16, borderWidth: 1, borderColor: '#EAE6DC', padding: 12, alignItems: 'flex-end' },
  infoIcon: { width: 29, height: 29, borderRadius: 10, backgroundColor: '#FBF3DC', alignItems: 'center', justifyContent: 'center', marginBottom: 6 },
  infoLabel: { fontFamily: 'Vazirmatn', fontSize: 9, color: COLORS.muted, textAlign: 'right' },
  infoValue: { fontFamily: 'VazirmatnBold', fontSize: 11, color: COLORS.text, textAlign: 'right', marginTop: 1 },
  offersSection: { marginTop: 4, marginBottom: 15 },
  offerCount: { minWidth: 27, height: 27, paddingHorizontal: 7, borderRadius: 14, backgroundColor: '#F4E9C9', alignItems: 'center', justifyContent: 'center' },
  offerCountText: { fontFamily: 'VazirmatnBold', color: COLORS.primaryDark, fontSize: 10 },
  offerCard: { flexDirection: 'row-reverse', alignItems: 'center', gap: 10, backgroundColor: '#fff', borderWidth: 1, borderColor: '#EAE6DC', borderRadius: 16, padding: 12, marginBottom: 9 },
  offerArrow: { width: 28, height: 28, borderRadius: 9, backgroundColor: '#FBF3DC', alignItems: 'center', justifyContent: 'center' },
  offerMain: { flex: 1 },
  supplierName: { fontFamily: 'VazirmatnBold', fontSize: 12, color: COLORS.text, textAlign: 'right' },
  offerMeta: { flexDirection: 'row-reverse', alignItems: 'center', gap: 8, marginTop: 5 },
  offerMetaText: { fontFamily: 'Vazirmatn', fontSize: 9, color: COLORS.muted },
  offerMetaDivider: { width: 1, height: 11, backgroundColor: COLORS.border },
  offerPrice: { fontFamily: 'VazirmatnBold', fontSize: 10, color: COLORS.primaryDark },
  supplierAvatar: { width: 38, height: 38, borderRadius: 13, backgroundColor: '#F4E9C9', alignItems: 'center', justifyContent: 'center' },
  supplierInitial: { fontFamily: 'VazirmatnBold', fontSize: 16, color: COLORS.primaryDark },
  noOffers: { minHeight: 92, borderRadius: 16, borderWidth: 1, borderStyle: 'dashed', borderColor: COLORS.border, alignItems: 'center', justifyContent: 'center', gap: 6, padding: 12 },
  noOffersText: { fontFamily: 'Vazirmatn', fontSize: 10, color: COLORS.muted, textAlign: 'center' },
  bottomAction: { position: 'absolute', bottom: 0, left: 0, right: 0, paddingHorizontal: 17, paddingTop: 12, paddingBottom: 12, backgroundColor: 'rgba(250,250,249,0.97)', borderTopWidth: 1, borderTopColor: COLORS.border },
  makeOfferButton: { minHeight: 50, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: COLORS.primaryDark, borderRadius: 15 },
  makeOfferText: { fontFamily: 'VazirmatnBold', fontSize: 14, color: '#fff' },
  sentRow: { flexDirection: 'row-reverse', gap: 9 },
  sentButton: { flex: 1, minHeight: 50, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', gap: 8, borderRadius: 15 },
  callButton: { backgroundColor: '#15803D' },
  chatButton: { backgroundColor: COLORS.primaryDark },
  sentButtonText: { fontFamily: 'VazirmatnBold', fontSize: 14, color: '#fff' },
  dimmedOffer: { minHeight: 40, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', gap: 6, marginTop: 9, borderRadius: 13, backgroundColor: '#F5F5F4', borderWidth: 1, borderColor: '#E7E5E4', opacity: 0.55 },
  dimmedOfferText: { fontFamily: 'VazirmatnMedium', fontSize: 11, color: COLORS.muted },
  centerState: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 25, gap: 10 },
  stateTitle: { fontFamily: 'VazirmatnBold', color: COLORS.text, fontSize: 14, textAlign: 'center' },
  stateText: { fontFamily: 'Vazirmatn', color: COLORS.muted, fontSize: 11, textAlign: 'center', lineHeight: 19 },
  retryButton: { backgroundColor: COLORS.primaryDark, borderRadius: 11, paddingHorizontal: 18, paddingVertical: 9, marginTop: 4 },
  accessCard: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 28, gap: 10 },
  accessIconWrap: { width: 72, height: 72, borderRadius: 24, backgroundColor: '#F4E9C9', alignItems: 'center', justifyContent: 'center', marginBottom: 6 },
  accessTitle: { fontFamily: 'VazirmatnBold', fontSize: 16, color: COLORS.text, textAlign: 'center' },
  accessText: { fontFamily: 'Vazirmatn', fontSize: 12, lineHeight: 22, color: '#57534E', textAlign: 'center' },
  accessHighlight: { fontFamily: 'VazirmatnBold', color: COLORS.primaryDark },
  accessSub: { fontFamily: 'Vazirmatn', fontSize: 10, lineHeight: 18, color: COLORS.muted, textAlign: 'center', marginBottom: 6 },
  accessPrimary: { marginTop: 6, minHeight: 48, paddingHorizontal: 18, borderRadius: 14, backgroundColor: COLORS.primaryDark, flexDirection: 'row-reverse', alignItems: 'center', gap: 8 },
  accessPrimaryText: { fontFamily: 'VazirmatnBold', fontSize: 12, color: '#fff' },
  accessSecondary: { minHeight: 42, paddingHorizontal: 16, borderRadius: 12, backgroundColor: '#F5F5F4', alignItems: 'center', justifyContent: 'center' },
  accessSecondaryText: { fontFamily: 'VazirmatnBold', fontSize: 11, color: COLORS.muted },
  editOwnerBtn: { marginTop: 12, minHeight: 46, borderRadius: 14, backgroundColor: '#FFFBEB', borderWidth: 1, borderColor: '#E4C66C', flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', gap: 8 },
  editOwnerText: { fontFamily: 'VazirmatnBold', fontSize: 12, color: COLORS.primaryDark },
  retryText: { fontFamily: 'VazirmatnBold', color: '#fff', fontSize: 11 },
});
