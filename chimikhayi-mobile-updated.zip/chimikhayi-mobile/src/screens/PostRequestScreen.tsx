import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Alert, KeyboardAvoidingView, Modal, Platform, Pressable, ScrollView, StyleSheet, Switch, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as DocumentPicker from 'expo-document-picker';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ApiError, api, type RequestDetails, type RequestDetailResult, type RequestFile } from '../api/api';
import type { DashboardStackParamList } from '../navigation/DashboardStackNavigator';
import { useAuthStore, type User } from '../store/authStore';
import { COLORS } from '../theme/colors';

type Props = NativeStackScreenProps<DashboardStackParamList, 'PostRequest'>;
type PickerKey = 'category' | 'province' | 'unit' | 'payment';

const OPTIONS: Record<PickerKey, string[]> = {
  category: [
    'مواد دارویی و تجهیزات پزشکی',
    'محصولات پتروشیمی',
    'قطعات و لوازم خودرو',
    'مواد اولیه صنعتی و شیمیایی',
    'لوازم خانگی و الکترونیک',
    'لوازم و تجهیزات صنعتی',
    'مصالح ساختمانی',
    'مواد غذایی و کشاورزی',
    'فلزات و فولاد',
    'ماشین‌آلات سنگین',
    'بسته‌بندی',
    'نساجی و الیاف',
  ],
  province: [
    'آذربایجان شرقی', 'آذربایجان غربی', 'اردبیل', 'اصفهان', 'البرز', 'ایلام',
    'بوشهر', 'تهران', 'چهارمحال و بختیاری', 'خراسان جنوبی', 'خراسان رضوی', 'خراسان شمالی',
    'خوزستان', 'زنجان', 'سمنان', 'سیستان و بلوچستان', 'فارس', 'قزوین', 'قم',
    'کردستان', 'کرمان', 'کرمانشاه', 'کهگیلویه و بویراحمد', 'گلستان', 'گیلان',
    'لرستان', 'مازندران', 'مرکزی', 'هرمزگان', 'همدان', 'یزد',
  ],
  unit: ['تن', 'کیلوگرم', 'عدد', 'دستگاه', 'متر', 'لیتر', 'بسته', 'سایر'],
  payment: ['نقدی', 'چک ۳ ماهه', 'چک ۶ ماهه', 'نقد و چک (توافقی)'],
};

const PAYMENT_VALUE: Record<string, string> = {
  'نقدی': 'cash',
  'چک ۳ ماهه': 'check3',
  'چک ۶ ماهه': 'check6',
  'نقد و چک (توافقی)': 'mixed',
};

const PAYMENT_LABEL: Record<string, string> = {
  cash: 'نقدی',
  check3: 'چک ۳ ماهه',
  check6: 'چک ۶ ماهه',
  mixed: 'نقد و چک (توافقی)',
  check1: 'چک ۱ ماهه',
  negotiable: 'توافقی',
  check: 'چکی',
};

const FIELD_LABEL: Record<PickerKey, string> = {
  category: 'دسته‌بندی',
  province: 'استان',
  unit: 'واحد',
  payment: 'شرایط پرداخت',
};

const digitsOnly = (value: string) =>
  value
    .replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));

function isVerified(user: User): boolean {
  const flag = user.is_verified ?? user.verified;
  if (flag === true || flag === 1 || flag === '1') return true;
  if (flag === false || flag === 0 || flag === '0') return false;
  return Boolean(user.level && user.level.toLowerCase() !== 'bronze');
}

function normalizeRequest(result: RequestDetailResult): RequestDetails | null {
  if ('request' in result && result.request) return result.request;
  if ('data' in result && result.data) return result.data;
  if (result && typeof result === 'object' && 'id' in result && 'title' in result) return result as RequestDetails;
  return null;
}

function fileNameOf(file: RequestFile, index: number): string {
  if (typeof file === 'string') return file.split('/').pop() || `فایل ${index + 1}`;
  return file.name || file.url?.split('/').pop() || file.path?.split('/').pop() || `فایل ${index + 1}`;
}

export function PostRequestScreen({ navigation, route }: Props) {
  const user = useAuthStore((s) => s.user);
  const editId = route.params?.requestId;
  const isEdit = editId !== undefined && editId !== null && String(editId).length > 0;

  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('');
  const [province, setProvince] = useState('');
  const [quantity, setQuantity] = useState('');
  const [unit, setUnit] = useState('');
  const [payment, setPayment] = useState('نقد');
  const [description, setDescription] = useState('');
  const [showPhone, setShowPhone] = useState(false);
  const [attachments, setAttachments] = useState<DocumentPicker.DocumentPickerAsset[]>([]);
  const [existingFiles, setExistingFiles] = useState<RequestFile[]>([]);
  const [removedExisting, setRemovedExisting] = useState<string[]>([]);
  const [activePicker, setActivePicker] = useState<PickerKey | null>(null);
  const [busy, setBusy] = useState(false);
  const [loadingEdit, setLoadingEdit] = useState(isEdit);

  useEffect(() => {
    if (!isEdit) return;
    let cancelled = false;
    (async () => {
      setLoadingEdit(true);
      try {
        const result = await api.getRequest(editId!);
        const req = normalizeRequest(result);
        if (!req || cancelled) return;
        setTitle(String(req.title ?? ''));
        setCategory(String(req.category ?? req.category_name ?? ''));
        setProvince(String(req.province ?? ''));
        setQuantity(String(req.quantity ?? ''));
        setUnit(String(req.unit ?? ''));
        const pt = String(req.payment_type ?? 'cash').toLowerCase();
        setPayment(PAYMENT_LABEL[pt] ?? 'نقدی');
        setDescription(String(req.description ?? ''));
        const phoneVisible =
          req.allow_phone === 1 ||
          req.allow_phone === true ||
          req.allow_phone === '1' ||
          (req as { show_phone?: unknown }).show_phone === 1 ||
          (req as { show_phone?: unknown }).show_phone === true;
        setShowPhone(Boolean(phoneVisible));
        setExistingFiles(req.files ?? []);
      } catch (error) {
        if (!cancelled) {
          Alert.alert(
            'بارگذاری آگهی انجام نشد',
            error instanceof ApiError ? error.message : 'لطفاً دوباره تلاش کنید.',
            [{ text: 'بازگشت', onPress: () => navigation.goBack() }],
          );
        }
      } finally {
        if (!cancelled) setLoadingEdit(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [editId, isEdit, navigation]);

  const chooseFiles = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: [
          'image/*',
          'video/*',
          'application/pdf',
          'application/msword',
          'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        ],
        multiple: true,
        copyToCacheDirectory: true,
      });
      if (!result.canceled) {
        setAttachments((current) => [...current, ...result.assets].slice(0, 8));
      }
    } catch {
      Alert.alert('انتخاب فایل انجام نشد', 'لطفاً دوباره تلاش کنید.');
    }
  };

  const removeNewFile = (uri: string) => setAttachments((current) => current.filter((file) => file.uri !== uri));
  const removeExistingFile = (file: RequestFile, index: number) => {
    const key = typeof file === 'string' ? file : file.url || file.path || String(index);
    setRemovedExisting((prev) => [...prev, key]);
    setExistingFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const submit = async () => {
    if (!user || user.role !== 'buyer') {
      Alert.alert('دسترسی محدود است', 'ثبت درخواست فقط برای حساب خریدار امکان‌پذیر است.');
      return;
    }
    if (!isEdit && !isVerified(user)) {
      Alert.alert('احراز هویت لازم است', 'پس از تأیید احراز هویت، امکان ثبت درخواست برای شما فعال می‌شود.');
      return;
    }
    const normalizedQuantity = digitsOnly(quantity).replace(/[٬,\s]/g, '');
    if (title.trim().length < 3) return Alert.alert('عنوان نامعتبر است', 'عنوان درخواست را کامل وارد کنید.');
    if (!category || !province || !unit || !payment) {
      return Alert.alert('اطلاعات ناقص است', 'دسته‌بندی، استان، واحد و شرایط پرداخت را انتخاب کنید.');
    }
    if (!normalizedQuantity || !/^\d+(\.\d+)?$/.test(normalizedQuantity) || Number(normalizedQuantity) <= 0) {
      return Alert.alert('مقدار نامعتبر است', 'مقدار را به‌صورت عددی و بزرگ‌تر از صفر وارد کنید.');
    }
    if (description.trim().length < 10) {
      return Alert.alert('توضیحات کوتاه است', 'لطفاً حداقل ۱۰ نویسه دربارهٔ درخواست بنویسید.');
    }

    const formData = new FormData();
    if (isEdit) formData.append('id', String(editId));
    if (isEdit) formData.append('request_id', String(editId));
    formData.append('title', title.trim());
    formData.append('category', category);
    formData.append('province', province);
    formData.append('quantity', normalizedQuantity);
    formData.append('unit', unit);
    formData.append('description', description.trim());
    formData.append('payment_type', PAYMENT_VALUE[payment] ?? 'cash');
    formData.append('show_phone', showPhone ? '1' : '0');
    formData.append('allow_phone', showPhone ? '1' : '0');
    if (removedExisting.length) {
      formData.append('removed_files', JSON.stringify(removedExisting));
    }
    attachments.forEach((asset, index) => {
      const name = asset.name || `file-${Date.now()}-${index}.jpg`;
      const type = asset.mimeType || (name.match(/\.png$/i) ? 'image/png' : name.match(/\.pdf$/i) ? 'application/pdf' : 'image/jpeg');
      // React Native FormData expects { uri, name, type }
      formData.append('files[]', { uri: asset.uri, name, type } as unknown as Blob);
      formData.append('files', { uri: asset.uri, name, type } as unknown as Blob);
    });

    setBusy(true);
    try {
      if (isEdit) await api.updateRequest(formData);
      else await api.postRequest(formData);
      Alert.alert(
        isEdit ? 'آگهی به‌روزرسانی شد' : 'درخواست ثبت شد',
        isEdit ? 'تغییرات آگهی با موفقیت ذخیره شد.' : 'درخواست شما با موفقیت ثبت شد.',
        [{ text: 'باشه', onPress: () => navigation.goBack() }],
      );
    } catch (error) {
      Alert.alert(
        isEdit ? 'ذخیره انجام نشد' : 'ثبت انجام نشد',
        error instanceof ApiError ? error.message : 'لطفاً دوباره تلاش کنید.',
      );
    } finally {
      setBusy(false);
    }
  };

  if (loadingEdit) {
    return (
      <SafeAreaView style={styles.safeArea} edges={['top']}>
        <View style={styles.loadingBox}>
          <ActivityIndicator size="large" color={COLORS.primary} />
          <Text style={styles.loadingText}>در حال بارگذاری آگهی...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={styles.header}>
          <Pressable onPress={() => navigation.goBack()} style={styles.backBtn} accessibilityLabel="بازگشت">
            <MaterialCommunityIcons name="arrow-right" size={22} color={COLORS.text} />
          </Pressable>
          <Text style={styles.headerTitle}>{isEdit ? 'ویرایش آگهی' : 'ثبت درخواست خرید'}</Text>
          <View style={styles.backBtn} />
        </View>

        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          <Text style={styles.label}>عنوان</Text>
          <TextInput value={title} onChangeText={setTitle} placeholder="مثلاً خرید پارچه پنبه" placeholderTextColor="#A8A29E" textAlign="right" style={styles.input} />

          <Text style={styles.label}>دسته‌بندی</Text>
          <SelectField value={category} placeholder="انتخاب دسته‌بندی" icon="shape-outline" onPress={() => setActivePicker('category')} />

          <Text style={styles.label}>استان</Text>
          <SelectField value={province} placeholder="انتخاب استان" icon="map-marker-outline" onPress={() => setActivePicker('province')} />

          <Text style={styles.label}>مقدار و واحد</Text>
          <View style={styles.quantityRow}>
            <TextInput
              value={quantity}
              onChangeText={(value) => setQuantity(value.replace(/[^0-9۰-۹٠-٩٬,.]/g, ''))}
              placeholder="مقدار"
              placeholderTextColor="#A8A29E"
              keyboardType="decimal-pad"
              textAlign="right"
              style={[styles.input, styles.quantityInput]}
            />
            <View style={styles.unitField}>
              <SelectField value={unit} placeholder="واحد" icon="chevron-down" onPress={() => setActivePicker('unit')} compact />
            </View>
          </View>

          <Text style={styles.label}>شرایط پرداخت</Text>
          <SelectField value={payment} placeholder="انتخاب شرایط پرداخت" icon="cash-multiple" onPress={() => setActivePicker('payment')} />

          <Text style={styles.label}>توضیحات</Text>
          <TextInput
            value={description}
            onChangeText={setDescription}
            placeholder="جزئیات نیاز، کیفیت، زمان تحویل و ..."
            placeholderTextColor="#A8A29E"
            textAlign="right"
            multiline
            style={[styles.input, styles.textArea]}
          />

          <View style={styles.phoneCard}>
            <View style={styles.phoneIcon}>
              <MaterialCommunityIcons name="phone-outline" size={18} color={COLORS.primaryDark} />
            </View>
            <View style={styles.phoneCopy}>
              <Text style={styles.phoneTitle}>نمایش شماره تماس</Text>
              <Text style={styles.phoneHint}>
                {showPhone
                  ? 'شماره شما برای تأمین‌کنندگان روی آگهی نمایش داده می‌شود.'
                  : 'شماره مخفی است؛ فقط با اجازه شما در دسترس قرار می‌گیرد.'}
              </Text>
            </View>
            <Switch
              value={showPhone}
              onValueChange={setShowPhone}
              trackColor={{ false: '#D6D3D1', true: '#D4A017' }}
              thumbColor={showPhone ? '#fff' : '#F5F5F4'}
            />
          </View>

          <Text style={styles.label}>تصاویر، ویدیو و فایل‌ها</Text>
          <Pressable onPress={() => void chooseFiles()} style={styles.attachBtn}>
            <MaterialCommunityIcons name="paperclip" size={18} color={COLORS.primaryDark} />
            <Text style={styles.attachText}>افزودن تصویر / ویدیو / فایل</Text>
          </Pressable>

          {existingFiles.map((file, index) => (
            <View key={`ex-${index}`} style={styles.fileRow}>
              <Pressable onPress={() => removeExistingFile(file, index)} hitSlop={8}>
                <MaterialCommunityIcons name="close-circle" size={20} color={COLORS.danger} />
              </Pressable>
              <Text style={styles.fileName} numberOfLines={1}>{fileNameOf(file, index)}</Text>
              <MaterialCommunityIcons name="file-outline" size={18} color={COLORS.muted} />
            </View>
          ))}
          {attachments.map((asset) => (
            <View key={asset.uri} style={styles.fileRow}>
              <Pressable onPress={() => removeNewFile(asset.uri)} hitSlop={8}>
                <MaterialCommunityIcons name="close-circle" size={20} color={COLORS.danger} />
              </Pressable>
              <Text style={styles.fileName} numberOfLines={1}>{asset.name}</Text>
              <MaterialCommunityIcons name="file-plus-outline" size={18} color={COLORS.primaryDark} />
            </View>
          ))}

          <Pressable disabled={busy} onPress={() => void submit()} style={[styles.submitBtn, busy && { opacity: 0.7 }]}>
            {busy ? <ActivityIndicator color="#fff" /> : (
              <>
                <MaterialCommunityIcons name={isEdit ? 'content-save-outline' : 'send-outline'} size={18} color="#fff" />
                <Text style={styles.submitText}>{isEdit ? 'ذخیره تغییرات' : 'ثبت درخواست'}</Text>
              </>
            )}
          </Pressable>
        </ScrollView>
      </KeyboardAvoidingView>

      <Modal visible={Boolean(activePicker)} transparent animationType="fade" onRequestClose={() => setActivePicker(null)}>
        <Pressable style={styles.modalBackdrop} onPress={() => setActivePicker(null)}>
          <View style={styles.sheet}>
            <Text style={styles.sheetTitle}>{activePicker ? FIELD_LABEL[activePicker] : ''}</Text>
            <ScrollView style={{ maxHeight: 360 }}>
              {(activePicker ? OPTIONS[activePicker] : []).map((option) => (
                <Pressable
                  key={option}
                  onPress={() => {
                    if (activePicker === 'category') setCategory(option);
                    else if (activePicker === 'province') setProvince(option);
                    else if (activePicker === 'unit') setUnit(option);
                    else if (activePicker === 'payment') setPayment(option);
                    setActivePicker(null);
                  }}
                  style={styles.optionRow}
                >
                  <Text style={styles.optionText}>{option}</Text>
                  <MaterialCommunityIcons name="chevron-left" size={19} color={COLORS.muted} />
                </Pressable>
              ))}
            </ScrollView>
            <Pressable style={styles.sheetCancel} onPress={() => setActivePicker(null)}>
              <Text style={styles.sheetCancelText}>انصراف</Text>
            </Pressable>
          </View>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

function SelectField({
  value,
  placeholder,
  icon,
  onPress,
  compact,
}: {
  value: string;
  placeholder: string;
  icon: keyof typeof MaterialCommunityIcons.glyphMap;
  onPress: () => void;
  compact?: boolean;
}) {
  return (
    <Pressable onPress={onPress} style={[styles.selectField, compact && styles.selectCompact]}>
      <MaterialCommunityIcons name={icon} size={18} color={COLORS.primaryDark} />
      <Text style={[styles.selectText, !value && styles.selectPlaceholder]} numberOfLines={1}>
        {value || placeholder}
      </Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.background },
  loadingBox: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10 },
  loadingText: { fontFamily: 'Vazirmatn', fontSize: 11, color: COLORS.muted },
  header: {
    minHeight: 56,
    paddingHorizontal: 14,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderBottomColor: '#EEEAE1',
  },
  backBtn: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center', backgroundColor: '#fff', borderWidth: 1, borderColor: COLORS.border },
  headerTitle: { fontFamily: 'VazirmatnBold', fontSize: 14, color: COLORS.text },
  content: { padding: 16, paddingBottom: 36, gap: 6 },
  label: { fontFamily: 'VazirmatnBold', fontSize: 11, color: COLORS.text, textAlign: 'right', marginTop: 10, marginBottom: 6 },
  input: {
    minHeight: 46,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: COLORS.border,
    backgroundColor: '#fff',
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontFamily: 'Vazirmatn',
    fontSize: 12,
    color: COLORS.text,
  },
  textArea: { minHeight: 110, textAlignVertical: 'top' },
  quantityRow: { flexDirection: 'row-reverse', gap: 8 },
  quantityInput: { flex: 1 },
  unitField: { width: 120 },
  selectField: {
    minHeight: 46,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: COLORS.border,
    backgroundColor: '#fff',
    paddingHorizontal: 12,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 8,
  },
  selectCompact: { minHeight: 46 },
  selectText: { flex: 1, fontFamily: 'Vazirmatn', fontSize: 12, color: COLORS.text, textAlign: 'right' },
  selectPlaceholder: { color: '#A8A29E' },
  phoneCard: {
    marginTop: 14,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 10,
    padding: 12,
    borderRadius: 16,
    backgroundColor: '#FFFBEB',
    borderWidth: 1,
    borderColor: '#F4E9C9',
  },
  phoneIcon: { width: 36, height: 36, borderRadius: 12, backgroundColor: '#F4E9C9', alignItems: 'center', justifyContent: 'center' },
  phoneCopy: { flex: 1 },
  phoneTitle: { fontFamily: 'VazirmatnBold', fontSize: 11, color: COLORS.text, textAlign: 'right' },
  phoneHint: { fontFamily: 'Vazirmatn', fontSize: 9, color: COLORS.muted, textAlign: 'right', marginTop: 2, lineHeight: 15 },
  attachBtn: {
    minHeight: 46,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#E4C66C',
    backgroundColor: '#FFFDF6',
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  attachText: { fontFamily: 'VazirmatnBold', fontSize: 11, color: COLORS.primaryDark },
  fileRow: {
    marginTop: 8,
    minHeight: 42,
    borderRadius: 12,
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: COLORS.border,
    paddingHorizontal: 10,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 8,
  },
  fileName: { flex: 1, fontFamily: 'Vazirmatn', fontSize: 10, color: COLORS.text, textAlign: 'right' },
  submitBtn: {
    marginTop: 18,
    minHeight: 50,
    borderRadius: 15,
    backgroundColor: COLORS.primaryDark,
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  submitText: { fontFamily: 'VazirmatnBold', fontSize: 13, color: '#fff' },
  modalBackdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.35)', justifyContent: 'flex-end' },
  sheet: { backgroundColor: '#fff', borderTopLeftRadius: 22, borderTopRightRadius: 22, padding: 16, paddingBottom: 24 },
  sheetTitle: { fontFamily: 'VazirmatnBold', fontSize: 14, color: COLORS.text, textAlign: 'center', marginBottom: 10 },
  optionRow: {
    minHeight: 48,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: '#EEEAE1',
    flexDirection: 'row-reverse',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 4,
  },
  optionText: { fontFamily: 'Vazirmatn', fontSize: 13, color: COLORS.text },
  sheetCancel: { marginTop: 10, minHeight: 44, borderRadius: 12, backgroundColor: '#F5F5F4', alignItems: 'center', justifyContent: 'center' },
  sheetCancelText: { fontFamily: 'VazirmatnBold', fontSize: 12, color: COLORS.muted },
});
