import React, { useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Alert, Image, KeyboardAvoidingView, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as DocumentPicker from 'expo-document-picker';
import * as ImagePicker from 'expo-image-picker';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ApiError, api } from '../api/api';
import { TrustCard } from '../components/TrustCard';
import type { DashboardStackParamList } from '../navigation/DashboardStackNavigator';
import { useAuthStore } from '../store/authStore';
import { COLORS } from '../theme/colors';
import { computeTrust, emptyProgress, isValidNationalCode, loadKycProgress, saveKycProgress, type KycProgress } from '../utils/trust';

type Props = NativeStackScreenProps<DashboardStackParamList, 'Kyc'>;
type Picked = { uri: string; name: string; mimeType?: string };

const MAX_BUSINESS_DOCS = 3;
const digitsOnly = (value: string) => value.replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d))).replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));

function SectionCard({ icon, title, subtitle, done, children }: { icon: keyof typeof MaterialCommunityIcons.glyphMap; title: string; subtitle: string; done: boolean; children: React.ReactNode }) {
  return (
    <View style={styles.sectionCard}>
      <View style={styles.sectionHead}>
        <View style={[styles.sectionIcon, done && styles.sectionIconDone]}><MaterialCommunityIcons name={done ? 'check-bold' : icon} size={20} color={done ? '#047857' : COLORS.primaryDark} /></View>
        <View style={styles.sectionCopy}><Text style={styles.sectionTitle}>{title}</Text><Text style={styles.sectionSubtitle}>{subtitle}</Text></View>
        <View style={[styles.chip, done ? styles.chipDone : styles.chipTodo]}><Text style={[styles.chipText, done ? styles.chipTextDone : styles.chipTextTodo]}>{done ? 'ارسال‌شده' : 'تکمیل نشده'}</Text></View>
      </View>
      {children}
    </View>
  );
}

function ImageSlot({ label, hint, value, onCamera, onLibrary, onClear }: { label: string; hint: string; value: Picked | null; onCamera: () => void; onLibrary: () => void; onClear: () => void }) {
  return (
    <View style={styles.slot}>
      <Text style={styles.label}>{label}</Text>
      {value ? (
        <View style={styles.preview}>
          <Image source={{ uri: value.uri }} resizeMode="cover" style={styles.previewImage} />
          <Pressable onPress={onClear} style={styles.previewClear} accessibilityLabel="حذف تصویر"><MaterialCommunityIcons name="close" size={16} color="#fff" /></Pressable>
        </View>
      ) : (
        <View style={styles.slotEmpty}><MaterialCommunityIcons name="image-plus" size={26} color="#B8A15A" /><Text style={styles.slotHint}>{hint}</Text></View>
      )}
      <View style={styles.slotActions}>
        <Pressable onPress={onCamera} style={styles.slotButton}><MaterialCommunityIcons name="camera-outline" size={17} color={COLORS.primaryDark} /><Text style={styles.slotButtonText}>دوربین</Text></Pressable>
        <Pressable onPress={onLibrary} style={styles.slotButton}><MaterialCommunityIcons name="image-multiple-outline" size={17} color={COLORS.primaryDark} /><Text style={styles.slotButtonText}>گالری</Text></Pressable>
      </View>
    </View>
  );
}

export function KycScreen({ navigation }: Props) {
  const user = useAuthStore((s) => s.user);
  const updateUser = useAuthStore((s) => s.updateUser);
  const [fullName, setFullName] = useState(user?.name ?? '');
  const [nationalId, setNationalId] = useState(user?.national_id ?? '');
  const [idCard, setIdCard] = useState<Picked | null>(null);
  const [selfie, setSelfie] = useState<Picked | null>(null);
  const [companyName, setCompanyName] = useState(user?.company_name ?? '');
  const [companyId, setCompanyId] = useState('');
  const [landline, setLandline] = useState(user?.landline ?? '');
  const [address, setAddress] = useState(user?.address ?? '');
  const [businessDocs, setBusinessDocs] = useState<Picked[]>([]);
  const [progress, setProgress] = useState<KycProgress>(emptyProgress());
  const [busy, setBusy] = useState(false);
  const userId = user?.id;

  useEffect(() => {
    if (userId === undefined) return;
    let cancelled = false;
    void loadKycProgress(userId).then((stored) => { if (!cancelled) setProgress(stored); });
    return () => { cancelled = true; };
  }, [userId]);

  const summary = useMemo(() => computeTrust(user, progress), [user, progress]);
  const identityDone = summary.steps.find((step) => step.id === 'identity')?.done ?? false;
  const selfieDone = summary.steps.find((step) => step.id === 'selfie')?.done ?? false;
  const businessDone = summary.steps.find((step) => step.id === 'business')?.done ?? false;
  const roleTitle = user?.role === 'buyer' ? 'خریدار' : user?.role === 'broker' ? 'ترخیص‌کار' : 'تأمین‌کننده';

  const pickImage = async (source: 'camera' | 'library'): Promise<Picked | null> => {
    try {
      if (source === 'camera') {
        const permission = await ImagePicker.requestCameraPermissionsAsync();
        if (!permission.granted) {
          Alert.alert('مجوز دوربین لازم است', 'برای عکس‌گرفتن، دسترسی دوربین را در تنظیمات گوشی فعال کنید.');
          return null;
        }
      }
      const options = { mediaTypes: ['images' as const], quality: 0.85, allowsEditing: false };
      const result = source === 'camera' ? await ImagePicker.launchCameraAsync(options) : await ImagePicker.launchImageLibraryAsync(options);
      if (result.canceled || !result.assets[0]) return null;
      const asset = result.assets[0];
      return { uri: asset.uri, name: asset.fileName || `kyc-${Date.now()}.jpg`, mimeType: asset.mimeType || 'image/jpeg' };
    } catch {
      Alert.alert('انتخاب تصویر انجام نشد', 'لطفاً مجوزها را بررسی و دوباره تلاش کنید.');
      return null;
    }
  };

  const pickBusinessDocs = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({ type: ['image/*', 'application/pdf'], multiple: true, copyToCacheDirectory: true });
      if (result.canceled) return;
      const added = result.assets.map((asset) => ({ uri: asset.uri, name: asset.name, mimeType: asset.mimeType }));
      setBusinessDocs((current) => [...current, ...added].slice(0, MAX_BUSINESS_DOCS));
    } catch {
      Alert.alert('انتخاب مدرک انجام نشد', 'لطفاً دوباره تلاش کنید.');
    }
  };

  const submit = async () => {
    if (!user) {
      Alert.alert('ورود لازم است', 'برای ارسال مدارک ابتدا وارد حساب کاربری شوید.');
      return;
    }
    const nid = digitsOnly(nationalId).replace(/\s/g, '') || String(user.national_id ?? '');
    const cid = digitsOnly(companyId).replace(/\s/g, '');
    const phone = digitsOnly(landline).replace(/[\s-]/g, '');
    const name = fullName.trim();
    const doIdentity = Boolean(idCard);
    const doSelfie = Boolean(selfie);
    const doBusiness = businessDocs.length > 0;

    if (!doIdentity && !doSelfie && !doBusiness) return Alert.alert('مدرکی انتخاب نشده', 'حداقل یک تصویر یا فایل مدرک را پیوست کنید.');
    if (doIdentity || doSelfie) {
      if (name.length < 3) return Alert.alert('نام کامل لازم است', 'نام و نام خانوادگی را همان‌طور که در کارت ملی آمده وارد کنید.');
      if (!isValidNationalCode(nid)) return Alert.alert('کد ملی نامعتبر است', 'کد ملی باید ۱۰ رقم و معتبر باشد.');
    }
    if (doSelfie && !identityDone && !doIdentity) return Alert.alert('ابتدا کارت ملی را بفرستید', 'برای تأیید چهره، تصویر کارت ملی هم لازم است.');
    if (doBusiness) {
      if (companyName.trim().length < 2) return Alert.alert('نام شرکت لازم است', 'نام شرکت یا کسب‌وکار را وارد کنید.');
      if (cid && !/^\d{11}$/.test(cid)) return Alert.alert('شناسهٔ ملی شرکت نامعتبر است', 'شناسهٔ ملی شرکت باید ۱۱ رقم باشد.');
      if (!/^\d{8,11}$/.test(phone)) return Alert.alert('تلفن ثابت نامعتبر است', 'شمارهٔ تلفن ثابت را با کد شهر وارد کنید.');
      if (address.trim().length < 10) return Alert.alert('نشانی کامل نیست', 'نشانی محل فعالیت را کامل وارد کنید.');
    }

    // Upload every file in one request; the server returns the URLs in the same order.
    const files: Array<{ asset: Picked; kind: string }> = [];
    if (idCard) files.push({ asset: idCard, kind: 'national_card' });
    if (selfie) files.push({ asset: selfie, kind: 'selfie_with_card' });
    businessDocs.forEach((asset) => files.push({ asset, kind: 'business_document' }));

    const formData = new FormData();
    files.forEach(({ asset }) => {
      formData.append('files[]', { uri: asset.uri, name: asset.name, type: asset.mimeType || 'application/octet-stream' } as unknown as Blob);
    });

    setBusy(true);
    try {
      const uploaded = await api.uploadVerificationFiles(formData);
      const uploadedFiles = uploaded.files ?? uploaded.data?.files ?? [];
      const documentUrls = uploadedFiles.map((file) => file.url).filter((url): url is string => Boolean(url));
      if (documentUrls.length !== files.length) throw new ApiError(uploaded.message || 'بارگذاری همهٔ مدارک از سرور تأیید نشد.');

      const levels: string[] = [];
      if (doIdentity) levels.push('identity');
      if (doSelfie) levels.push('selfie');
      if (doBusiness) levels.push('business');

      const result = await api.submitKyc({
        companyName: companyName.trim(),
        nationalId: nid,
        landline: phone,
        address: address.trim(),
        documents: documentUrls,
        fullName: name,
        companyNationalId: cid || undefined,
        documentTypes: files.map((file) => file.kind),
        levels,
      });

      const nextProgress: KycProgress = {
        identity: progress.identity || doIdentity,
        selfie: progress.selfie || doSelfie,
        business: progress.business || doBusiness,
        submittedAt: new Date().toISOString(),
      };
      await saveKycProgress(user.id, nextProgress);
      setProgress(nextProgress);

      const serverUser = result.user ?? result.data?.user;
      updateUser({
        ...(serverUser ?? {}),
        national_id: nid,
        ...(doBusiness ? { company_name: companyName.trim(), landline: phone, address: address.trim() } : {}),
      });

      setIdCard(null);
      setSelfie(null);
      setBusinessDocs([]);
      const nextStars = computeTrust({ ...user, national_id: nid }, nextProgress).stars;
      Alert.alert('مدارک ارسال شد', `ستارهٔ اعتماد شما به ${nextStars.toLocaleString('fa-IR')} از ۵ رسید. ستارهٔ پنجم پس از بررسی و تأیید مدارک توسط تیم چی میخوای فعال می‌شود.`, [{ text: 'بازگشت', onPress: () => navigation.goBack() }, { text: 'ماندن در صفحه', style: 'cancel' }]);
    } catch (error) {
      Alert.alert('ارسال مدارک ناموفق بود', error instanceof ApiError ? error.message : 'لطفاً دوباره تلاش کنید.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <View style={styles.header}><Pressable onPress={() => navigation.goBack()} style={styles.headerButton}><MaterialCommunityIcons name="arrow-right" size={22} color={COLORS.text} /></Pressable><Text style={styles.headerTitle}>احراز هویت {roleTitle}</Text><View style={styles.headerButton} /></View>
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          <TrustCard summary={summary} full />
          <View style={styles.notice}><MaterialCommunityIcons name="shield-lock-outline" size={17} color="#92400E" /><Text style={styles.noticeText}>هر مرحله را می‌توانید جداگانه بفرستید. مدارک فقط برای بررسی احراز هویت ارسال می‌شوند و پس از بررسی، وضعیت در داشبورد به‌روزرسانی می‌شود.</Text></View>

          <SectionCard icon="card-account-details-outline" title="۱. هویت فردی" subtitle="نام کامل، کد ملی و تصویر کارت ملی" done={identityDone}>
            <Text style={styles.label}>نام و نام خانوادگی (مطابق کارت ملی)</Text>
            <TextInput value={fullName} onChangeText={setFullName} placeholder="نام کامل" placeholderTextColor="#A8A29E" textAlign="right" style={styles.input} maxLength={80} />
            <Text style={styles.label}>کد ملی</Text>
            <TextInput value={nationalId} onChangeText={(value) => setNationalId(value.replace(/[^0-9۰-۹٠-٩]/g, '').slice(0, 10))} placeholder="۱۰ رقم" placeholderTextColor="#A8A29E" keyboardType="number-pad" textAlign="right" style={styles.input} maxLength={10} />
            <ImageSlot label="تصویر روی کارت ملی" hint="کارت را کامل و خوانا عکس بگیرید" value={idCard} onCamera={() => void pickImage('camera').then((picked) => picked && setIdCard(picked))} onLibrary={() => void pickImage('library').then((picked) => picked && setIdCard(picked))} onClear={() => setIdCard(null)} />
          </SectionCard>

          <SectionCard icon="face-recognition" title="۲. تأیید چهره" subtitle="سلفی همراه کارت ملی" done={selfieDone}>
            <ImageSlot label="سلفی با کارت ملی در دست" hint="صورت و کارت ملی هر دو در تصویر دیده شوند" value={selfie} onCamera={() => void pickImage('camera').then((picked) => picked && setSelfie(picked))} onLibrary={() => void pickImage('library').then((picked) => picked && setSelfie(picked))} onClear={() => setSelfie(null)} />
          </SectionCard>

          <SectionCard icon="domain" title="۳. کسب‌وکار" subtitle="اطلاعات شرکت و مدرک فعالیت" done={businessDone}>
            <Text style={styles.label}>نام شرکت / کسب‌وکار</Text>
            <TextInput value={companyName} onChangeText={setCompanyName} placeholder="نام رسمی شرکت یا مجموعه" placeholderTextColor="#A8A29E" textAlign="right" style={styles.input} maxLength={120} />
            <Text style={styles.label}>شناسهٔ ملی شرکت (اختیاری)</Text>
            <TextInput value={companyId} onChangeText={(value) => setCompanyId(value.replace(/[^0-9۰-۹٠-٩]/g, '').slice(0, 11))} placeholder="۱۱ رقم" placeholderTextColor="#A8A29E" keyboardType="number-pad" textAlign="right" style={styles.input} maxLength={11} />
            <Text style={styles.label}>تلفن ثابت با کد شهر</Text>
            <TextInput value={landline} onChangeText={(value) => setLandline(value.replace(/[^0-9۰-۹٠-٩-]/g, '').slice(0, 14))} placeholder="مثلاً ۰۲۱۱۲۳۴۵۶۷۸" placeholderTextColor="#A8A29E" keyboardType="phone-pad" textAlign="right" style={styles.input} maxLength={14} />
            <Text style={styles.label}>نشانی محل فعالیت</Text>
            <TextInput value={address} onChangeText={setAddress} placeholder="استان، شهر، خیابان و نشانی کامل" placeholderTextColor="#A8A29E" multiline textAlign="right" textAlignVertical="top" style={styles.addressInput} maxLength={500} />
            <Text style={styles.label}>مدرک فعالیت (پروانه کسب، روزنامه رسمی، کارت بازرگانی و ...)</Text>
            <Pressable onPress={() => void pickBusinessDocs()} style={styles.uploadBox}>
              <View style={styles.uploadIcon}><MaterialCommunityIcons name="cloud-upload-outline" size={20} color={COLORS.primaryDark} /></View>
              <View style={styles.uploadCopy}><Text style={styles.uploadTitle}>انتخاب فایل</Text><Text style={styles.uploadHint}>{`تصویر یا PDF · حداکثر ${MAX_BUSINESS_DOCS.toLocaleString('fa-IR')} فایل`}</Text></View>
              <MaterialCommunityIcons name="plus" size={19} color={COLORS.primaryDark} />
            </Pressable>
            {businessDocs.length ? (
              <View style={styles.fileList}>
                {businessDocs.map((document) => (
                  <View key={document.uri} style={styles.fileChip}>
                    <MaterialCommunityIcons name={document.mimeType?.startsWith('image/') ? 'image-outline' : 'file-pdf-box'} size={16} color={COLORS.primaryDark} />
                    <Text style={styles.fileName} numberOfLines={1}>{document.name}</Text>
                    <Pressable onPress={() => setBusinessDocs((current) => current.filter((item) => item.uri !== document.uri))}><MaterialCommunityIcons name="close-circle" size={17} color={COLORS.muted} /></Pressable>
                  </View>
                ))}
              </View>
            ) : null}
          </SectionCard>
        </ScrollView>
        <View style={styles.footer}><Pressable disabled={busy} onPress={() => void submit()} style={({ pressed }) => [styles.submitButton, pressed && { opacity: 0.86 }, busy && styles.disabled]}>{busy ? <ActivityIndicator color="#fff" /> : <><MaterialCommunityIcons name="send-check-outline" size={18} color="#fff" /><Text style={styles.submitText}>ارسال برای بررسی</Text></>}</Pressable></View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.background },
  flex: { flex: 1 },
  header: { minHeight: 56, paddingHorizontal: 17, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: '#EEEAE1' },
  headerButton: { width: 38, height: 38, borderRadius: 13, backgroundColor: '#fff', borderWidth: 1, borderColor: COLORS.border, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { fontFamily: 'VazirmatnBold', fontSize: 14, color: COLORS.text },
  content: { padding: 16, paddingBottom: 24 },
  notice: { flexDirection: 'row-reverse', alignItems: 'center', gap: 7, padding: 10, backgroundColor: '#FEF3C7', borderWidth: 1, borderColor: '#FDE68A', borderRadius: 13, marginBottom: 12 },
  noticeText: { flex: 1, fontFamily: 'Vazirmatn', fontSize: 8, color: '#92400E', textAlign: 'right', lineHeight: 15 },
  sectionCard: { padding: 15, borderRadius: 19, backgroundColor: '#fff', borderWidth: 1, borderColor: '#EAE6DC', marginBottom: 12 },
  sectionHead: { flexDirection: 'row-reverse', alignItems: 'center', gap: 10, marginBottom: 4 },
  sectionIcon: { width: 40, height: 40, borderRadius: 14, backgroundColor: '#F4E9C9', alignItems: 'center', justifyContent: 'center' },
  sectionIconDone: { backgroundColor: '#D1FAE5' },
  sectionCopy: { flex: 1 },
  sectionTitle: { fontFamily: 'VazirmatnBold', fontSize: 12, color: COLORS.text, textAlign: 'right' },
  sectionSubtitle: { fontFamily: 'Vazirmatn', fontSize: 8, color: COLORS.muted, textAlign: 'right', marginTop: 1 },
  chip: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 10 },
  chipDone: { backgroundColor: '#D1FAE5' },
  chipTodo: { backgroundColor: '#F5F5F4' },
  chipText: { fontFamily: 'VazirmatnBold', fontSize: 8 },
  chipTextDone: { color: '#047857' },
  chipTextTodo: { color: COLORS.muted },
  label: { fontFamily: 'VazirmatnMedium', fontSize: 11, color: COLORS.text, textAlign: 'right', marginTop: 11, marginBottom: 6 },
  input: { minHeight: 44, fontFamily: 'Vazirmatn', fontSize: 11, color: COLORS.text, backgroundColor: COLORS.background, borderWidth: 1, borderColor: COLORS.border, borderRadius: 12, paddingHorizontal: 11, paddingVertical: 10 },
  addressInput: { minHeight: 92, fontFamily: 'Vazirmatn', fontSize: 10, lineHeight: 19, color: COLORS.text, backgroundColor: COLORS.background, borderWidth: 1, borderColor: COLORS.border, borderRadius: 12, paddingHorizontal: 11, paddingVertical: 10 },
  slot: { marginTop: 2 },
  slotEmpty: { minHeight: 112, alignItems: 'center', justifyContent: 'center', gap: 6, borderRadius: 14, borderWidth: 1, borderStyle: 'dashed', borderColor: '#D6C58D', backgroundColor: '#FFFBEB', paddingHorizontal: 14 },
  slotHint: { fontFamily: 'Vazirmatn', fontSize: 9, lineHeight: 16, color: '#92400E', textAlign: 'center' },
  preview: { height: 150, borderRadius: 14, overflow: 'hidden', backgroundColor: '#E7E5E4' },
  previewImage: { width: '100%', height: '100%' },
  previewClear: { position: 'absolute', top: 8, left: 8, width: 28, height: 28, borderRadius: 14, backgroundColor: 'rgba(0,0,0,0.55)', alignItems: 'center', justifyContent: 'center' },
  slotActions: { flexDirection: 'row-reverse', gap: 8, marginTop: 8 },
  slotButton: { flex: 1, minHeight: 40, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', gap: 6, borderRadius: 12, backgroundColor: '#F4E9C9' },
  slotButtonText: { fontFamily: 'VazirmatnBold', fontSize: 10, color: COLORS.primaryDark },
  uploadBox: { minHeight: 64, flexDirection: 'row-reverse', alignItems: 'center', gap: 9, padding: 10, borderRadius: 13, borderWidth: 1, borderStyle: 'dashed', borderColor: '#D6C58D', backgroundColor: '#FFFBEB' },
  uploadIcon: { width: 36, height: 36, borderRadius: 12, backgroundColor: '#F4E9C9', alignItems: 'center', justifyContent: 'center' },
  uploadCopy: { flex: 1 },
  uploadTitle: { fontFamily: 'VazirmatnBold', fontSize: 10, color: COLORS.text, textAlign: 'right' },
  uploadHint: { fontFamily: 'Vazirmatn', fontSize: 8, color: COLORS.muted, textAlign: 'right', marginTop: 2 },
  fileList: { gap: 6, marginTop: 8 },
  fileChip: { flexDirection: 'row-reverse', alignItems: 'center', gap: 7, paddingHorizontal: 9, paddingVertical: 7, backgroundColor: '#F5F5F4', borderRadius: 10 },
  fileName: { flex: 1, fontFamily: 'Vazirmatn', fontSize: 9, color: COLORS.text, textAlign: 'right' },
  footer: { paddingHorizontal: 16, paddingVertical: 10, borderTopWidth: 1, borderTopColor: COLORS.border, backgroundColor: 'rgba(250,250,249,0.98)' },
  submitButton: { minHeight: 49, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', gap: 7, backgroundColor: COLORS.primaryDark, borderRadius: 14 },
  submitText: { fontFamily: 'VazirmatnBold', color: '#fff', fontSize: 13 },
  disabled: { opacity: 0.65 },
});
