import React, { useState } from 'react';
import { ActivityIndicator, Alert, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ApiError } from '../api/api';
import { RootStackParamList } from '../navigation/RootNavigator';
import { useAuthStore } from '../store/authStore';
import { COLORS } from '../theme/colors';

type Props = NativeStackScreenProps<RootStackParamList, 'Otp'>;
const digitsOnly = (value: string) => value.replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d))).replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));

export function OtpScreen({ route, navigation }: Props) {
  const { mobile } = route.params;
  const verifyOtp = useAuthStore((s) => s.verifyOtp);
  const clearPendingRegistration = useAuthStore((s) => s.clearPendingRegistration);
  const busy = useAuthStore((s) => s.busy);
  const [otp, setOtp] = useState('');

  const onVerify = async () => {
    const normalizedOtp = digitsOnly(otp).replace(/\D/g, '');
    if (normalizedOtp.length !== 5) return Alert.alert('کد نامعتبر است', 'کد تأیید باید دقیقاً ۵ رقم باشد.');
    try {
      await verifyOtp(normalizedOtp);
    } catch (error) {
      Alert.alert('تأیید انجام نشد', error instanceof ApiError ? error.message : 'کد تأیید نامعتبر است یا اطلاعات ثبت‌نام پیدا نشد.');
    }
  };

  const onBack = () => {
    clearPendingRegistration();
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <Pressable onPress={onBack} style={styles.backButton}><Text style={styles.back}>بازگشت ←</Text></Pressable>
      <View style={styles.mark}><Text style={styles.markText}>✓</Text></View>
      <Text style={styles.eyebrow}>مرحلهٔ نهایی ثبت‌نام</Text>
      <Text style={styles.title}>شماره‌تان را تأیید کنید</Text>
      <Text style={styles.subtitle}>کد ارسال‌شده به {mobile} را وارد کنید</Text>
      <TextInput value={otp} onChangeText={(value) => setOtp(value.replace(/[^0-9۰-۹٠-٩]/g, '').slice(0, 5))} placeholder="— — — — —" placeholderTextColor="#A8A29E" keyboardType="number-pad" textAlign="center" maxLength={5} style={styles.input} autoFocus />
      <Pressable onPress={onVerify} disabled={busy} style={({ pressed }) => [styles.button, pressed && { opacity: 0.85 }, busy && { opacity: 0.65 }]}>
        {busy ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>تأیید و ساخت حساب</Text>}
      </Pressable>
      <Text style={styles.hint}>اگر پیامک را دریافت نکردید، شمارهٔ واردشده یا سرویس پیامک را بررسی کنید.</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background, padding: 24, justifyContent: 'center' },
  backButton: { position: 'absolute', top: 30, left: 24, zIndex: 1 },
  back: { fontFamily: 'VazirmatnMedium', color: COLORS.primaryDark, fontSize: 14 },
  mark: { width: 66, height: 66, borderRadius: 23, alignSelf: 'center', backgroundColor: '#FEF3C7', alignItems: 'center', justifyContent: 'center', marginBottom: 18 },
  markText: { fontFamily: 'VazirmatnBold', fontSize: 30, color: COLORS.primaryDark },
  eyebrow: { fontFamily: 'VazirmatnMedium', fontSize: 11, color: COLORS.primaryDark, textAlign: 'center', marginBottom: 5 },
  title: { fontFamily: 'VazirmatnBold', fontSize: 22, color: COLORS.text, textAlign: 'center' },
  subtitle: { fontFamily: 'Vazirmatn', fontSize: 13, color: COLORS.muted, textAlign: 'center', marginTop: 8, marginBottom: 24 },
  input: { fontFamily: 'VazirmatnBold', letterSpacing: 7, fontSize: 21, color: COLORS.text, backgroundColor: COLORS.surface, borderWidth: 1, borderColor: '#E7E2D6', borderRadius: 15, padding: 16, marginBottom: 14 },
  button: { backgroundColor: COLORS.primaryDark, borderRadius: 14, minHeight: 52, alignItems: 'center', justifyContent: 'center' },
  buttonText: { fontFamily: 'VazirmatnBold', color: '#fff', fontSize: 14 },
  hint: { fontFamily: 'Vazirmatn', color: COLORS.muted, textAlign: 'center', fontSize: 11, marginTop: 16, lineHeight: 20 },
});
