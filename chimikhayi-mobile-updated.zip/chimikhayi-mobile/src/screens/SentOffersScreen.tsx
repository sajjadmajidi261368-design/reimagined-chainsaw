import React, { useCallback, useMemo, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, RefreshControl, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ApiError, api, type MyOfferItem, type MyRequestItem } from '../api/api';
import type { DashboardStackParamList } from '../navigation/DashboardStackNavigator';
import { useAuthStore } from '../store/authStore';
import { COLORS } from '../theme/colors';
import { extractArray } from '../utils/collections';

type Props = NativeStackScreenProps<DashboardStackParamList, 'SentOffers'>;
type StatusFilter = 'all' | 'pending' | 'accepted' | 'rejected';

const KEYS = ['offers', 'requests', 'items', 'results', 'rows', 'data'];

export function statusOf(status?: string): { key: StatusFilter; label: string; color: string; background: string } {
  const key = (status || 'pending').toLowerCase();
  if (key === 'accepted') return { key: 'accepted', label: 'پذیرفته‌شده', color: '#047857', background: '#D1FAE5' };
  if (key === 'rejected') return { key: 'rejected', label: 'ردشده', color: '#B91C1C', background: '#FEE2E2' };
  return { key: 'pending', label: 'در انتظار', color: '#92400E', background: '#FEF3C7' };
}
export function formatMoney(value: number | string, currency?: string): string {
  const numeric = Number(value);
  return `${Number.isFinite(numeric) ? numeric.toLocaleString('fa-IR') : String(value)} ${currency || 'تومان'}`;
}
export function formatDate(value?: string): string {
  if (!value) return '';
  const date = new Date(value.replace(' ', 'T'));
  return Number.isNaN(date.getTime()) ? '' : date.toLocaleDateString('fa-IR', { year: 'numeric', month: 'long', day: 'numeric' });
}

export function SentOffersScreen({ navigation }: Props) {
  const user = useAuthStore((s) => s.user);
  const logout = useAuthStore((s) => s.logout);
  const isBuyer = user?.role === 'buyer';
  const [offers, setOffers] = useState<MyOfferItem[]>([]);
  const [requests, setRequests] = useState<MyRequestItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<StatusFilter>('all');

  const load = useCallback(async (refresh = false) => {
    refresh ? setRefreshing(true) : setLoading(true);
    setError(null);
    try {
      if (useAuthStore.getState().user?.role === 'buyer') setRequests(extractArray<MyRequestItem>(await api.getMyRequests(), KEYS));
      else setOffers(extractArray<MyOfferItem>(await api.getMyOffers(), KEYS));
    } catch (cause) {
      if (cause instanceof ApiError && cause.code === 'auth') {
        logout();
        return;
      }
      setError(cause instanceof ApiError ? cause.message : 'دریافت فهرست انجام نشد.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [logout]);

  useFocusEffect(useCallback(() => { void load(); }, [load]));

  const counts = useMemo(() => ({
    all: offers.length,
    pending: offers.filter((item) => statusOf(item.status).key === 'pending').length,
    accepted: offers.filter((item) => statusOf(item.status).key === 'accepted').length,
    rejected: offers.filter((item) => statusOf(item.status).key === 'rejected').length,
  }), [offers]);
  const visibleOffers = useMemo(() => (filter === 'all' ? offers : offers.filter((item) => statusOf(item.status).key === filter)), [filter, offers]);

  const openRequest = (requestId: string | number) => {
    const tabs = navigation.getParent() as unknown as { navigate: (name: string, params: object) => void } | undefined;
    tabs?.navigate('HomeTab', { screen: 'RequestDetail', params: { requestId } });
  };

  const renderOffer = ({ item }: { item: MyOfferItem }) => {
    const status = statusOf(item.status);
    return (
      <Pressable onPress={() => navigation.navigate('SentOfferDetail', { offer: item })} style={({ pressed }) => [styles.card, pressed && { opacity: 0.85 }]}>
        <View style={styles.cardTop}>
          <View style={[styles.badge, { backgroundColor: status.background }]}><Text style={[styles.badgeText, { color: status.color }]}>{status.label}</Text></View>
          <Text style={styles.metaText}>{formatDate(item.created_at)}</Text>
        </View>
        <Text style={styles.cardTitle} numberOfLines={2}>{item.request_title ?? item.title ?? 'درخواست کالا'}</Text>
        <View style={styles.cardBottom}>
          <MaterialCommunityIcons name="chevron-left" size={19} color={COLORS.primaryDark} />
          <Text style={styles.metaText}>{item.delivery_time ? `تحویل: ${item.delivery_time}` : ''}</Text>
          <Text style={styles.price}>{formatMoney(item.price, item.currency)}</Text>
        </View>
      </Pressable>
    );
  };

  const renderRequest = ({ item }: { item: MyRequestItem }) => {
    const open = (item.status || 'open').toLowerCase() === 'open';
    const count = Number(item.offers_count ?? 0) || 0;
    return (
      <Pressable onPress={() => openRequest(item.id)} style={({ pressed }) => [styles.card, pressed && { opacity: 0.85 }]}>
        <View style={styles.cardTop}>
          <View style={[styles.badge, { backgroundColor: open ? '#DCFCE7' : '#F5F5F4' }]}><Text style={[styles.badgeText, { color: open ? '#047857' : COLORS.muted }]}>{open ? 'باز' : 'بسته'}</Text></View>
          <Text style={styles.metaText}>{formatDate(item.created_at)}</Text>
        </View>
        <Text style={styles.cardTitle} numberOfLines={2}>{item.title || 'درخواست بدون عنوان'}</Text>
        <View style={styles.cardBottom}>
          <MaterialCommunityIcons name="chevron-left" size={19} color={COLORS.primaryDark} />
          <Text style={styles.price}>{`${count.toLocaleString('fa-IR')} پیشنهاد دریافتی`}</Text>
        </View>
      </Pressable>
    );
  };

  const filters: Array<{ id: StatusFilter; label: string }> = [{ id: 'all', label: 'همه' }, { id: 'pending', label: 'در انتظار' }, { id: 'accepted', label: 'پذیرفته' }, { id: 'rejected', label: 'ردشده' }];
  const total = isBuyer ? requests.length : offers.length;

  let empty: React.ReactElement | null = null;
  if (loading && total === 0) empty = <View style={styles.state}><ActivityIndicator size="large" color={COLORS.primary} /></View>;
  else if (error && total === 0) empty = <View style={styles.state}><MaterialCommunityIcons name="cloud-alert-outline" size={32} color={COLORS.danger} /><Text style={styles.stateTitle}>بارگذاری انجام نشد</Text><Text style={styles.stateText}>{error}</Text><Pressable onPress={() => void load()} style={styles.retry}><Text style={styles.retryText}>تلاش دوباره</Text></Pressable></View>;
  else if (total === 0) empty = <View style={styles.state}><MaterialCommunityIcons name={isBuyer ? 'clipboard-text-outline' : 'send-outline'} size={32} color={COLORS.muted} /><Text style={styles.stateTitle}>{isBuyer ? 'هنوز درخواستی ثبت نکرده‌اید' : 'هنوز پیشنهادی نفرستاده‌اید'}</Text><Text style={styles.stateText}>{isBuyer ? 'اولین درخواست خود را از داشبورد ثبت کنید.' : 'از صفحهٔ اصلی یک درخواست را باز کنید و پیشنهاد بدهید.'}</Text></View>;
  else if (!isBuyer && visibleOffers.length === 0) empty = <View style={styles.state}><MaterialCommunityIcons name="filter-remove-outline" size={30} color={COLORS.muted} /><Text style={styles.stateTitle}>موردی با این وضعیت نیست</Text></View>;

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} style={styles.headerButton} accessibilityLabel="بازگشت"><MaterialCommunityIcons name="arrow-right" size={22} color={COLORS.text} /></Pressable>
        <View style={styles.headerCopy}><Text style={styles.headerTitle}>{isBuyer ? 'درخواست‌های من' : 'پیشنهادهای ارسال‌شده'}</Text><Text style={styles.headerSubtitle}>{`${total.toLocaleString('fa-IR')} مورد`}</Text></View>
        <View style={styles.headerButton} />
      </View>
      {!isBuyer && offers.length > 0 ? (
        <View style={styles.filters}>
          {filters.map((item) => (
            <Pressable key={item.id} onPress={() => setFilter(item.id)} style={[styles.filter, filter === item.id && styles.filterActive]}>
              <Text style={[styles.filterText, filter === item.id && styles.filterTextActive]}>{`${item.label} ${counts[item.id].toLocaleString('fa-IR')}`}</Text>
            </Pressable>
          ))}
        </View>
      ) : null}
      {isBuyer ? (
        <FlatList data={requests} keyExtractor={(item, index) => String(item.id ?? index)} renderItem={renderRequest} contentContainerStyle={styles.list} ListEmptyComponent={empty} showsVerticalScrollIndicator={false} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => void load(true)} tintColor={COLORS.primary} colors={[COLORS.primary]} />} />
      ) : (
        <FlatList data={visibleOffers} keyExtractor={(item, index) => String(item.id ?? index)} renderItem={renderOffer} contentContainerStyle={styles.list} ListEmptyComponent={empty} showsVerticalScrollIndicator={false} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => void load(true)} tintColor={COLORS.primary} colors={[COLORS.primary]} />} />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.background },
  header: { minHeight: 60, paddingHorizontal: 16, flexDirection: 'row-reverse', alignItems: 'center', gap: 10, borderBottomWidth: 1, borderBottomColor: '#EEEAE1', backgroundColor: '#fff' },
  headerButton: { width: 38, height: 38, borderRadius: 13, backgroundColor: COLORS.background, borderWidth: 1, borderColor: COLORS.border, alignItems: 'center', justifyContent: 'center' },
  headerCopy: { flex: 1, alignItems: 'center' },
  headerTitle: { fontFamily: 'VazirmatnBold', fontSize: 14, color: COLORS.text },
  headerSubtitle: { fontFamily: 'Vazirmatn', fontSize: 9, color: COLORS.muted, marginTop: 1 },
  filters: { flexDirection: 'row-reverse', gap: 7, paddingHorizontal: 15, paddingTop: 12 },
  filter: { flex: 1, minHeight: 36, borderRadius: 12, backgroundColor: '#F1EEE6', alignItems: 'center', justifyContent: 'center' },
  filterActive: { backgroundColor: COLORS.primaryDark },
  filterText: { fontFamily: 'VazirmatnMedium', fontSize: 9, color: COLORS.muted },
  filterTextActive: { fontFamily: 'VazirmatnBold', color: '#fff' },
  list: { padding: 15, paddingBottom: 24, flexGrow: 1 },
  card: { padding: 14, backgroundColor: '#fff', borderRadius: 17, borderWidth: 1, borderColor: '#EAE6DC', marginBottom: 10 },
  cardTop: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between' },
  badge: { paddingHorizontal: 9, paddingVertical: 4, borderRadius: 12 },
  badgeText: { fontFamily: 'VazirmatnBold', fontSize: 9 },
  metaText: { fontFamily: 'Vazirmatn', fontSize: 9, color: COLORS.muted },
  cardTitle: { fontFamily: 'VazirmatnBold', fontSize: 12, lineHeight: 20, color: COLORS.text, textAlign: 'right', marginTop: 9 },
  cardBottom: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 10, paddingTop: 9, borderTopWidth: 1, borderTopColor: '#F5F5F4' },
  price: { fontFamily: 'VazirmatnBold', fontSize: 11, color: COLORS.primaryDark },
  state: { flex: 1, minHeight: 240, alignItems: 'center', justifyContent: 'center', gap: 8, padding: 22 },
  stateTitle: { fontFamily: 'VazirmatnBold', fontSize: 13, color: COLORS.text, textAlign: 'center' },
  stateText: { fontFamily: 'Vazirmatn', fontSize: 10, lineHeight: 19, color: COLORS.muted, textAlign: 'center' },
  retry: { marginTop: 4, backgroundColor: COLORS.primaryDark, borderRadius: 11, paddingHorizontal: 17, paddingVertical: 8 },
  retryText: { fontFamily: 'VazirmatnBold', color: '#fff', fontSize: 10 },
});
