import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ActivityIndicator, Alert, FlatList, Image, KeyboardAvoidingView, Linking, Modal, Platform, Pressable, StyleSheet, Text, TextInput, View, type NativeScrollEvent, type NativeSyntheticEvent } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as DocumentPicker from 'expo-document-picker';
import * as ImagePicker from 'expo-image-picker';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ApiError, api, type ChatMessage, type MessagesResult } from '../api/api';
import { mediaUrl } from '../api/media';
import type { MessagesStackParamList } from '../navigation/MessagesStackNavigator';
import { useAuthStore } from '../store/authStore';
import { COLORS } from '../theme/colors';
import { getDraftText, getHiddenUpTo, removeDraft, saveDraftText } from '../utils/chatLocal';

type Props = NativeStackScreenProps<MessagesStackParamList, 'ChatRoom'>;
type IconName = keyof typeof MaterialCommunityIcons.glyphMap;

function parseDate(value?: string): Date | null {
  if (!value) return null;
  const date = new Date(value.replace(' ', 'T'));
  return Number.isNaN(date.getTime()) ? null : date;
}
function messagesFrom(result: MessagesResult): ChatMessage[] {
  const messages = Array.isArray(result) ? result : result.messages ?? result.data ?? result.items ?? [];
  return [...messages].sort((a, b) => (parseDate(b.created_at)?.getTime() ?? 0) - (parseDate(a.created_at)?.getTime() ?? 0));
}
function sameMessages(a: ChatMessage[], b: ChatMessage[]): boolean {
  if (a.length !== b.length) return false;
  return a.every((item, index) => String(item.id) === String(b[index].id) && String(item.is_read ?? '') === String(b[index].is_read ?? ''));
}
function messageSenderId(item: ChatMessage): string | undefined {
  const sender = item.sender;
  const value = item.sender_id ?? item.user_id ?? item.from_id ?? item.from_user_id ?? item.author_id ?? (typeof sender === 'object' && sender ? sender.id ?? sender.user_id : sender);
  return value === undefined || value === null ? undefined : String(value);
}
function flagIsTrue(value?: boolean | number | string): boolean {
  return value === true || value === 1 || ['1', 'true', 'yes'].includes(String(value ?? '').toLowerCase());
}
function isMine(item: ChatMessage, currentUserId?: number | string): boolean {
  if (flagIsTrue(item.is_mine)) return true;
  if (currentUserId === undefined || currentUserId === null) return false;
  const senderId = messageSenderId(item);
  return senderId !== undefined && senderId === String(currentUserId);
}
function timeLabel(value?: string): string {
  const date = parseDate(value);
  return date ? date.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }) : '';
}
function dayKey(date: Date): string {
  return `${date.getFullYear()}-${date.getMonth()}-${date.getDate()}`;
}
function dayLabel(date: Date): string {
  const now = new Date();
  if (dayKey(date) === dayKey(now)) return 'امروز';
  const yesterday = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
  if (dayKey(date) === dayKey(yesterday)) return 'دیروز';
  try {
    return date.toLocaleDateString('fa-IR', { weekday: 'long', day: 'numeric', month: 'long' });
  } catch {
    return date.toLocaleDateString('fa-IR');
  }
}
function fileIcon(name?: string, type?: string): IconName {
  const text = `${name ?? ''} ${type ?? ''}`.toLowerCase();
  if (/pdf/.test(text)) return 'file-pdf-box';
  if (/doc|word/.test(text)) return 'file-word-box';
  if (/xls|sheet|excel|csv/.test(text)) return 'file-excel-box';
  if (/zip|rar|7z/.test(text)) return 'folder-zip-outline';
  return 'paperclip';
}

function normalizeOwnMessage(item: Partial<ChatMessage> | undefined, requestId: string | number, currentUserId: string | number, fallbackId: string): ChatMessage {
  return {
    ...(item ?? {}),
    id: item?.id ?? fallbackId,
    request_id: item?.request_id ?? requestId,
    sender_id: item?.sender_id ?? item?.user_id ?? item?.from_id ?? item?.from_user_id ?? currentUserId,
    message: item?.message ?? '',
    is_mine: item?.is_mine ?? 1,
  };
}

export const LOST_OFFER_MESSAGE = 'پیشنهاد دیگری انتخاب شد. با ارسال پیشنهاد بهتر شانس برنده شدن شما بیشتر می‌شود.';

const BUYER_QUICK_REPLIES = ['سلام، پیشنهادتان را دیدم. امکان اصلاح قیمت وجود دارد؟', 'زمان تحویل دقیق چقدر است؟', 'آیا امکان ارسال نمونه یا مشخصات فنی کامل‌تر هست؟'];
const SUPPLIER_QUICK_REPLIES = ['سلام و وقت بخیر. پیشنهاد من را مشاهده کردید؟', 'اگر سؤال یا نیاز به توضیح بیشتری هست، در خدمتم.', 'برای هماهنگی نهایی تماس یا گفتگو را ادامه دهیم؟'];

export function ChatRoomScreen({ route, navigation }: Props) {
  const { requestId, peerId, peerName, requestTitle, peerAvatar, outcome } = route.params;
  const user = useAuthStore((state) => state.user);
  const logout = useAuthStore((state) => state.logout);
  const chatActive = Boolean(user);
  // قاعده ساده: lost → بسته | در غیر این صورت (won یا آگهی باز) → باز
  const lost = outcome === 'lost';
  const won = outcome === 'won';
  const [chatLocked, setChatLocked] = useState(lost);
  const [lockReason, setLockReason] = useState(lost ? LOST_OFFER_MESSAGE : '');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [attachmentMenuVisible, setAttachmentMenuVisible] = useState(false);
  const [infoVisible, setInfoVisible] = useState(false);
  const [viewerUri, setViewerUri] = useState<string | null>(null);
  const [showJump, setShowJump] = useState(false);
  const [draft, setDraft] = useState('');
  const [avatarFailed, setAvatarFailed] = useState(false);
  const listRef = useRef<FlatList<ChatMessage>>(null);
  const lastCountRef = useRef(0);
  const hiddenUpToRef = useRef(0);
  const draftRef = useRef('');
  const [draftReady, setDraftReady] = useState(false);
  const userId = user?.id;
  const threadRef = useMemo(() => ({ requestId, peerId, peerName, requestTitle, peerAvatar }), [requestId, peerId, peerName, requestTitle, peerAvatar]);
  draftRef.current = draft;
  const busyRef = useRef(false);
  busyRef.current = sending || uploading;

  // وقتی از یک چت به چت دیگر می‌رویم (بدون unmount)، وضعیت را از نو تنظیم کن
  // تا پیام‌ها و قفل چت روی چت قبلی نماند
  useEffect(() => {
    setMessages([]);
    setDraft('');
    setDraftReady(false);
    setAvatarFailed(false);
    setShowJump(false);
    setViewerUri(null);
    lastCountRef.current = 0;
    hiddenUpToRef.current = 0;
    if (lost) {
      setChatLocked(true);
      setLockReason(LOST_OFFER_MESSAGE);
    } else {
      setChatLocked(false);
      setLockReason('');
    }
  }, [requestId, peerId, lost]);

  // `silent` is used by background polling: no spinner, no error alerts, and it never
  // overwrites the list while a message or file is being sent.
  const loadMessages = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const result = await api.getMessages(requestId, peerId);
      if (silent && busyRef.current) return;

      // قاعده ساده: فقط outcome تعیین‌کننده است
      // lost → بسته | won یا بدون outcome (آگهی باز) → باز
      // allow_chat سرور دیگر قفل را برعکس نمی‌کند
      if (lost) {
        setChatLocked(true);
        setLockReason(LOST_OFFER_MESSAGE);
      } else {
        setChatLocked(false);
        setLockReason('');
      }
      // Messages the user deleted earlier stay hidden on this device; newer ones show normally.
      const next = messagesFrom(result).filter((message) => {
        if (!hiddenUpToRef.current) return true;
        const time = parseDate(message.created_at)?.getTime();
        return time === undefined || time > hiddenUpToRef.current;
      });
      setMessages((current) => sameMessages(current, next) ? current : next);
      if (silent && next.length > lastCountRef.current) {
        void api.markRead({ request_id: requestId, peer_id: peerId }).catch(() => undefined);
      }
      lastCountRef.current = next.length;
    } catch (error) {
      if (error instanceof ApiError && error.code === 'auth') {
        logout();
        return;
      }
      if (!silent) Alert.alert('پیام‌ها بارگذاری نشدند', error instanceof ApiError ? error.message : 'لطفاً دوباره تلاش کنید.');
    } finally {
      if (!silent) setLoading(false);
    }
  }, [logout, peerId, requestId, lost]);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      if (userId !== undefined) {
        hiddenUpToRef.current = await getHiddenUpTo(userId, requestId, peerId);
        const saved = await getDraftText(userId, requestId, peerId);
        if (!cancelled && saved) setDraft(saved);
      }
      if (!cancelled) {
        setDraftReady(true);
        await loadMessages();
      }
    })();
    void api.markRead({ request_id: requestId, peer_id: peerId }).catch(() => undefined);
    return () => { cancelled = true; };
  }, [loadMessages, peerId, requestId, userId]);

  // Keep unsent text as a draft so the conversation (and what was typed) survives leaving the screen.
  useEffect(() => {
    if (!draftReady || userId === undefined) return undefined;
    const timer = setTimeout(() => { void saveDraftText(userId, threadRef, draft); }, 500);
    return () => clearTimeout(timer);
  }, [draft, draftReady, threadRef, userId]);
  useEffect(() => () => {
    if (userId !== undefined) void saveDraftText(userId, threadRef, draftRef.current);
  }, [threadRef, userId]);

  // Pick up new incoming messages while the chat is open.
  useEffect(() => {
    const timer = setInterval(() => {
      if (!busyRef.current) void loadMessages(true);
    }, 8000);
    return () => clearInterval(timer);
  }, [loadMessages]);

  const peerPhoto = useMemo(() => mediaUrl(peerAvatar), [peerAvatar]);
  const quickReplies = user?.role === 'buyer' ? BUYER_QUICK_REPLIES : SUPPLIER_QUICK_REPLIES;

  const scrollToLatest = () => requestAnimationFrame(() => listRef.current?.scrollToOffset({ offset: 0, animated: true }));

  const send = async () => {
    const message = draft.trim();
    if (!message || sending || !chatActive || chatLocked) {
      if (chatLocked) Alert.alert('گفتگو بسته است', lockReason || 'امکان ارسال پیام وجود ندارد.');
      return;
    }
    setSending(true);
    const temporaryId = `local-${Date.now()}`;
    const optimisticMessage: ChatMessage = {
      id: temporaryId,
      request_id: requestId,
      sender_id: user?.id ?? 'me',
      receiver_id: peerId,
      message,
      created_at: new Date().toISOString(),
    };
    setMessages((current) => [optimisticMessage, ...current]);
    try {
      const result = await api.sendMessage({ request_id: requestId, receiver_id: peerId, message });
      const saved = result.data ?? (typeof result.message === 'object' ? result.message : undefined);
      const normalized = normalizeOwnMessage(saved ?? optimisticMessage, requestId, user?.id ?? 'me', temporaryId);
      setMessages((current) => [normalized, ...current.filter((item) => item.id !== temporaryId)]);
      setDraft('');
      draftRef.current = '';
      if (userId !== undefined) void removeDraft(userId, requestId, peerId);
      scrollToLatest();
    } catch (error) {
      setMessages((current) => current.filter((item) => item.id !== temporaryId));
      if (error instanceof ApiError && error.code === 'auth') {
        logout();
      } else {
        Alert.alert('ارسال پیام انجام نشد', error instanceof ApiError ? error.message : 'لطفاً دوباره تلاش کنید.');
      }
    } finally {
      setSending(false);
    }
  };

  const uploadAndSendFile = async (asset: { uri: string; name: string; mimeType?: string }) => {
    if (!user || uploading || sending || chatLocked) {
      if (chatLocked) Alert.alert('گفتگو بسته است', lockReason || 'امکان ارسال پیوست وجود ندارد.');
      return;
    }
    setUploading(true);
    try {
      const formData = new FormData();
      formData.append('file', { uri: asset.uri, name: asset.name, type: asset.mimeType || 'application/octet-stream' } as unknown as Blob);
      formData.append('request_id', String(requestId));
      if (peerId !== undefined && peerId !== null) formData.append('receiver_id', String(peerId));
      const uploaded = await api.uploadChatFile(formData);
      const file = uploaded.data ?? uploaded.file ?? uploaded;
      const fileUrl = file.file_url ?? file.file_path ?? file.url ?? file.path;
      if (!fileUrl) throw new ApiError(uploaded.message || 'آدرس فایل در پاسخ سرور وجود ندارد.');
      const fileName = file.file_name || file.name || asset.name;
      const fileType = file.file_type || file.mime_type || file.type || asset.mimeType || 'application/octet-stream';
      const sent = await api.sendMessage({ request_id: requestId, receiver_id: peerId, message: '', file_name: fileName, file_url: fileUrl, file_type: fileType });
      const saved = sent.data ?? (typeof sent.message === 'object' ? sent.message : undefined);
      const fallback: ChatMessage = {
        id: `local-file-${Date.now()}`,
        request_id: requestId,
        sender_id: user.id,
        receiver_id: peerId,
        message: '',
        file_name: fileName,
        file_url: fileUrl,
        file_type: fileType,
        created_at: new Date().toISOString(),
        is_mine: 1,
      };
      const normalized = normalizeOwnMessage(saved ?? fallback, requestId, user.id, String(fallback.id));
      setMessages((current) => [normalized, ...current]);
      if (userId !== undefined) void removeDraft(userId, requestId, peerId);
      scrollToLatest();
    } catch (error) {
      if (error instanceof ApiError && error.code === 'auth') logout();
      else Alert.alert('ارسال پیوست انجام نشد', error instanceof ApiError ? error.message : 'آپلود فایل یا ثبت پیام ناموفق بود. لطفاً دوباره تلاش کنید.');
    } finally {
      setUploading(false);
    }
  };

  const chooseDocument = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({ type: '*/*', copyToCacheDirectory: true, multiple: false });
      if (!result.canceled && result.assets[0]) {
        const asset = result.assets[0];
        await uploadAndSendFile({ uri: asset.uri, name: asset.name, mimeType: asset.mimeType });
      }
    } catch {
      Alert.alert('انتخاب فایل انجام نشد', 'دوباره تلاش کنید یا دسترسی فایل‌ها را بررسی کنید.');
    }
  };

  const chooseImage = async (source: 'camera' | 'library') => {
    try {
      const permission = source === 'camera'
        ? await ImagePicker.requestCameraPermissionsAsync()
        : await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!permission.granted) return Alert.alert('مجوز لازم است', source === 'camera' ? 'برای عکس‌گرفتن، دسترسی دوربین را فعال کنید.' : 'برای انتخاب تصویر، دسترسی گالری را فعال کنید.');
      const result = source === 'camera'
        ? await ImagePicker.launchCameraAsync({ mediaTypes: ['images'], quality: 0.85 })
        : await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.85 });
      if (!result.canceled && result.assets[0]) {
        const asset = result.assets[0];
        await uploadAndSendFile({ uri: asset.uri, name: asset.fileName || `chat-image-${Date.now()}.jpg`, mimeType: asset.mimeType || 'image/jpeg' });
      }
    } catch {
      Alert.alert('بازکردن تصویر انجام نشد', 'دسترسی‌های دوربین یا گالری را بررسی کنید.');
    }
  };

  const openAttachment = (url: string) => {
    void Linking.openURL(url).catch(() => Alert.alert('بازکردن پیوست انجام نشد', 'مرورگر یا نمایشگر فایل در دسترس نیست.'));
  };

  const openRequest = () => {
    setInfoVisible(false);
    const tabs = navigation.getParent() as unknown as { navigate: (name: string, params: object) => void } | undefined;
    tabs?.navigate('HomeTab', { screen: 'RequestDetail', params: { requestId } });
  };

  const onScroll = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
    const far = event.nativeEvent.contentOffset.y > 320;
    setShowJump((current) => (current === far ? current : far));
  };

  const renderMessage = ({ item, index }: { item: ChatMessage; index: number }) => {
    const mine = isMine(item, user?.id);
    const filePath = mediaUrl(item.file_url ?? item.file_path ?? item.url);
    const imageAttachment = /^(image\/)/i.test(item.file_type ?? item.mime_type ?? '') || /\.(png|jpe?g|gif|webp|bmp|avif)(?:\?|$)/i.test(item.file_name ?? '');
    const created = parseDate(item.created_at);
    // The list is inverted (newest first), so the "previous" message in time is the next array item.
    const older = messages[index + 1];
    const olderDate = older ? parseDate(older.created_at) : null;
    const startsDay = Boolean(created) && (!olderDate || dayKey(created as Date) !== dayKey(olderDate));
    const startsGroup = startsDay || !older || isMine(older, user?.id) !== mine;
    const pending = String(item.id).startsWith('local-') && item.is_mine === undefined && !item.file_url;
    const read = item.is_read === true || item.is_read === 1 || item.is_read === '1';
    return (
      <View>
        {startsDay && created ? <View style={styles.dayRow}><View style={styles.dayPill}><Text style={styles.dayText}>{dayLabel(created)}</Text></View></View> : null}
        <View style={[styles.messageRow, mine ? styles.myMessageRow : styles.peerMessageRow, !startsGroup && styles.groupedRow]}>
          <View style={[styles.bubble, mine ? styles.myBubble : styles.peerBubble]}>
            {startsGroup ? <Text style={[styles.senderLabel, mine ? styles.myMessageTime : styles.senderPeerLabel]}>{mine ? 'شما' : peerName || 'طرف مقابل'}</Text> : null}
            {filePath ? (
              <View style={styles.attachmentBlock}>
                {imageAttachment ? <Pressable onPress={() => setViewerUri(filePath)}><Image source={{ uri: filePath }} resizeMode="cover" style={styles.attachmentPreview} /></Pressable> : null}
                <Pressable onPress={() => openAttachment(filePath)} style={[styles.attachment, mine ? styles.attachmentMine : styles.attachmentPeer]}>
                  <MaterialCommunityIcons name={imageAttachment ? 'image-outline' : fileIcon(item.file_name, item.file_type)} size={18} color={mine ? '#F4E9C9' : COLORS.primaryDark} />
                  <Text style={[styles.attachmentText, mine && styles.myMessageText]} numberOfLines={1}>{item.file_name || 'مشاهدهٔ پیوست'}</Text>
                </Pressable>
              </View>
            ) : null}
            {item.message ? <Text style={[styles.messageText, mine ? styles.myMessageText : styles.peerMessageText]}>{item.message}</Text> : null}
            <View style={styles.messageMeta}>
              <Text style={[styles.messageTime, mine && styles.myMessageTime]}>{timeLabel(item.created_at)}</Text>
              {mine ? <MaterialCommunityIcons name={pending ? 'clock-outline' : read ? 'check-all' : 'check'} size={13} color={read ? '#FDE68A' : '#D6D3D1'} /> : null}
            </View>
          </View>
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['top', 'bottom']}>
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : 'height'} keyboardVerticalOffset={Platform.OS === 'ios' ? 4 : 0}>
        <View style={styles.header}>
          <Pressable onPress={() => navigation.goBack()} style={styles.backButton} accessibilityLabel="بازگشت"><MaterialCommunityIcons name="arrow-right" size={22} color={COLORS.text} /></Pressable>
          {peerPhoto && !avatarFailed ? <Image source={{ uri: peerPhoto }} onError={() => setAvatarFailed(true)} style={styles.avatar} /> : <View style={styles.avatarFallback}><Text style={styles.avatarInitial}>{(peerName || '؟')[0]}</Text></View>}
          <View style={styles.headerCopy}><Text style={styles.peerName} numberOfLines={1}>{peerName}</Text><Text style={styles.requestTitle} numberOfLines={1}>{requestTitle}</Text></View>
          <Pressable onPress={() => setInfoVisible(true)} style={styles.moreButton} accessibilityLabel="اطلاعات درخواست"><MaterialCommunityIcons name="information-outline" size={21} color={COLORS.text} /></Pressable>
        </View>

        {loading && messages.length === 0 ? <View style={styles.loading}><ActivityIndicator size="large" color={COLORS.primary} /><Text style={styles.loadingText}>در حال دریافت پیام‌ها...</Text></View> : messages.length === 0 ? (
          <View style={styles.emptyState}>
            <View style={styles.emptyIcon}><MaterialCommunityIcons name="message-text-outline" size={28} color={COLORS.primaryDark} /></View>
            <Text style={styles.emptyTitle}>گفتگو را شروع کنید</Text>
            <Text style={styles.emptyHint}>می‌توانید یکی از جمله‌های پیشنهادی را انتخاب و ویرایش کنید.</Text>
            {chatActive ? (
              <View style={styles.quickList}>
                {quickReplies.map((text) => <Pressable key={text} onPress={() => setDraft(text)} style={styles.quickChip}><Text style={styles.quickText}>{text}</Text></Pressable>)}
              </View>
            ) : null}
          </View>
        ) : (
          <View style={styles.listWrap}>
            <FlatList
              ref={listRef}
              data={messages}
              inverted
              keyExtractor={(item, index) => `${item.id}-${index}`}
              renderItem={renderMessage}
              contentContainerStyle={styles.messageList}
              style={styles.list}
              showsVerticalScrollIndicator={false}
              onScroll={onScroll}
              scrollEventThrottle={64}
            />
            {showJump ? <Pressable onPress={() => listRef.current?.scrollToOffset({ offset: 0, animated: true })} style={styles.jumpButton} accessibilityLabel="رفتن به آخرین پیام"><MaterialCommunityIcons name="chevron-double-down" size={22} color={COLORS.primaryDark} /></Pressable> : null}
          </View>
        )}

        {chatActive && !chatLocked ? (
          <View style={styles.composerWrap}>
            {draft.length > 1500 ? <Text style={styles.counter}>{`${draft.length.toLocaleString('fa-IR')} / ${(2000).toLocaleString('fa-IR')}`}</Text> : null}
            <View style={styles.composer}>
              <Pressable disabled={uploading || sending} onPress={() => setAttachmentMenuVisible(true)} style={[styles.attachButton, (uploading || sending) && styles.sendDisabled]} accessibilityLabel="افزودن پیوست">{uploading ? <ActivityIndicator size="small" color={COLORS.primaryDark} /> : <MaterialCommunityIcons name="paperclip" size={20} color={COLORS.muted} />}</Pressable>
              <TextInput value={draft} onChangeText={setDraft} placeholder="پیام خود را بنویسید..." placeholderTextColor="#A8A29E" multiline maxLength={2000} textAlign="right" style={styles.input} editable={!sending && !uploading} />
              <Pressable disabled={sending || uploading || !draft.trim()} onPress={() => void send()} style={({ pressed }) => [styles.sendButton, pressed && { opacity: 0.85 }, (sending || uploading || !draft.trim()) && styles.sendDisabled]} accessibilityLabel="ارسال">{sending ? <ActivityIndicator color="#fff" size="small" /> : <MaterialCommunityIcons name="send" size={18} color="#fff" />}</Pressable>
            </View>
          </View>
        ) : (
          <View style={styles.lockedBanner}>
            <MaterialCommunityIcons name="lock-outline" size={19} color={COLORS.warning} />
            <Text style={styles.lockedText}>
              {!chatActive
                ? 'برای گفتگو وارد حساب کاربری شوید'
                : (lockReason || 'گفتگو برای این درخواست بسته شده است.')}
            </Text>
          </View>
        )}
      </KeyboardAvoidingView>

      <Modal visible={attachmentMenuVisible} transparent animationType="fade" onRequestClose={() => setAttachmentMenuVisible(false)}>
        <Pressable style={styles.modalBackdrop} onPress={() => setAttachmentMenuVisible(false)}>
          <View style={styles.sheet}>
            <Text style={styles.sheetTitle}>ارسال پیوست</Text>
            <Pressable style={styles.sheetOption} onPress={() => { setAttachmentMenuVisible(false); void chooseImage('camera'); }}><MaterialCommunityIcons name="camera-outline" size={21} color={COLORS.primaryDark} /><Text style={styles.sheetOptionText}>گرفتن عکس با دوربین</Text></Pressable>
            <Pressable style={styles.sheetOption} onPress={() => { setAttachmentMenuVisible(false); void chooseImage('library'); }}><MaterialCommunityIcons name="image-multiple-outline" size={21} color={COLORS.primaryDark} /><Text style={styles.sheetOptionText}>انتخاب تصویر از گالری</Text></Pressable>
            <Pressable style={styles.sheetOption} onPress={() => { setAttachmentMenuVisible(false); void chooseDocument(); }}><MaterialCommunityIcons name="file-upload-outline" size={21} color={COLORS.primaryDark} /><Text style={styles.sheetOptionText}>انتخاب فایل یا PDF</Text></Pressable>
            <Pressable style={styles.sheetCancel} onPress={() => setAttachmentMenuVisible(false)}><Text style={styles.sheetCancelText}>انصراف</Text></Pressable>
          </View>
        </Pressable>
      </Modal>

      <Modal visible={infoVisible} transparent animationType="fade" onRequestClose={() => setInfoVisible(false)}>
        <Pressable style={styles.modalBackdrop} onPress={() => setInfoVisible(false)}>
          <View style={styles.sheet}>
            <Text style={styles.sheetTitle}>اطلاعات گفتگو</Text>
            <View style={styles.infoCard}>
              <Text style={styles.infoLabel}>درخواست</Text>
              <Text style={styles.infoValue}>{requestTitle}</Text>
              <View style={styles.infoDivider} />
              <Text style={styles.infoLabel}>طرف گفتگو</Text>
              <Text style={styles.infoValue}>{peerName}</Text>
            </View>
            <Pressable style={styles.primaryAction} onPress={openRequest}><MaterialCommunityIcons name="file-document-outline" size={18} color="#fff" /><Text style={styles.primaryActionText}>مشاهدهٔ جزئیات درخواست</Text></Pressable>
            <Pressable style={styles.sheetCancel} onPress={() => setInfoVisible(false)}><Text style={styles.sheetCancelText}>بستن</Text></Pressable>
          </View>
        </Pressable>
      </Modal>

      <Modal visible={Boolean(viewerUri)} transparent animationType="fade" onRequestClose={() => setViewerUri(null)}>
        <View style={styles.viewer}>
          <Pressable style={styles.viewerClose} onPress={() => setViewerUri(null)} accessibilityLabel="بستن تصویر"><MaterialCommunityIcons name="close" size={24} color="#fff" /></Pressable>
          {viewerUri ? <Image source={{ uri: viewerUri }} resizeMode="contain" style={styles.viewerImage} /> : null}
          {viewerUri ? <Pressable style={styles.viewerOpen} onPress={() => openAttachment(viewerUri)}><MaterialCommunityIcons name="open-in-new" size={17} color="#fff" /><Text style={styles.viewerOpenText}>بازکردن در مرورگر</Text></Pressable> : null}
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.background },
  flex: { flex: 1 },
  header: { minHeight: 65, flexDirection: 'row-reverse', alignItems: 'center', gap: 9, paddingHorizontal: 13, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#EEEAE1' },
  backButton: { width: 36, height: 36, borderRadius: 12, backgroundColor: COLORS.background, alignItems: 'center', justifyContent: 'center' },
  avatar: { width: 39, height: 39, borderRadius: 14, backgroundColor: '#F4E9C9' },
  avatarFallback: { width: 39, height: 39, borderRadius: 14, backgroundColor: '#F4E9C9', alignItems: 'center', justifyContent: 'center' },
  avatarInitial: { fontFamily: 'VazirmatnBold', fontSize: 17, color: COLORS.primaryDark },
  headerCopy: { flex: 1, minWidth: 0 },
  peerName: { fontFamily: 'VazirmatnBold', fontSize: 12, color: COLORS.text, textAlign: 'right' },
  requestTitle: { fontFamily: 'Vazirmatn', fontSize: 9, color: COLORS.muted, textAlign: 'right', marginTop: 2 },
  moreButton: { width: 36, height: 36, borderRadius: 12, backgroundColor: COLORS.background, alignItems: 'center', justifyContent: 'center' },
  listWrap: { flex: 1 },
  list: { flex: 1, backgroundColor: '#F6F4EF' },
  messageList: { paddingVertical: 15, paddingHorizontal: 13, flexGrow: 1, justifyContent: 'flex-end', direction: 'ltr' },
  dayRow: { alignItems: 'center', marginTop: 10, marginBottom: 8 },
  dayPill: { paddingHorizontal: 12, paddingVertical: 4, borderRadius: 12, backgroundColor: 'rgba(120,113,108,0.14)' },
  dayText: { fontFamily: 'VazirmatnMedium', fontSize: 9, color: COLORS.muted },
  messageRow: { width: '100%', marginVertical: 4 },
  groupedRow: { marginTop: 0 },
  myMessageRow: { alignItems: 'flex-end', alignSelf: 'flex-end' },
  peerMessageRow: { alignItems: 'flex-start' },
  bubble: { maxWidth: '82%', paddingHorizontal: 12, paddingTop: 9, paddingBottom: 6, borderRadius: 16 },
  myBubble: { alignSelf: 'flex-end', backgroundColor: '#3B2E0A', borderBottomRightRadius: 5 },
  peerBubble: { backgroundColor: '#fff', borderColor: '#E8E5DF', borderWidth: 1, borderBottomLeftRadius: 5 },
  senderLabel: { fontFamily: 'VazirmatnBold', fontSize: 8, textAlign: 'right', writingDirection: 'rtl', marginBottom: 3 },
  senderPeerLabel: { color: COLORS.primaryDark },
  messageText: { fontFamily: 'Vazirmatn', fontSize: 11, lineHeight: 20, textAlign: 'right', writingDirection: 'rtl' },
  myMessageText: { color: '#FFFDF6' },
  peerMessageText: { color: COLORS.text },
  messageMeta: { flexDirection: 'row', justifyContent: 'flex-end', alignItems: 'center', gap: 3, marginTop: 4 },
  messageTime: { fontFamily: 'Vazirmatn', fontSize: 8, color: COLORS.muted },
  myMessageTime: { color: '#D6D3D1' },
  attachment: { flexDirection: 'row-reverse', alignItems: 'center', gap: 7, maxWidth: 210, paddingHorizontal: 9, paddingVertical: 8, borderRadius: 11, marginBottom: 4 },
  attachmentMine: { backgroundColor: 'rgba(255,255,255,0.1)' },
  attachmentPeer: { backgroundColor: '#FBF3DC' },
  attachmentBlock: { alignItems: 'flex-end', marginBottom: 3 },
  attachmentPreview: { width: 190, height: 140, borderRadius: 12, backgroundColor: '#E7E5E4', marginBottom: 6 },
  attachmentText: { flexShrink: 1, fontFamily: 'VazirmatnMedium', fontSize: 10, color: COLORS.primaryDark, writingDirection: 'rtl', textAlign: 'right' },
  jumpButton: { position: 'absolute', bottom: 14, left: 14, width: 40, height: 40, borderRadius: 20, backgroundColor: '#fff', borderWidth: 1, borderColor: '#E4C66C', alignItems: 'center', justifyContent: 'center', elevation: 4, shadowColor: '#000', shadowOpacity: 0.12, shadowRadius: 6, shadowOffset: { width: 0, height: 2 } },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 9, backgroundColor: '#F6F4EF' },
  loadingText: { fontFamily: 'Vazirmatn', fontSize: 10, color: COLORS.muted },
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 8, paddingHorizontal: 22, backgroundColor: '#F6F4EF' },
  emptyIcon: { width: 62, height: 62, borderRadius: 21, backgroundColor: '#F4E9C9', alignItems: 'center', justifyContent: 'center' },
  emptyTitle: { width: '100%', fontFamily: 'VazirmatnBold', fontSize: 13, color: COLORS.text, textAlign: 'center', writingDirection: 'rtl' },
  emptyHint: { width: '100%', fontFamily: 'Vazirmatn', fontSize: 9, color: COLORS.muted, textAlign: 'center', writingDirection: 'rtl' },
  quickList: { width: '100%', gap: 7, marginTop: 8 },
  quickChip: { paddingHorizontal: 13, paddingVertical: 10, borderRadius: 14, backgroundColor: '#fff', borderWidth: 1, borderColor: '#E4C66C' },
  quickText: { fontFamily: 'Vazirmatn', fontSize: 10, lineHeight: 18, color: COLORS.text, textAlign: 'right', writingDirection: 'rtl' },
  composerWrap: { backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: '#EAE6DC' },
  counter: { fontFamily: 'Vazirmatn', fontSize: 8, color: COLORS.muted, textAlign: 'left', paddingHorizontal: 14, paddingTop: 5 },
  composer: { flexDirection: 'row-reverse', alignItems: 'flex-end', gap: 7, paddingHorizontal: 11, paddingVertical: 9 },
  attachButton: { width: 38, height: 38, borderRadius: 13, backgroundColor: COLORS.background, alignItems: 'center', justifyContent: 'center', marginBottom: 1 },
  input: { flex: 1, maxHeight: 110, minHeight: 40, borderRadius: 14, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.background, paddingHorizontal: 12, paddingTop: 9, paddingBottom: 8, fontFamily: 'Vazirmatn', fontSize: 10, color: COLORS.text, writingDirection: 'rtl', textAlign: 'right' },
  sendButton: { width: 39, height: 39, borderRadius: 14, alignItems: 'center', justifyContent: 'center', backgroundColor: COLORS.primaryDark, marginBottom: 1 },
  sendDisabled: { opacity: 0.5 },
  lockedBanner: { minHeight: 58, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', gap: 8, paddingHorizontal: 12, backgroundColor: '#FFFBEB', borderTopWidth: 1, borderTopColor: '#FDE68A' },
  lockedText: { fontFamily: 'VazirmatnMedium', color: '#92400E', fontSize: 11, textAlign: 'center' },
  modalBackdrop: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.38)' },
  sheet: { paddingHorizontal: 18, paddingTop: 16, paddingBottom: 24, backgroundColor: '#fff', borderTopLeftRadius: 22, borderTopRightRadius: 22 },
  sheetTitle: { fontFamily: 'VazirmatnBold', fontSize: 14, color: COLORS.text, textAlign: 'right', marginBottom: 8 },
  sheetOption: { minHeight: 52, flexDirection: 'row-reverse', alignItems: 'center', gap: 12, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  sheetOptionText: { fontFamily: 'VazirmatnMedium', fontSize: 11, color: COLORS.text, textAlign: 'right' },
  sheetCancel: { minHeight: 42, alignItems: 'center', justifyContent: 'center', marginTop: 6 },
  sheetCancelText: { fontFamily: 'VazirmatnBold', fontSize: 11, color: COLORS.muted },
  infoCard: { padding: 14, borderRadius: 16, backgroundColor: COLORS.background, borderWidth: 1, borderColor: '#EAE6DC' },
  infoLabel: { fontFamily: 'Vazirmatn', fontSize: 9, color: COLORS.muted, textAlign: 'right' },
  infoValue: { fontFamily: 'VazirmatnBold', fontSize: 12, lineHeight: 21, color: COLORS.text, textAlign: 'right', marginTop: 2 },
  infoDivider: { height: 1, backgroundColor: '#EAE6DC', marginVertical: 10 },
  primaryAction: { minHeight: 48, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', gap: 7, marginTop: 12, borderRadius: 14, backgroundColor: COLORS.primaryDark },
  primaryActionText: { fontFamily: 'VazirmatnBold', fontSize: 12, color: '#fff' },
  viewer: { flex: 1, backgroundColor: 'rgba(0,0,0,0.94)', alignItems: 'center', justifyContent: 'center' },
  viewerClose: { position: 'absolute', top: 44, right: 18, width: 42, height: 42, borderRadius: 21, backgroundColor: 'rgba(255,255,255,0.16)', alignItems: 'center', justifyContent: 'center', zIndex: 2 },
  viewerImage: { width: '100%', height: '78%' },
  viewerOpen: { position: 'absolute', bottom: 36, flexDirection: 'row-reverse', alignItems: 'center', gap: 6, paddingHorizontal: 16, paddingVertical: 10, borderRadius: 14, backgroundColor: 'rgba(255,255,255,0.16)' },
  viewerOpenText: { fontFamily: 'VazirmatnMedium', fontSize: 10, color: '#fff' },
});
