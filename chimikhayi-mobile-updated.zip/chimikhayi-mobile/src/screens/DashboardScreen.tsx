import React, { useCallback, useMemo, useState } from 'react';
import { Alert, Image, Pressable, RefreshControl, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ApiError, api, type MyOfferItem, type MyOffersResult, type MyRequestItem, type MyRequestsResult, type OpenRequest, type OpenRequestsResult } from '../api/api';
import { mediaUrl } from '../api/media';
import { TrustStars } from '../components/TrustCard';
import type { DashboardStackParamList } from '../navigation/DashboardStackNavigator';
import { useAuthStore, type User } from '../store/authStore';
import { COLORS } from '../theme/colors';
import { extractArray, findNumber } from '../utils/collections';
import { subscriptionInfo } from '../utils/subscription';
import { computeTrust, emptyProgress, isServerVerified, loadKycProgress, type KycProgress } from '../utils/trust';

type Props = NativeStackScreenProps<DashboardStackParamList, 'Dashboard'>;
type IconName = keyof typeof MaterialCommunityIcons.glyphMap;

const FREE_OFFER_QUOTA = 30;
const LIST_KEYS = ['requests', 'offers', 'items', 'results', 'rows', 'data'];

function roleLabel(user: User): string {
  if (user.role === 'buyer') return 'خریدار';
  if (user.role === 'broker' || user.is_broker === 1 || user.is_broker === true) return 'ترخیص‌کار';
  return 'تأمین‌کننده';
}
function isOpen(item: { status?: string }): boolean {
  return (item.status || 'open').toLowerCase() === 'open';
}
const fa = (value: number) => value.toLocaleString('fa-IR');

function Stat({ value, label, tint }: { value: string; label: string; tint?: string }) {
  return (
    <View style={styles.stat}>
      <Text style={[styles.statValue, tint ? { color: tint } : null]} numberOfLines={1}>{value}</Text>
      <Text style={styles.statLabel} numberOfLines={2}>{label}</Text>
    </View>
  );
}

function MenuRow({ icon, title, hint, badge, onPress, danger, last }: { icon: IconName; title: string; hint?: string; badge?: string; onPress: () => void; danger?: boolean; last?: boolean }) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.menuRow, !last && styles.menuRowDivider, pressed && { backgroundColor: '#FAF7EE' }]} accessibilityRole="button">
      <View style={[styles.menuIcon, danger && styles.menuIconDanger]}><MaterialCommunityIcons name={icon} size={20} color={danger ? COLORS.danger : COLORS.primaryDark} /></View>
      <View style={styles.menuCopy}><Text style={styles.menuTitle}>{title}</Text>{hint ? <Text style={styles.menuHint} numberOfLines={2}>{hint}</Text> : null}</View>
      {badge ? <View style={styles.menuBadge}><Text style={styles.menuBadgeText}>{badge}</Text></View> : null}
      <MaterialCommunityIcons name="chevron-left" size={20} color={COLORS.muted} />
    </Pressable>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <View style={styles.section}>
      <Text style={styles.sectionTitle}>{title}</Text>
      <View style={styles.sectionCard}>{children}</View>
    </View>
  );
}

export function DashboardScreen({ navigation }: Props) {
  const user = useAuthStore((s) => s.user);
  const logout = useAuthStore((s) => s.logout);
  const updateUser = useAuthStore((s) => s.updateUser);
  const [requests, setRequests] = useState<OpenRequest[]>([]);
  const [offers, setOffers] = useState<MyOfferItem[]>([]);
  const [offersTotal, setOffersTotal] = useState<number | undefined>(undefined);
  const [refreshing, setRefreshing] = useState(false);
  const [avatarFailed, setAvatarFailed] = useState(false);
  const [progress, setProgress] = useState<KycProgress>(emptyProgress());

  // loadData must not depend on the `user` object itself: updateUser() below replaces it,
  // which would recreate loadData and re-trigger useFocusEffect in a fetch loop.
  const userId = user?.id;
  const loadData = useCallback(async (refresh = false) => {
    const storedUser = useAuthStore.getState().user;
    if (!storedUser) return;
    if (refresh) setRefreshing(true);
    try {
      const session = await api.me();
      const currentUser = session.user ?? storedUser;
      updateUser(currentUser);
      if (currentUser.role === 'buyer') {
        const result: MyRequestsResult = await api.getMyRequests();
        setRequests(extractArray<MyRequestItem>(result, LIST_KEYS));
      } else {
        const [myOffers, openRequests] = await Promise.all([api.getMyOffers(), api.getOpenRequests()]);
        const offerList: MyOffersResult = myOffers;
        setOffers(extractArray<MyOfferItem>(offerList, LIST_KEYS));
        setOffersTotal(findNumber(offerList, 'offers_count'));
        const open: OpenRequestsResult = openRequests;
        setRequests(extractArray<OpenRequest>(open, LIST_KEYS));
      }
    } catch (cause) {
      if (cause instanceof ApiError && cause.code === 'auth') logout();
      // Other errors keep the last known numbers; pull to refresh retries.
    } finally {
      setRefreshing(false);
    }
  }, [logout, updateUser, userId]);

  useFocusEffect(useCallback(() => {
    void loadData();
    if (userId !== undefined) void loadKycProgress(userId).then(setProgress);
  }, [loadData, userId]));

  const trust = useMemo(() => computeTrust(user, progress), [user, progress]);
  const subscription = useMemo(() => (user ? subscriptionInfo(user) : null), [user]);

  if (!user || !subscription) return <SafeAreaView style={styles.safeArea} />;
  const isBuyer = user.role === 'buyer';
  const isVerified = isServerVerified(user);
  const avatar = mediaUrl(user.avatar_url ?? user.avatar);
  const sentCount = offersTotal ?? (user.offers_count === undefined ? offers.length : Number(user.offers_count));
  const sent = Number.isFinite(sentCount) ? sentCount : offers.length;
  const remainingQuota = Math.max(0, FREE_OFFER_QUOTA - sent);
  const quotaPercent = Math.min(100, Math.round(((FREE_OFFER_QUOTA - remainingQuota) / FREE_OFFER_QUOTA) * 100));
  const openCount = requests.filter(isOpen).length;
  const receivedOffers = requests.reduce((sum, item) => sum + (Number((item as MyRequestItem).offers_count ?? 0) || 0), 0);

  const goTab = (name: 'HomeTab' | 'Messages' | 'Pricing') => {
    const tabs = navigation.getParent() as unknown as { navigate: (target: string) => void } | undefined;
    tabs?.navigate(name);
  };
  const confirmLogout = () => Alert.alert(
    'خروج از حساب کاربری',
    'با خروج از حساب، باید دوباره وارد شوید. مطمئن هستید؟',
    [
      { text: 'انصراف', style: 'cancel' },
      { text: 'بله، خارج شو', style: 'destructive', onPress: () => Alert.alert('تأیید نهایی', 'برای خروج از حساب، یک بار دیگر تأیید کنید.', [{ text: 'ماندن در حساب', style: 'cancel' }, { text: 'خروج', style: 'destructive', onPress: logout }]) },
    ],
  );

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <ScrollView
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => void loadData(true)} tintColor={COLORS.primary} colors={[COLORS.primary]} />}
      >
        <View style={styles.topBar}>
          <Text style={styles.topTitle}>پروفایل من</Text>
          <Pressable onPress={() => navigation.navigate('Settings')} style={styles.topButton} accessibilityLabel="تنظیمات و اعلان‌ها"><MaterialCommunityIcons name="cog-outline" size={21} color={COLORS.text} /></Pressable>
        </View>

        {/* Profile header */}
        <View style={styles.profile}>
          <View style={styles.avatarRing}>
            {avatar && !avatarFailed ? <Image source={{ uri: avatar }} onError={() => setAvatarFailed(true)} style={styles.avatar} /> : <View style={styles.avatarFallback}><Text style={styles.avatarInitial}>{(user.name || 'ک')[0]}</Text></View>}
            {isVerified ? <View style={styles.verifiedMark}><MaterialCommunityIcons name="check-decagram" size={22} color="#047857" /></View> : null}
          </View>
          <Text style={styles.name} numberOfLines={1}>{user.name}</Text>
          <Text style={styles.mobile}>{user.mobile}</Text>
          <View style={styles.levelPill}>
            <MaterialCommunityIcons name="medal-outline" size={15} color={COLORS.primaryDark} />
            <Text style={styles.levelText}>{`سطح کاربری: ${trust.levelLabel}`}</Text>
          </View>
          <View style={styles.starsBox}>
            <TrustStars stars={trust.stars} size={21} mutedColor="#D6CBA5" />
            <Text style={styles.starsNumber}>{`${fa(trust.stars)} از ${fa(5)} · امتیاز ${fa(trust.score)}`}</Text>
          </View>
          <View style={styles.rolePill}><Text style={styles.roleText}>{roleLabel(user)}</Text></View>
        </View>

        {/* Stats, Instagram style */}
        <View style={styles.statsCard}>
          <View style={styles.statsRow}>
            {isBuyer ? (
              <>
                <Stat value={fa(requests.length)} label="درخواست‌های من" />
                <View style={styles.statDivider} />
                <Stat value={fa(openCount)} label="درخواست باز" tint="#047857" />
                <View style={styles.statDivider} />
                <Stat value={fa(receivedOffers)} label="پیشنهاد دریافتی" />
                <View style={styles.statDivider} />
                <Stat value={subscription.label} label="هزینهٔ ثبت درخواست" tint="#047857" />
              </>
            ) : (
              <>
                <Stat value={fa(remainingQuota)} label="سهمیهٔ رایگان باقی‌مانده" tint={remainingQuota === 0 ? COLORS.danger : COLORS.primaryDark} />
                <View style={styles.statDivider} />
                <Stat value={subscription.label} label="وضعیت اشتراک" tint={subscription.active ? '#047857' : COLORS.danger} />
                <View style={styles.statDivider} />
                <Stat value={fa(sent)} label="پیشنهاد ارسال‌شده" />
                <View style={styles.statDivider} />
                <Stat value={fa(openCount)} label="درخواست باز" tint="#1D4ED8" />
              </>
            )}
          </View>
          {!isBuyer ? (
            <View style={styles.quota}>
              <View style={styles.quotaTrack}><View style={[styles.quotaFill, { width: `${quotaPercent}%` }, remainingQuota === 0 && { backgroundColor: COLORS.danger }]} /></View>
              <Text style={styles.quotaText}>
                {remainingQuota === 0 ? 'سهمیهٔ رایگان شما تمام شده است.' : `${fa(sent)} از ${fa(FREE_OFFER_QUOTA)} پیشنهاد رایگان استفاده شده.`}
                {subscription.detail ? `  ${subscription.detail}` : ''}
              </Text>
              {!subscription.active ? <Pressable onPress={() => goTab('Pricing')}><Text style={styles.quotaLink}>مشاهدهٔ تعرفه‌ها و فعال‌سازی اشتراک</Text></Pressable> : null}
            </View>
          ) : null}
        </View>

        <Section title="حساب کاربری">
          <MenuRow icon="account-edit-outline" title="ویرایش پروفایل" hint="نام و تصویر پروفایل" onPress={() => navigation.navigate('ProfileEdit')} />
          <MenuRow icon="shield-star-outline" title="احراز هویت و ستارهٔ اعتماد" hint={trust.nextHint ?? 'حساب شما در بالاترین سطح اعتماد است'} badge={`${fa(trust.stars)} ★`} onPress={() => navigation.navigate('Kyc')} last />
        </Section>

        <Section title={isBuyer ? 'درخواست‌ها' : 'پیشنهادها'}>
          {isBuyer ? (
            <>
              <MenuRow icon="clipboard-text-outline" title="درخواست‌های من" hint="همهٔ درخواست‌های ثبت‌شده و پیشنهادهای دریافتی" badge={fa(requests.length)} onPress={() => navigation.navigate('SentOffers')} />
              <MenuRow icon={isVerified ? 'plus-circle-outline' : 'shield-check-outline'} title={isVerified ? 'ثبت درخواست جدید' : 'تکمیل احراز هویت برای ثبت درخواست'} onPress={() => navigation.navigate(isVerified ? 'PostRequest' : 'Kyc')} last />
            </>
          ) : (
            <>
              <MenuRow icon="send-check-outline" title="پیشنهادهای ارسال‌شده" hint="همهٔ پیشنهادها با وضعیت و جزئیات هر کدام" badge={fa(offers.length)} onPress={() => navigation.navigate('SentOffers')} />
              <MenuRow icon="storefront-outline" title="فرصت‌های باز" hint="درخواست‌های تازهٔ خریداران" badge={fa(openCount)} onPress={() => goTab('HomeTab')} last />
            </>
          )}
        </Section>

        <Section title="بیشتر">
          <MenuRow icon="message-text-outline" title="پیام‌ها" onPress={() => goTab('Messages')} />
          <MenuRow icon="bell-ring-outline" title="تنظیمات و اعلان‌ها" onPress={() => navigation.navigate('Settings')} last />
        </Section>

        <Pressable onPress={confirmLogout} style={({ pressed }) => [styles.logout, pressed && { opacity: 0.85 }]} accessibilityRole="button">
          <MaterialCommunityIcons name="logout" size={20} color={COLORS.danger} />
          <Text style={styles.logoutText}>خروج از حساب کاربری</Text>
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.background },
  content: { padding: 17, paddingBottom: 32 },
  topBar: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 },
  topTitle: { fontFamily: 'VazirmatnBold', fontSize: 17, color: COLORS.text },
  topButton: { width: 40, height: 40, borderRadius: 13, backgroundColor: '#fff', borderWidth: 1, borderColor: COLORS.border, alignItems: 'center', justifyContent: 'center' },
  profile: { alignItems: 'center', paddingTop: 8, paddingBottom: 14 },
  avatarRing: { width: 108, height: 108, borderRadius: 54, borderWidth: 3, borderColor: COLORS.primary, padding: 4, alignItems: 'center', justifyContent: 'center', backgroundColor: '#fff' },
  avatar: { width: 94, height: 94, borderRadius: 47, backgroundColor: '#F4E9C9' },
  avatarFallback: { width: 94, height: 94, borderRadius: 47, backgroundColor: '#F4E9C9', alignItems: 'center', justifyContent: 'center' },
  avatarInitial: { fontFamily: 'VazirmatnBold', fontSize: 38, color: COLORS.primaryDark },
  verifiedMark: { position: 'absolute', bottom: -2, right: -2, width: 28, height: 28, borderRadius: 14, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center' },
  name: { fontFamily: 'VazirmatnBold', fontSize: 17, color: COLORS.text, marginTop: 11, maxWidth: '90%' },
  mobile: { fontFamily: 'Vazirmatn', fontSize: 11, color: COLORS.muted, marginTop: 1 },
  levelPill: { flexDirection: 'row-reverse', alignItems: 'center', gap: 5, marginTop: 11, paddingHorizontal: 13, paddingVertical: 6, borderRadius: 14, backgroundColor: '#F4E9C9' },
  levelText: { fontFamily: 'VazirmatnBold', fontSize: 11, color: COLORS.primaryDark },
  starsBox: { alignItems: 'center', gap: 4, marginTop: 9 },
  starsNumber: { fontFamily: 'VazirmatnMedium', fontSize: 10, color: COLORS.muted },
  rolePill: { marginTop: 9, paddingHorizontal: 11, paddingVertical: 3, borderRadius: 10, backgroundColor: '#211B10' },
  roleText: { fontFamily: 'VazirmatnMedium', fontSize: 9, color: '#E4C66C' },
  statsCard: { padding: 14, borderRadius: 20, backgroundColor: '#fff', borderWidth: 1, borderColor: '#EAE6DC', marginBottom: 16 },
  statsRow: { flexDirection: 'row-reverse', alignItems: 'stretch' },
  stat: { flex: 1, alignItems: 'center', justifyContent: 'flex-start', paddingHorizontal: 2, gap: 3 },
  statValue: { fontFamily: 'VazirmatnBold', fontSize: 19, color: COLORS.text },
  statLabel: { fontFamily: 'Vazirmatn', fontSize: 8, lineHeight: 13, color: COLORS.muted, textAlign: 'center' },
  statDivider: { width: 1, backgroundColor: '#EEEAE1', marginVertical: 4 },
  quota: { marginTop: 14, paddingTop: 12, borderTopWidth: 1, borderTopColor: '#F5F5F4' },
  quotaTrack: { height: 7, borderRadius: 4, backgroundColor: '#F4E9C9', overflow: 'hidden', flexDirection: 'row-reverse' },
  quotaFill: { height: 7, borderRadius: 4, backgroundColor: COLORS.primary },
  quotaText: { fontFamily: 'Vazirmatn', fontSize: 9, lineHeight: 16, color: COLORS.muted, textAlign: 'right', marginTop: 8 },
  quotaLink: { fontFamily: 'VazirmatnBold', fontSize: 10, color: COLORS.primaryDark, textAlign: 'right', marginTop: 6 },
  section: { marginBottom: 16 },
  sectionTitle: { fontFamily: 'VazirmatnBold', fontSize: 12, color: COLORS.text, textAlign: 'right', marginBottom: 8, marginRight: 4 },
  sectionCard: { borderRadius: 18, backgroundColor: '#fff', borderWidth: 1, borderColor: '#EAE6DC', overflow: 'hidden' },
  menuRow: { minHeight: 62, flexDirection: 'row-reverse', alignItems: 'center', gap: 11, paddingHorizontal: 13, paddingVertical: 10 },
  menuRowDivider: { borderBottomWidth: 1, borderBottomColor: '#F1EEE6' },
  menuIcon: { width: 38, height: 38, borderRadius: 13, backgroundColor: '#F4E9C9', alignItems: 'center', justifyContent: 'center' },
  menuIconDanger: { backgroundColor: '#FEE2E2' },
  menuCopy: { flex: 1 },
  menuTitle: { fontFamily: 'VazirmatnBold', fontSize: 11, color: COLORS.text, textAlign: 'right' },
  menuHint: { fontFamily: 'Vazirmatn', fontSize: 9, lineHeight: 15, color: COLORS.muted, textAlign: 'right', marginTop: 2 },
  menuBadge: { minWidth: 28, height: 24, paddingHorizontal: 8, borderRadius: 12, backgroundColor: '#F4E9C9', alignItems: 'center', justifyContent: 'center' },
  menuBadgeText: { fontFamily: 'VazirmatnBold', fontSize: 10, color: COLORS.primaryDark },
  logout: { minHeight: 52, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', gap: 8, borderRadius: 16, backgroundColor: '#FEF2F2', borderWidth: 1, borderColor: '#FECACA', marginTop: 2 },
  logoutText: { fontFamily: 'VazirmatnBold', fontSize: 13, color: COLORS.danger },
});
