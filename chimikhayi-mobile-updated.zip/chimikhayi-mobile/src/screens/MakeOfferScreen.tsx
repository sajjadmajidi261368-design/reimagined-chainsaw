import React, { useState } from 'react';
import { ActivityIndicator, Alert, KeyboardAvoidingView, Linking, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ApiError, api, type RequestDetailResult, type RequestDetails } from '../api/api';
import type { HomeStackParamList } from '../navigation/HomeStackNavigator';
import { COLORS } from '../theme/colors';
import { useAuthStore } from '../store/authStore';
import { registerDraftThread } from '../utils/chatLocal';

type Props = NativeStackScreenProps<HomeStackParamList, 'MakeOffer'>;
const DELIVERY_OPTIONS = ['۳ روز کاری', '۱۵ روز کاری', 'توافقی'];
const digitsOnly = (value: string) => value.replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d))).replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));
const permissionGranted = (value?: boolean | number | string) => value === true || value === 1 || ['1', 'true', 'yes', 'on'].includes(String(value ?? '').toLowerCase());
function normalizeRequest(result: RequestDetailResult): RequestDetails {
  let current: unknown = result;
  const visited = new Set<object>();
  for (let depth = 0; depth < 6; depth += 1) {
    if (!current || typeof current !== 'object' || visited.has(current)) break;
    visited.add(current);
    const record = current as Record<string, unknown>;
    const nested = record.request ?? record.data ?? record.result ?? record.payload;
    if (!nested || typeof nested !== 'object') return current as RequestDetails;
    current = nested;
  }
  return current as RequestDetails;
}
function buyerIdFrom(request: RequestDetails): string | number | undefined {
  const record = request as RequestDetails & Record<string, unknown>;
  const buyer = record.buyer as Record<string, unknown> | undefined;
  const owner = record.user as Record<string, unknown> | undefined;
  const ownerRecord = record.owner as Record<string, unknown> | undefined;
  const value = request.buyer_id ?? buyer?.id ?? buyer?.user_id ?? request.user_id ?? owner?.id ?? owner?.user_id ?? ownerRecord?.id ?? record.buyer_user_id ?? record.buyerId ?? record.owner_id ?? record.created_by_id ?? record.created_by;
  return typeof value === 'string' || typeof value === 'number' ? value : undefined;
}
function phoneFrom(request: RequestDetails): string | undefined {
  const record = request as RequestDetails & Record<string, unknown>;
  const buyer = record.buyer as Record<string, unknown> | undefined;
  const owner = record.user as Record<string, unknown> | undefined;
  const value = request.buyer_mobile ?? buyer?.mobile ?? buyer?.phone ?? owner?.mobile ?? owner?.phone ?? record.buyer_phone ?? record.mobile ?? record.phone;
  return typeof value === 'string' && value.trim() ? value : undefined;
}

export function MakeOfferScreen({ route, navigation }: Props) {
  const [price, setPrice] = useState('');
  const [delivery, setDelivery] = useState(DELIVERY_OPTIONS[0]);
  const [description, setDescription] = useState('');
  const [busy, setBusy] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [chatAllowed, setChatAllowed] = useState(Boolean(route.params.allowChat));
  const [phoneAllowed, setPhoneAllowed] = useState(Boolean(route.params.allowPhone));
  const [buyerPhone, setBuyerPhone] = useState(route.params.buyerMobile ?? '');
  const [buyerId, setBuyerId] = useState(route.params.buyerId);
  const user = useAuthStore((state) => state.user);

  const submit = async () => {
    const numericPrice = digitsOnly(price).replace(/[٬,\s]/g, '');
    if (!numericPrice || !/^\d+(\.\d{1,2})?$/.test(numericPrice) || Number(numericPrice) <= 0) {
      Alert.alert('مبلغ معتبر نیست', 'قیمت پیشنهادی را به‌صورت عددی و بزرگ‌تر از صفر وارد کنید.');
      return;
    }
    if (!description.trim()) {
      Alert.alert('توضیحات لازم است', 'توضیح کوتاهی دربارهٔ پیشنهاد خود بنویسید.');
      return;
    }
    setBusy(true);
    try {
      const result = await api.makeOffer({ request_id: route.params.requestId, price: numericPrice, delivery, description: description.trim() });
      setChatAllowed(true);
      if (result.offer?.allow_phone !== undefined) setPhoneAllowed(permissionGranted(result.offer.allow_phone));
      if (result.offer?.buyer_mobile) setBuyerPhone(result.offer.buyer_mobile);
      setSubmitted(true);
      try {
        const latestRequest = normalizeRequest(await api.getRequest(route.params.requestId));
        const latestBuyerId = buyerIdFrom(latestRequest);
        if (latestBuyerId !== undefined && latestBuyerId !== null) setBuyerId(latestBuyerId);
        const latestPhone = phoneFrom(latestRequest);
        if (latestPhone) setBuyerPhone(latestPhone);
        if (latestRequest.allow_phone !== undefined) setPhoneAllowed(permissionGranted(latestRequest.allow_phone));
      } catch {
        // Keep the phone number/permission passed from the request detail if refresh is unavailable.
      }
      Alert.alert('پیشنهاد ارسال شد', 'پیشنهاد شما با موفقیت ثبت شد. دسترسی‌های تماس فقط مطابق اطلاعات مجاز سرور فعال می‌شوند.');
    } catch (error) {
      if (error instanceof ApiError && error.code === 'quota_exceeded') {
        Alert.alert(
          'پایان سهمیهٔ رایگان',
          'سهمیه پیشنهادهای رایگان شما تمام شده است',
          [{ text: 'رفتن به تعرفه‌ها', onPress: () => navigation.getParent()?.navigate('Pricing' as never) }],
        );
      } else {
        Alert.alert('ارسال پیشنهاد ناموفق بود', error instanceof ApiError ? error.message : 'لطفاً دوباره تلاش کنید.');
      }
    } finally {
      setBusy(false);
    }
  };

  const phone = digitsOnly(buyerPhone).replace(/[^\d+]/g, '');
  const canCall = Boolean(user && submitted && phoneAllowed && /^\+?\d{10,15}$/.test(phone));
  const openChat = async () => {
    if (!user) return Alert.alert('ورود لازم است', 'برای شروع گفتگو ابتدا وارد حساب خود شوید.');
    if (!submitted) return;
    if (!chatAllowed) return Alert.alert('چت در دسترس نیست', 'ابتدا پیشنهاد را با موفقیت ثبت کنید.');
    let recipientId = buyerId;
    if (recipientId === undefined || recipientId === null || String(recipientId).length === 0) {
      try {
        const latestRequest = normalizeRequest(await api.getRequest(route.params.requestId));
        recipientId = buyerIdFrom(latestRequest);
        if (recipientId !== undefined && recipientId !== null) setBuyerId(recipientId);
      } catch { /* The screen still provides a clear recovery message below. */ }
    }
    if (recipientId === undefined || recipientId === null || String(recipientId).length === 0) {
      return Alert.alert('گفتگو آماده نیست', 'شناسهٔ خریدار از سرور دریافت نشد. لطفاً جزئیات درخواست را دوباره باز کنید.');
    }
    const tabs = navigation.getParent() as unknown as { navigate: (name: string, params: object) => void } | undefined;
    if (!tabs) return Alert.alert('بازکردن چت انجام نشد', 'صفحهٔ پیام‌ها در دسترس نیست. اپ را دوباره باز کنید و تلاش کنید.');
    // Keep the conversation in Messages as a draft even if the user leaves without writing anything.
    await registerDraftThread(user.id, {
      requestId: route.params.requestId,
      peerId: recipientId,
      peerName: route.params.buyerName || 'خریدار',
      requestTitle: route.params.requestTitle || 'گفتگو دربارهٔ درخواست',
      peerAvatar: route.params.buyerAvatar,
    });
    tabs.navigate('Messages', { screen: 'ChatRoom', params: {
      requestId: route.params.requestId,
      peerId: recipientId,
      peerName: route.params.buyerName || 'خریدار',
      peerAvatar: route.params.buyerAvatar,
      requestTitle: route.params.requestTitle || 'گفتگو دربارهٔ درخواست',
      allowChat: true,
    } });
  };
  const openPhone = () => {
    if (!user) return Alert.alert('ورود لازم است', 'برای تماس ابتدا وارد حساب خود شوید.');
    if (!submitted) return;
    const normalizedPhone = digitsOnly(buyerPhone).replace(/[^\d+]/g, '');
    if (!phoneAllowed || !/^\+?\d{10,15}$/.test(normalizedPhone)) {
      return Alert.alert('شماره در دسترس نیست', 'شمارهٔ کامل فقط پس از آزادسازی از طرف خریدار قابل تماس است.');
    }
    void Linking.openURL(`tel:${normalizedPhone}`).catch(() => Alert.alert('تماس برقرار نشد', 'برنامهٔ تماس در این دستگاه در دسترس نیست.'));
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} style={styles.headerButton}><MaterialCommunityIcons name="arrow-right" size={22} color={COLORS.text} /></Pressable>
        <Text style={styles.headerTitle}>ارسال پیشنهاد</Text>
        <View style={styles.headerButton} />
      </View>
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          <View style={styles.introCard}><View style={styles.introIcon}><MaterialCommunityIcons name="send-outline" size={22} color={COLORS.primaryDark} /></View><View style={styles.introCopy}><Text style={styles.title}>{submitted ? 'پیشنهاد ثبت شد' : 'پیشنهادتان را ثبت کنید'}</Text><Text style={styles.subtitle}>قیمت و زمان تحویل را مشخص کنید.</Text></View></View>
          <View style={styles.formCard}>
            <Text style={styles.label}>قیمت پیشنهادی (تومان)</Text>
            <View style={styles.priceInputWrap}><MaterialCommunityIcons name="currency-usd" size={19} color={COLORS.primaryDark} /><TextInput value={price} onChangeText={(value) => setPrice(value.replace(/[^0-9۰-۹٠-٩٬,.]/g, ''))} placeholder="مثلاً ۱۲۵۰۰۰۰۰" placeholderTextColor="#A8A29E" keyboardType="decimal-pad" textAlign="right" style={styles.priceInput} /></View>
            <Text style={styles.label}>زمان تحویل</Text>
            <View style={styles.deliveryOptions}>{DELIVERY_OPTIONS.map((option) => <Pressable key={option} onPress={() => setDelivery(option)} style={[styles.deliveryOption, delivery === option && styles.deliverySelected]}><Text style={[styles.deliveryText, delivery === option && styles.deliveryTextSelected]}>{option}</Text></Pressable>)}</View>
            <Text style={styles.label}>توضیحات پیشنهاد</Text>
            <TextInput value={description} onChangeText={setDescription} placeholder="شرایط، مشخصات یا نکات تکمیلی پیشنهاد خود را بنویسید..." placeholderTextColor="#A8A29E" multiline textAlign="right" textAlignVertical="top" style={styles.descriptionInput} maxLength={700} />
            <Text style={styles.characterCount}>{description.length.toLocaleString('fa-IR')} / ۷۰۰</Text>
          </View>
          <View style={styles.tipRow}><MaterialCommunityIcons name="information-outline" size={17} color={COLORS.primaryDark} /><Text style={styles.tip}>پیشنهاد شما برای خریدار درخواست ارسال می‌شود.</Text></View>
        </ScrollView>
        <View style={styles.footer}>
          <View style={styles.contactActions}>
            <Pressable onPress={openChat} style={({ pressed }) => [styles.contactButton, submitted && user ? styles.chatButtonActive : styles.contactButtonDisabled, pressed && submitted && user && { opacity: 0.86 }]} accessibilityRole="button"><MaterialCommunityIcons name="message-text-outline" size={17} color={submitted && user ? '#fff' : COLORS.muted} /><Text style={[styles.contactText, submitted && user && styles.contactTextActive]}>{submitted ? 'شروع چت' : 'چت پس از ارسال پیشنهاد'}</Text></Pressable>
            <Pressable onPress={openPhone} style={({ pressed }) => [styles.contactButton, canCall ? styles.callButtonActive : submitted && user ? styles.callButtonPending : styles.contactButtonDisabled, pressed && submitted && { opacity: 0.86 }]} accessibilityRole="button"><MaterialCommunityIcons name="phone-outline" size={17} color={canCall || (submitted && user) ? '#fff' : COLORS.muted} /><Text style={[styles.contactText, (canCall || (submitted && user)) && styles.contactTextActive]}>{submitted && !canCall ? 'تماس (با اجازهٔ خریدار)' : 'تماس'}</Text></Pressable>
          </View>
          <Pressable disabled={busy || submitted} onPress={() => void submit()} style={({ pressed }) => [styles.submitButton, pressed && !busy && !submitted && { opacity: 0.86 }, (busy || submitted) && styles.disabled]}>{busy ? <ActivityIndicator color="#fff" /> : submitted ? <Text style={styles.submitText}>پیشنهاد ارسال شده</Text> : <><MaterialCommunityIcons name="send" size={18} color="#fff" /><Text style={styles.submitText}>ارسال پیشنهاد</Text></>}</Pressable>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.background },
  flex: { flex: 1 },
  header: { minHeight: 56, paddingHorizontal: 17, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: '#EEEAE1' },
  headerButton: { width: 38, height: 38, borderRadius: 13, backgroundColor: '#fff', borderWidth: 1, borderColor: COLORS.border, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { fontFamily: 'VazirmatnBold', fontSize: 14, color: COLORS.text },
  content: { padding: 18, paddingBottom: 24 },
  introCard: { flexDirection: 'row-reverse', alignItems: 'center', gap: 12, padding: 16, backgroundColor: '#211B10', borderRadius: 19, marginBottom: 15 },
  introIcon: { width: 43, height: 43, borderRadius: 15, backgroundColor: '#F4E9C9', alignItems: 'center', justifyContent: 'center' },
  introCopy: { flex: 1 },
  title: { fontFamily: 'VazirmatnBold', fontSize: 15, color: '#FFFDF6', textAlign: 'right' },
  subtitle: { fontFamily: 'Vazirmatn', fontSize: 10, color: '#D6D3D1', textAlign: 'right', marginTop: 3, lineHeight: 17 },
  formCard: { padding: 17, borderRadius: 20, backgroundColor: '#fff', borderWidth: 1, borderColor: '#EAE6DC' },
  label: { fontFamily: 'VazirmatnMedium', fontSize: 12, color: COLORS.text, textAlign: 'right', marginBottom: 7, marginTop: 9 },
  priceInputWrap: { flexDirection: 'row-reverse', alignItems: 'center', gap: 8, backgroundColor: COLORS.background, borderWidth: 1, borderColor: COLORS.border, borderRadius: 13, paddingHorizontal: 12 },
  priceInput: { flex: 1, fontFamily: 'VazirmatnBold', fontSize: 15, color: COLORS.text, paddingVertical: 13 },
  deliveryOptions: { flexDirection: 'row-reverse', gap: 8, marginBottom: 7 },
  deliveryOption: { flex: 1, alignItems: 'center', justifyContent: 'center', borderRadius: 12, borderWidth: 1, borderColor: COLORS.border, minHeight: 43, backgroundColor: '#fff' },
  deliverySelected: { borderColor: COLORS.primary, backgroundColor: '#FFFBEB' },
  deliveryText: { fontFamily: 'Vazirmatn', fontSize: 10, color: COLORS.muted },
  deliveryTextSelected: { fontFamily: 'VazirmatnBold', color: COLORS.primaryDark },
  descriptionInput: { minHeight: 124, borderRadius: 13, borderWidth: 1, borderColor: COLORS.border, backgroundColor: COLORS.background, padding: 12, fontFamily: 'Vazirmatn', fontSize: 11, lineHeight: 20, color: COLORS.text },
  characterCount: { fontFamily: 'Vazirmatn', fontSize: 9, color: COLORS.muted, textAlign: 'left', marginTop: 5 },
  tipRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 6, marginTop: 13, paddingHorizontal: 3 },
  tip: { flex: 1, fontFamily: 'Vazirmatn', fontSize: 10, color: COLORS.muted, textAlign: 'right' },
  footer: { paddingHorizontal: 18, paddingTop: 10, paddingBottom: 12, borderTopWidth: 1, borderTopColor: COLORS.border, backgroundColor: 'rgba(250,250,249,0.98)' },
  contactActions: { flexDirection: 'row-reverse', gap: 8, marginBottom: 8 },
  contactButton: { flex: 1, minHeight: 42, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', gap: 6, borderRadius: 12, borderWidth: 1 },
  contactButtonDisabled: { backgroundColor: '#F5F5F4', borderColor: '#E7E5E4' },
  chatButtonActive: { backgroundColor: '#0F766E', borderColor: '#0F766E' },
  callButtonActive: { backgroundColor: '#15803D', borderColor: '#15803D' },
  callButtonPending: { backgroundColor: '#A16207', borderColor: '#A16207' },
  contactText: { fontFamily: 'VazirmatnMedium', fontSize: 10, color: COLORS.muted },
  contactTextActive: { color: '#fff' },
  submitButton: { minHeight: 51, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: COLORS.primaryDark, borderRadius: 15 },
  submitText: { fontFamily: 'VazirmatnBold', color: '#fff', fontSize: 14 },
  disabled: { opacity: 0.65 },
});
