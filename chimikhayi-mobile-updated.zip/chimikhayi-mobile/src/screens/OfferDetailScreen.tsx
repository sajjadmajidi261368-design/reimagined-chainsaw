import React, { useState } from 'react';
import { ActivityIndicator, Alert, Pressable, ScrollView, StyleSheet, Switch, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ApiError, api, type RequestOffer } from '../api/api';
import type { HomeStackParamList } from '../navigation/HomeStackNavigator';
import { useAuthStore } from '../store/authStore';
import { COLORS } from '../theme/colors';
import { registerDraftThread } from '../utils/chatLocal';

type Props = NativeStackScreenProps<HomeStackParamList, 'OfferDetail'>;

function enabled(value?: boolean | number | string): boolean {
  return value === true || value === 1 || value === '1';
}

function levelLabel(level?: string): string {
  if (!level) return 'سطح تأمین‌کننده ثبت نشده';
  const normalized = level.toLowerCase();
  const labels: Record<string, string> = { bronze: 'برنزی', silver: 'نقره‌ای', gold: 'طلایی', برنز: 'برنزی', نقره: 'نقره‌ای', طلا: 'طلایی' };
  return labels[normalized] ?? level;
}

function formatPrice(price: number | string, currency?: string): string {
  const amount = Number(price);
  const formatted = Number.isFinite(amount) ? amount.toLocaleString('fa-IR') : String(price);
  return `${formatted} ${currency || 'تومان'}`;
}

function PermissionRow({ title, description, value, disabled, onValueChange, icon }: { title: string; description: string; value: boolean; disabled: boolean; onValueChange: (value: boolean) => void; icon: 'message-text-outline' | 'phone-outline' }) {
  return (
    <View style={styles.permissionRow}>
      <View style={styles.permissionIcon}><MaterialCommunityIcons name={icon} size={19} color={COLORS.primaryDark} /></View>
      <View style={styles.permissionCopy}><Text style={styles.permissionTitle}>{title}</Text><Text style={styles.permissionDescription}>{description}</Text></View>
      <Switch value={value} disabled={disabled} onValueChange={onValueChange} trackColor={{ false: '#D6D3D1', true: '#D4A017' }} thumbColor={value ? '#fff' : '#F5F5F4'} />
    </View>
  );
}

export function OfferDetailScreen({ route, navigation }: Props) {
  const { offer, requestId } = route.params;
  const user = useAuthStore((s) => s.user);
  const [chatAllowed, setChatAllowed] = useState(enabled(offer.allow_chat));
  const [phoneAllowed, setPhoneAllowed] = useState(enabled(offer.allow_phone));
  const [permissionBusy, setPermissionBusy] = useState<'chat' | 'phone' | null>(null);
  const [acceptBusy, setAcceptBusy] = useState(false);

  const togglePermission = async (type: 'chat' | 'phone', next: boolean) => {
    type === 'chat' ? setChatAllowed(next) : setPhoneAllowed(next);
    setPermissionBusy(type);
    try {
      await api.toggleOfferPermission({ offer_id: offer.id, type });
    } catch (error) {
      type === 'chat' ? setChatAllowed(!next) : setPhoneAllowed(!next);
      Alert.alert('تغییر مجوز انجام نشد', error instanceof ApiError ? error.message : 'لطفاً دوباره تلاش کنید.');
    } finally {
      setPermissionBusy(null);
    }
  };

  const openChat = async () => {
    if (!chatAllowed) {
      Alert.alert('چت داخلی', 'برای شروع چت، ابتدا مجوز چت داخلی را فعال کنید.');
      return;
    }
    if (!user?.id) {
      Alert.alert('ورود لازم است', 'برای شروع گفتگو ابتدا وارد حساب خود شوید.');
      return;
    }
    const peerId = offer.supplier_id;
    if (peerId === undefined || peerId === null || String(peerId).length === 0) {
      Alert.alert('گفتگو آماده نیست', 'شناسهٔ تأمین‌کننده از سرور دریافت نشد. صفحه را دوباره باز کنید.');
      return;
    }
    const resolvedRequestId = requestId ?? offer.request_id;
    if (resolvedRequestId === undefined || resolvedRequestId === null) {
      Alert.alert('گفتگو آماده نیست', 'شناسهٔ درخواست مشخص نیست.');
      return;
    }
    const tabs = navigation.getParent() as unknown as { navigate: (name: string, params: object) => void } | undefined;
    if (!tabs) {
      Alert.alert('بازکردن چت انجام نشد', 'صفحهٔ پیام‌ها در دسترس نیست. اپ را دوباره باز کنید و تلاش کنید.');
      return;
    }
    const peerName = offer.supplier_name || 'تأمین‌کننده';
    const requestTitle = (offer as { request_title?: string }).request_title || 'گفتگو دربارهٔ پیشنهاد';
    await registerDraftThread(user.id, {
      requestId: resolvedRequestId,
      peerId,
      peerName,
      requestTitle,
    });
    tabs.navigate('Messages', {
      screen: 'ChatRoom',
      params: {
        requestId: resolvedRequestId,
        peerId,
        peerName,
        requestTitle,
        allowChat: String(offer.status ?? '').toLowerCase() !== 'rejected',
        outcome: String(offer.status ?? '').toLowerCase() === 'accepted'
          ? 'won'
          : String(offer.status ?? '').toLowerCase() === 'rejected'
            ? 'lost'
            : undefined,
      },
    });
  };

  const accept = async () => {

    setAcceptBusy(true);
    try {
      await api.acceptOffer(offer.id);
      Alert.alert(
        'پیشنهاد پذیرفته شد',
        'گفتگو با پیشنهاددهندهٔ منتخب همچنان باز می‌ماند. گفتگوی سایر پیشنهاددهندگان بسته می‌شود و پیام «پیشنهاد دیگری انتخاب شد» برایشان ارسال می‌شود.',
        [{ text: 'بازگشت به درخواست', onPress: () => navigation.popToTop() }],
      );
    } catch (error) {
      Alert.alert('پذیرش انجام نشد', error instanceof ApiError ? error.message : 'لطفاً دوباره تلاش کنید.');
    } finally {
      setAcceptBusy(false);
    }
  };

  const confirmAccept = () => Alert.alert('تأیید پذیرش پیشنهاد', 'آیا از پذیرش این پیشنهاد اطمینان دارید؟', [
    { text: 'انصراف', style: 'cancel' },
    { text: 'بله، قبول می‌کنم', onPress: () => void accept() },
  ]);

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <View style={styles.header}><Pressable onPress={() => navigation.goBack()} style={styles.headerButton}><MaterialCommunityIcons name="arrow-right" size={22} color={COLORS.text} /></Pressable><Text style={styles.headerTitle}>بررسی پیشنهاد</Text><View style={styles.headerButton} /></View>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.supplierCard}>
          <View style={styles.supplierAvatar}><Text style={styles.supplierInitial}>{(offer.supplier_name || 'ت')[0]}</Text></View>
          <Text style={styles.supplierLabel}>پیشنهاد از طرف</Text>
          <Text style={styles.supplierName}>{offer.supplier_name || 'تأمین‌کننده'}</Text>
          <View style={styles.levelBadge}><MaterialCommunityIcons name="medal-outline" size={15} color={COLORS.primaryDark} /><Text style={styles.levelText}>{levelLabel(offer.supplier_level)}</Text></View>
        </View>

        <View style={styles.priceCard}><Text style={styles.priceLabel}>قیمت پیشنهادی</Text><Text style={styles.price}>{formatPrice(offer.price, offer.currency)}</Text><View style={styles.priceDivider} /><View style={styles.deliveryRow}><View style={styles.deliveryIcon}><MaterialCommunityIcons name="truck-fast-outline" size={18} color={COLORS.primaryDark} /></View><View><Text style={styles.deliveryLabel}>زمان تحویل</Text><Text style={styles.deliveryValue}>{offer.delivery_time ?? 'توافقی'}</Text></View></View></View>

        <View style={styles.sectionCard}><Text style={styles.sectionTitle}>توضیحات تأمین‌کننده</Text><Text style={styles.description}>{offer.description?.trim() || 'توضیحی برای این پیشنهاد ثبت نشده است.'}</Text></View>

        <View style={styles.permissionCard}>
          <View style={styles.permissionHeading}><View style={styles.lockBadge}><MaterialCommunityIcons name="shield-check-outline" size={17} color={COLORS.primaryDark} /></View><View><Text style={styles.sectionTitle}>مدیریت دسترسی‌ها</Text><Text style={styles.permissionSubtitle}>مجوزهای این تأمین‌کننده را کنترل کنید</Text></View></View>
          <View style={styles.permissionDivider} />
          <PermissionRow title="اجازه چت داخلی" description="امکان گفت‌وگوی درون‌برنامه‌ای" value={chatAllowed} disabled={permissionBusy !== null} onValueChange={(value) => void togglePermission('chat', value)} icon="message-text-outline" />
          <View style={styles.permissionDivider} />
          <PermissionRow title="اجازه اشتراک شماره تماس" description="نمایش شماره تماس برای تأمین‌کننده" value={phoneAllowed} disabled={permissionBusy !== null} onValueChange={(value) => void togglePermission('phone', value)} icon="phone-outline" />
          {permissionBusy ? <View style={styles.savingRow}><ActivityIndicator size="small" color={COLORS.primary} /><Text style={styles.savingText}>در حال ذخیرهٔ مجوز...</Text></View> : null}
        </View>
      </ScrollView>
      <View style={styles.footer}>
        <Pressable onPress={() => void openChat()} style={[styles.chatButton, !chatAllowed && styles.chatButtonDisabled]}><MaterialCommunityIcons name="message-text-outline" size={17} color={chatAllowed ? COLORS.primaryDark : COLORS.muted} /><Text style={[styles.chatText, !chatAllowed && styles.chatTextDisabled]}>شروع چت</Text></Pressable>
        <Pressable disabled={acceptBusy} onPress={confirmAccept} style={({ pressed }) => [styles.acceptButton, pressed && { opacity: 0.86 }, acceptBusy && styles.disabled]}>{acceptBusy ? <ActivityIndicator color="#fff" /> : <><MaterialCommunityIcons name="check-circle-outline" size={18} color="#fff" /><Text style={styles.acceptText}>قبول پیشنهاد</Text></>}</Pressable>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.background },
  header: { minHeight: 56, paddingHorizontal: 17, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: '#EEEAE1' },
  headerButton: { width: 38, height: 38, borderRadius: 13, backgroundColor: '#fff', borderWidth: 1, borderColor: COLORS.border, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { fontFamily: 'VazirmatnBold', fontSize: 14, color: COLORS.text },
  content: { padding: 17, paddingBottom: 26 },
  supplierCard: { alignItems: 'center', paddingVertical: 19, paddingHorizontal: 16, backgroundColor: '#211B10', borderRadius: 21, marginBottom: 13 },
  supplierAvatar: { width: 60, height: 60, borderRadius: 21, backgroundColor: '#F4E9C9', alignItems: 'center', justifyContent: 'center', marginBottom: 8 },
  supplierInitial: { fontFamily: 'VazirmatnBold', fontSize: 25, color: COLORS.primaryDark },
  supplierLabel: { fontFamily: 'Vazirmatn', fontSize: 10, color: '#D6D3D1' },
  supplierName: { fontFamily: 'VazirmatnBold', fontSize: 17, color: '#FFFDF6', marginTop: 2 },
  levelBadge: { flexDirection: 'row-reverse', alignItems: 'center', gap: 5, borderRadius: 20, backgroundColor: '#F4E9C9', paddingHorizontal: 10, paddingVertical: 5, marginTop: 9 },
  levelText: { fontFamily: 'VazirmatnBold', fontSize: 9, color: COLORS.primaryDark },
  priceCard: { padding: 16, backgroundColor: '#fff', borderRadius: 18, borderWidth: 1, borderColor: '#EAE6DC', marginBottom: 12 },
  priceLabel: { fontFamily: 'Vazirmatn', fontSize: 10, color: COLORS.muted, textAlign: 'right' },
  price: { fontFamily: 'VazirmatnBold', fontSize: 22, color: COLORS.primaryDark, textAlign: 'right', marginTop: 3 },
  priceDivider: { height: 1, backgroundColor: '#F0EEEA', marginVertical: 12 },
  deliveryRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 9 },
  deliveryIcon: { width: 34, height: 34, borderRadius: 12, backgroundColor: '#FBF3DC', alignItems: 'center', justifyContent: 'center' },
  deliveryLabel: { fontFamily: 'Vazirmatn', fontSize: 9, color: COLORS.muted, textAlign: 'right' },
  deliveryValue: { fontFamily: 'VazirmatnBold', fontSize: 11, color: COLORS.text, textAlign: 'right', marginTop: 1 },
  sectionCard: { padding: 16, backgroundColor: '#fff', borderRadius: 18, borderWidth: 1, borderColor: '#EAE6DC', marginBottom: 12 },
  sectionTitle: { fontFamily: 'VazirmatnBold', fontSize: 13, color: COLORS.text, textAlign: 'right' },
  description: { fontFamily: 'Vazirmatn', fontSize: 11, lineHeight: 21, color: '#57534E', textAlign: 'right', marginTop: 7 },
  permissionCard: { padding: 15, backgroundColor: '#fff', borderRadius: 18, borderWidth: 1, borderColor: '#EAE6DC' },
  permissionHeading: { flexDirection: 'row-reverse', alignItems: 'center', gap: 9, marginBottom: 12 },
  lockBadge: { width: 34, height: 34, borderRadius: 12, backgroundColor: '#FBF3DC', alignItems: 'center', justifyContent: 'center' },
  permissionSubtitle: { fontFamily: 'Vazirmatn', fontSize: 9, color: COLORS.muted, textAlign: 'right', marginTop: 2 },
  permissionDivider: { height: 1, backgroundColor: '#F0EEEA' },
  permissionRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 9, minHeight: 65 },
  permissionIcon: { width: 31, height: 31, borderRadius: 11, backgroundColor: '#FBF3DC', alignItems: 'center', justifyContent: 'center' },
  permissionCopy: { flex: 1 },
  permissionTitle: { fontFamily: 'VazirmatnMedium', fontSize: 11, color: COLORS.text, textAlign: 'right' },
  permissionDescription: { fontFamily: 'Vazirmatn', fontSize: 8, color: COLORS.muted, textAlign: 'right', marginTop: 2 },
  savingRow: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', gap: 6, paddingTop: 7 },
  savingText: { fontFamily: 'Vazirmatn', fontSize: 9, color: COLORS.muted },
  footer: { flexDirection: 'row-reverse', gap: 9, paddingHorizontal: 17, paddingVertical: 11, borderTopWidth: 1, borderTopColor: COLORS.border, backgroundColor: 'rgba(250,250,249,0.98)' },
  chatButton: { flex: 1, minHeight: 50, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', gap: 6, borderRadius: 14, borderWidth: 1, borderColor: COLORS.primary, backgroundColor: '#FFFBEB' },
  chatButtonDisabled: { borderColor: COLORS.border, backgroundColor: '#F5F5F4' },
  chatText: { fontFamily: 'VazirmatnBold', fontSize: 12, color: COLORS.primaryDark },
  chatTextDisabled: { color: COLORS.muted },
  acceptButton: { flex: 1.2, minHeight: 50, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', gap: 6, borderRadius: 14, backgroundColor: COLORS.primaryDark },
  acceptText: { fontFamily: 'VazirmatnBold', fontSize: 12, color: '#fff' },
  disabled: { opacity: 0.65 },
});
