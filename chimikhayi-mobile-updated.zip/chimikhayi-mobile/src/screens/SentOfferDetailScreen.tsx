import React from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import type { DashboardStackParamList } from '../navigation/DashboardStackNavigator';
import { COLORS } from '../theme/colors';
import { formatDate, formatMoney, statusOf } from './SentOffersScreen';

type Props = NativeStackScreenProps<DashboardStackParamList, 'SentOfferDetail'>;

function Row({ icon, label, value }: { icon: keyof typeof MaterialCommunityIcons.glyphMap; label: string; value: string }) {
  return (
    <View style={styles.row}>
      <View style={styles.rowIcon}><MaterialCommunityIcons name={icon} size={18} color={COLORS.primaryDark} /></View>
      <View style={styles.rowCopy}><Text style={styles.rowLabel}>{label}</Text><Text style={styles.rowValue}>{value}</Text></View>
    </View>
  );
}

export function SentOfferDetailScreen({ route, navigation }: Props) {
  const { offer } = route.params;
  const status = statusOf(offer.status);
  const title = offer.request_title ?? offer.title ?? 'درخواست کالا';
  const date = formatDate(offer.created_at);

  const openRequest = () => {
    if (offer.request_id === undefined || offer.request_id === null) return;
    const tabs = navigation.getParent() as unknown as { navigate: (name: string, params: object) => void } | undefined;
    tabs?.navigate('HomeTab', { screen: 'RequestDetail', params: { requestId: offer.request_id } });
  };

  const hint = status.key === 'accepted'
    ? 'خریدار این پیشنهاد را پذیرفته است. برای هماهنگی، از صفحهٔ آگهی تماس یا چت را بزنید.'
    : status.key === 'rejected'
      ? 'این پیشنهاد پذیرفته نشد. می‌توانید برای درخواست‌های دیگر پیشنهاد بدهید.'
      : 'منتظر پاسخ خریدار هستید. خریدار پیشنهادها را مقایسه می‌کند و تصمیم می‌گیرد.';

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} style={styles.headerButton} accessibilityLabel="بازگشت"><MaterialCommunityIcons name="arrow-right" size={22} color={COLORS.text} /></Pressable>
        <Text style={styles.headerTitle}>جزئیات پیشنهاد</Text>
        <View style={styles.headerButton} />
      </View>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.hero}>
          <View style={[styles.badge, { backgroundColor: status.background }]}><Text style={[styles.badgeText, { color: status.color }]}>{status.label}</Text></View>
          <Text style={styles.heroLabel}>قیمت پیشنهادی شما</Text>
          <Text style={styles.heroPrice}>{formatMoney(offer.price, offer.currency)}</Text>
          <Text style={styles.heroTitle} numberOfLines={3}>{title}</Text>
        </View>

        <View style={styles.card}>
          <Row icon="truck-fast-outline" label="زمان تحویل" value={offer.delivery_time ? String(offer.delivery_time) : 'توافقی'} />
          {date ? <Row icon="calendar-clock-outline" label="تاریخ ارسال" value={date} /> : null}
          <Row icon="pound" label="شمارهٔ پیشنهاد" value={String(offer.id)} />
        </View>

        <View style={styles.card}>
          <Text style={styles.sectionTitle}>توضیحات پیشنهاد</Text>
          <Text style={styles.description}>{offer.description?.trim() || 'توضیحی برای این پیشنهاد ثبت نشده است.'}</Text>
        </View>

        <View style={styles.hintCard}><MaterialCommunityIcons name="information-outline" size={18} color={COLORS.primaryDark} /><Text style={styles.hintText}>{hint}</Text></View>

        {offer.request_id !== undefined && offer.request_id !== null ? (
          <Pressable onPress={openRequest} style={({ pressed }) => [styles.primary, pressed && { opacity: 0.86 }]}><MaterialCommunityIcons name="file-document-outline" size={19} color="#fff" /><Text style={styles.primaryText}>مشاهدهٔ آگهی و گفتگو با خریدار</Text></Pressable>
        ) : null}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.background },
  header: { minHeight: 56, paddingHorizontal: 16, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: '#EEEAE1', backgroundColor: '#fff' },
  headerButton: { width: 38, height: 38, borderRadius: 13, backgroundColor: COLORS.background, borderWidth: 1, borderColor: COLORS.border, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { fontFamily: 'VazirmatnBold', fontSize: 14, color: COLORS.text },
  content: { padding: 16, paddingBottom: 30 },
  hero: { padding: 18, borderRadius: 22, backgroundColor: '#211B10', alignItems: 'flex-end', marginBottom: 12 },
  badge: { paddingHorizontal: 11, paddingVertical: 5, borderRadius: 13 },
  badgeText: { fontFamily: 'VazirmatnBold', fontSize: 10 },
  heroLabel: { fontFamily: 'Vazirmatn', fontSize: 10, color: '#E4C66C', marginTop: 14 },
  heroPrice: { fontFamily: 'VazirmatnBold', fontSize: 25, color: '#FFFDF6', marginTop: 2 },
  heroTitle: { fontFamily: 'VazirmatnMedium', fontSize: 12, lineHeight: 21, color: '#D6D3D1', textAlign: 'right', marginTop: 10 },
  card: { padding: 15, borderRadius: 18, backgroundColor: '#fff', borderWidth: 1, borderColor: '#EAE6DC', marginBottom: 12, gap: 13 },
  row: { flexDirection: 'row-reverse', alignItems: 'center', gap: 11 },
  rowIcon: { width: 36, height: 36, borderRadius: 12, backgroundColor: '#F4E9C9', alignItems: 'center', justifyContent: 'center' },
  rowCopy: { flex: 1 },
  rowLabel: { fontFamily: 'Vazirmatn', fontSize: 9, color: COLORS.muted, textAlign: 'right' },
  rowValue: { fontFamily: 'VazirmatnBold', fontSize: 12, color: COLORS.text, textAlign: 'right', marginTop: 1 },
  sectionTitle: { fontFamily: 'VazirmatnBold', fontSize: 13, color: COLORS.text, textAlign: 'right' },
  description: { fontFamily: 'Vazirmatn', fontSize: 12, lineHeight: 23, color: '#57534E', textAlign: 'right' },
  hintCard: { flexDirection: 'row-reverse', alignItems: 'flex-start', gap: 8, padding: 13, borderRadius: 15, backgroundColor: '#FFFBEB', borderWidth: 1, borderColor: '#F4E9C9', marginBottom: 14 },
  hintText: { flex: 1, fontFamily: 'Vazirmatn', fontSize: 10, lineHeight: 19, color: '#78350F', textAlign: 'right' },
  primary: { minHeight: 50, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', gap: 8, borderRadius: 15, backgroundColor: COLORS.primaryDark },
  primaryText: { fontFamily: 'VazirmatnBold', fontSize: 13, color: '#fff' },
});
