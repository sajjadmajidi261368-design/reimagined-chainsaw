import React from 'react';
import { Alert, Linking, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import type { PricingStackParamList } from '../navigation/PricingStackNavigator';
import { useAuthStore } from '../store/authStore';
import { COLORS } from '../theme/colors';

type Props = NativeStackScreenProps<PricingStackParamList, 'Pricing'>;
const PLANS = [
  { id: 'month', title: 'یک‌ماهه', duration: '۱ ماه', price: 2490000, icon: 'calendar-month-outline' as const, description: 'برای شروع و تجربهٔ امکانات بیشتر', featured: false, benefits: ['ارسال پیشنهادهای بیشتر', 'دسترسی به درخواست‌های بازار', 'پشتیبانی استاندارد'] },
  { id: 'half-year', title: 'شش‌ماهه', duration: '۶ ماه', price: 12900000, icon: 'calendar-range-outline' as const, description: 'انتخاب متعادل برای فعالیت مستمر', featured: true, benefits: ['همهٔ امکانات طرح یک‌ماهه', 'صرفه‌جویی در تمدید دوره‌ای', 'اولویت در پشتیبانی'] },
  { id: 'year', title: 'یک‌ساله', duration: '۱۲ ماه', price: 21900000, icon: 'crown-outline' as const, description: 'برای کسب‌وکارهای فعال و حرفه‌ای', featured: false, benefits: ['همهٔ امکانات طرح شش‌ماهه', 'بیشترین مدت اعتبار', 'پشتیبانی ویژه'] },
];

export function PricingScreen(_props: Props) {
  const user = useAuthStore((state) => state.user);
  const openCheckout = async (plan: (typeof PLANS)[number]) => {
    if (!user) {
      Alert.alert('ورود لازم است', 'برای خرید اشتراک ابتدا وارد حساب خود شوید.');
      return;
    }
    if (user.role !== 'supplier' && user.role !== 'broker') {
      Alert.alert('این اشتراک مخصوص تأمین‌کننده است', 'برای خرید اشتراک تأمین‌کنندگان، با حساب تأمین‌کننده وارد شوید.');
      return;
    }
    if (!user.id) {
      Alert.alert('خطا', 'شناسه کاربر یافت نشد. لطفاً دوباره وارد شوید.');
      return;
    }
    const paymentUrl =
      `https://chimikhayi.ir/bitpay-init.php` +
      `?amount=${encodeURIComponent(String(plan.price))}` +
      `&user_id=${encodeURIComponent(String(user.id))}`;
    try {
      await Linking.openURL(paymentUrl);
    } catch {
      Alert.alert('بازکردن درگاه انجام نشد', 'مرورگر گوشی یا اتصال اینترنت را بررسی کنید و دوباره بزنید.');
    }
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}><View style={styles.headerIcon}><MaterialCommunityIcons name="crown-outline" size={22} color={COLORS.primaryDark} /></View><Text style={styles.headerTitle}>تعرفه‌ها</Text><Text style={styles.headerSubtitle}>{user?.role === 'buyer' ? 'خدمات خرید برای شما رایگان است' : 'طرح مناسب فعالیت خود را انتخاب کنید'}</Text></View>
        {user?.role === 'buyer' ? (
          <View style={styles.buyerFreeCard}>
            <View style={styles.buyerFreeIcon}><MaterialCommunityIcons name="check-decagram" size={30} color="#16845B" /></View>
            <Text style={styles.buyerFreeTitle}>رایگان برای شما، خریدار عزیز</Text>
            <Text style={styles.buyerFreeText}>ثبت درخواست خرید و دریافت پیشنهاد از تأمین‌کنندگان برای خریداران رایگان است. نیازی به خرید اشتراک ندارید.</Text>
          </View>
        ) : (
          <>
        <View style={styles.hero}><View style={styles.heroOrb} /><Text style={styles.heroEyebrow}>چی میخوای پلاس</Text><Text style={styles.heroTitle}>راهی مطمئن‌تر برای رشد تجارت شما</Text><Text style={styles.heroDescription}>۳۰ پیشنهاد اول رایگان است. پس از آن می‌توانید پلن اشتراک تهیه کنید.</Text></View>
        {PLANS.map((plan) => (
          <View key={plan.id} style={[styles.planCard, plan.featured && styles.featuredCard]}>
            {plan.featured ? <View style={styles.popularBadge}><MaterialCommunityIcons name="star-four-points" size={12} color="#fff" /><Text style={styles.popularText}>پیشنهاد ویژه</Text></View> : null}
            <View style={styles.planHeading}><View style={[styles.planIcon, plan.featured && styles.featuredIcon]}><MaterialCommunityIcons name={plan.icon} size={21} color={plan.featured ? '#F4E9C9' : COLORS.primaryDark} /></View><View style={styles.planTitleBlock}><Text style={[styles.planTitle, plan.featured && styles.lightText]}>{plan.title}</Text><Text style={[styles.planDescription, plan.featured && styles.lightMuted]}>{plan.description}</Text></View><Text style={[styles.duration, plan.featured && styles.durationFeatured]}>{plan.duration}</Text></View>
            <View style={[styles.divider, plan.featured && styles.featuredDivider]} />
            <Text style={[styles.price, plan.featured && styles.lightText]}>{plan.price.toLocaleString('fa-IR')} تومان</Text>
            <Text style={[styles.priceHint, plan.featured && styles.lightMuted]}>مالیات در مرحلهٔ پرداخت محاسبه می‌شود.</Text>
            <View style={styles.benefits}>{plan.benefits.map((benefit) => <View key={benefit} style={styles.benefitRow}><MaterialCommunityIcons name="check-circle" size={16} color={plan.featured ? '#E4C66C' : '#16845B'} /><Text style={[styles.benefitText, plan.featured && styles.lightMuted]}>{benefit}</Text></View>)}</View>
            <Pressable onPress={() => void openCheckout(plan)} style={({ pressed }) => [styles.buyButton, plan.featured && styles.featuredBuyButton, pressed && { opacity: 0.84 }]}><Text style={[styles.buyText, plan.featured && styles.featuredBuyText]}>پرداخت آنلاین</Text><MaterialCommunityIcons name="open-in-new" size={17} color={plan.featured ? COLORS.primaryDark : '#fff'} /></Pressable>
          </View>
        ))}
        <View style={styles.footerNote}><MaterialCommunityIcons name="shield-check-outline" size={17} color={COLORS.primaryDark} /><Text style={styles.footerText}>پرداخت آنلاین از مرورگر گوشی و در مسیر امن درگاه سایت انجام می‌شود.</Text></View>
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.background },
  content: { padding: 17, paddingBottom: 28 },
  header: { alignItems: 'center', marginBottom: 14 },
  headerIcon: { width: 46, height: 46, borderRadius: 16, backgroundColor: '#F4E9C9', alignItems: 'center', justifyContent: 'center', marginBottom: 7 },
  headerTitle: { fontFamily: 'VazirmatnBold', fontSize: 18, color: COLORS.text },
  headerSubtitle: { fontFamily: 'Vazirmatn', fontSize: 9, color: COLORS.muted, marginTop: 2 },
  buyerFreeCard: { alignItems: 'center', padding: 22, borderRadius: 21, backgroundColor: '#ECFDF5', borderWidth: 1, borderColor: '#A7F3D0', marginTop: 10 },
  buyerFreeIcon: { width: 58, height: 58, alignItems: 'center', justifyContent: 'center', borderRadius: 20, backgroundColor: '#D1FAE5', marginBottom: 10 },
  buyerFreeTitle: { fontFamily: 'VazirmatnBold', fontSize: 14, color: '#065F46', textAlign: 'center' },
  buyerFreeText: { fontFamily: 'Vazirmatn', fontSize: 10, lineHeight: 19, color: '#047857', textAlign: 'center', marginTop: 7 },
  hero: { position: 'relative', overflow: 'hidden', backgroundColor: '#211B10', borderRadius: 21, padding: 18, marginBottom: 13 },
  heroOrb: { position: 'absolute', width: 140, height: 140, borderRadius: 70, backgroundColor: 'rgba(212,160,23,0.12)', top: -70, left: -30 },
  heroEyebrow: { fontFamily: 'VazirmatnBold', fontSize: 9, color: '#E4C66C', textAlign: 'right' },
  heroTitle: { fontFamily: 'VazirmatnBold', fontSize: 15, color: '#FFFDF6', textAlign: 'right', marginTop: 6 },
  heroDescription: { fontFamily: 'Vazirmatn', fontSize: 9, lineHeight: 17, color: '#D6D3D1', textAlign: 'right', marginTop: 5 },
  planCard: { padding: 15, backgroundColor: '#fff', borderRadius: 19, borderWidth: 1, borderColor: '#EAE6DC', marginBottom: 11 },
  featuredCard: { backgroundColor: '#2B2415', borderColor: '#B58A1A', borderWidth: 1.5 },
  popularBadge: { position: 'absolute', top: 11, left: 12, flexDirection: 'row', alignItems: 'center', gap: 4, borderRadius: 10, backgroundColor: COLORS.primaryDark, paddingHorizontal: 8, paddingVertical: 4 },
  popularText: { fontFamily: 'VazirmatnBold', fontSize: 7, color: '#fff' },
  planHeading: { flexDirection: 'row-reverse', alignItems: 'center', gap: 9 },
  planIcon: { width: 40, height: 40, borderRadius: 14, backgroundColor: '#F4E9C9', alignItems: 'center', justifyContent: 'center' },
  featuredIcon: { backgroundColor: 'rgba(244,233,201,0.14)' },
  planTitleBlock: { flex: 1 },
  planTitle: { fontFamily: 'VazirmatnBold', fontSize: 13, color: COLORS.text, textAlign: 'right' },
  planDescription: { fontFamily: 'Vazirmatn', fontSize: 8, color: COLORS.muted, textAlign: 'right', marginTop: 2 },
  duration: { fontFamily: 'VazirmatnBold', fontSize: 9, color: COLORS.primaryDark, backgroundColor: '#FFFBEB', borderRadius: 10, overflow: 'hidden', paddingHorizontal: 8, paddingVertical: 5 },
  durationFeatured: { color: '#F4E9C9', backgroundColor: 'rgba(244,233,201,0.12)' },
  divider: { height: 1, backgroundColor: '#F0EEEA', marginVertical: 12 },
  featuredDivider: { backgroundColor: 'rgba(255,255,255,0.12)' },
  price: { fontFamily: 'VazirmatnBold', fontSize: 13, color: COLORS.primaryDark, textAlign: 'right' },
  priceHint: { fontFamily: 'Vazirmatn', fontSize: 7, color: COLORS.muted, textAlign: 'right', marginTop: 2 },
  benefits: { gap: 7, marginTop: 10 },
  benefitRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 6 },
  benefitText: { fontFamily: 'Vazirmatn', fontSize: 9, color: '#57534E', textAlign: 'right' },
  buyButton: { minHeight: 42, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', gap: 7, borderRadius: 12, backgroundColor: COLORS.primaryDark, marginTop: 13 },
  featuredBuyButton: { backgroundColor: '#E4C66C' },
  buyText: { fontFamily: 'VazirmatnBold', fontSize: 10, color: '#fff' },
  featuredBuyText: { color: COLORS.primaryDark },
  lightText: { color: '#FFFDF6' },
  lightMuted: { color: '#D6D3D1' },
  footerNote: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 8 },
  footerText: { fontFamily: 'Vazirmatn', fontSize: 8, color: COLORS.muted },
});
