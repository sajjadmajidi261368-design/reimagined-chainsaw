import React, { useRef, useState } from 'react';
import { ActivityIndicator, Alert, Linking, Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { WebView } from 'react-native-webview';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { COLORS } from '../theme/colors';

const BLOG_URL = 'https://chimikhayi.ir/blog.html';
const FAQ_URL = 'https://chimikhayi.ir/faq.html';
const HIDE_SITE_CHROME = `
(function() {
  function hideSiteChrome() {
    var root = document.documentElement;
    if (!root) return;
    var styleId = 'chimikhayi-native-bottom-nav-fix';
    if (!document.getElementById(styleId)) {
      var style = document.createElement('style');
      style.id = styleId;
      style.textContent = 'header,#header,#site-header,.site-header,.main-header,.mobile-header,.desktop-header,.navbar,.site-navbar,.main-nav,.site-nav,.top-nav,.topbar,.top-bar,[data-site-header],nav,[role="navigation"],footer,#footer,#site-footer,.site-footer,.main-footer,.mobile-bottom-nav,.mobileBottomNav,.bottom-nav,.bottomNav,.bottom-navigation,.bottomNavigation,.tab-bar,.tabBar,#mobile-bottom-nav,#mobileBottomNav,#bottom-nav,#bottomNav,[data-mobile-bottom-nav],[class*="sticky-bottom"],[id*="sticky-bottom"],.fixed.bottom-0,.fixed.inset-x-0{display:none!important;visibility:hidden!important;height:0!important;max-height:0!important;min-height:0!important;pointer-events:none!important}body{padding-bottom:0!important;padding-top:0!important;margin-bottom:0!important;margin-top:0!important}';
      (document.head || root).appendChild(style);
    }
    document.querySelectorAll('header,nav,[role="navigation"],footer,[class*="bottom"],[id*="bottom"],[class*="footer"],[id*="footer"],[class*="tabbar"],[class*="tab-bar"]').forEach(function(el) {
      var css = window.getComputedStyle(el);
      var rect = el.getBoundingClientRect();
      if (el.tagName === 'HEADER' || el.tagName === 'NAV' || el.tagName === 'FOOTER' || el.getAttribute('role') === 'navigation' || ((css.position === 'fixed' || css.position === 'sticky') && (css.bottom === '0px' || rect.bottom >= window.innerHeight - 4))) {
        el.remove();
      }
    });
    if (document.body) { document.body.style.setProperty('padding-bottom','0','important'); document.body.style.setProperty('padding-top','0','important'); document.body.style.setProperty('margin-bottom','0','important'); document.body.style.setProperty('margin-top','0','important'); }
  }
  var observer = new MutationObserver(hideSiteChrome);
  hideSiteChrome();
  if (document.documentElement) observer.observe(document.documentElement,{childList:true,subtree:true});
  else document.addEventListener('DOMContentLoaded',function(){if(document.documentElement) observer.observe(document.documentElement,{childList:true,subtree:true});hideSiteChrome();},{once:true});
  window.addEventListener('load',hideSiteChrome);
  window.addEventListener('resize',hideSiteChrome);
})();
true;
`;


/**
 * The blog is a read-only knowledge base inside the app. Cards on the site contain call-to-action buttons
 * (register, post a request, log in ...) that would drop the user into the website with no way back.
 * We remove those buttons (but keep text and ordinary links) and never let the WebView leave the
 * blog/FAQ content. Buttons that only expand or collapse a card are left alone.
 */
const REMOVE_CTAS = `
(function() {
  var CTA_TEXT = /(ثبت[\\s\\u200c]*نام|ثبت[\\s\\u200c]*درخواست|ثبت[\\s\\u200c]*آگهی|ورود|عضویت|شروع[\\s\\u200c]*کن|همین[\\s\\u200c]*حالا|رایگان[\\s\\u200c]*شروع|ارسال[\\s\\u200c]*پیشنهاد|sign[\\s-]*up|register|log[\\s-]*in)/i;
  var CTA_HREF = /(login|register|signup|sign-up|auth|dashboard|panel|request|offer|pricing|checkout|payment|profile|messages|chat|index)/i;
  function isToggle(el) {
    return el.hasAttribute('aria-expanded') || el.hasAttribute('aria-controls') || el.hasAttribute('data-toggle') || el.hasAttribute('data-bs-toggle') || (el.closest && el.closest('summary'));
  }
  function looksLikeButton(el) {
    var cls = (el.className && el.className.toString ? el.className.toString() : '') || '';
    return /(^|[\\s_-])(btn|button|cta)([\\s_-]|$)/i.test(cls) || /btn|button|cta/i.test(cls);
  }
  function sweep() {
    try {
      document.querySelectorAll('button,input[type="button"],input[type="submit"],[role="button"],a').forEach(function(el) {
        if (el.getAttribute('data-chimikhayi-keep') === '1') return;
        var tag = el.tagName;
        var text = (el.textContent || el.value || '').trim();
        var href = tag === 'A' ? (el.getAttribute('href') || '') : '';
        if (tag === 'A') {
          var pointsAway = CTA_HREF.test(href) && !/^https?:\\/\\/(?!(www\\.)?chimikhayi\\.ir)/i.test(href);
          if (pointsAway || ((looksLikeButton(el) || CTA_TEXT.test(text)) && !isToggle(el) && text.length < 40)) el.style.setProperty('display','none','important');
          return;
        }
        if (isToggle(el)) return;
        el.style.setProperty('display','none','important');
      });
    } catch (e) {}
  }
  sweep();
  if (document.documentElement) new MutationObserver(sweep).observe(document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
  window.addEventListener('load', sweep);
  document.addEventListener('click', function(e) {
    var a = e.target && e.target.closest ? e.target.closest('a') : null;
    if (a && CTA_HREF.test(a.getAttribute('href') || '') && !/^https?:\\/\\/(?!(www\\.)?chimikhayi\\.ir)/i.test(a.getAttribute('href') || '')) { e.preventDefault(); e.stopPropagation(); }
  }, true);
})();
true;
`;
const BLOCKED_PATHS = /(login|register|signup|sign-up|auth|dashboard|panel|request|offer|pricing|checkout|payment|profile|messages|chat|index)/i;
const ALLOWED_PATHS = /(blog|faq|article|post|news|guide|learn|wiki|knowledge)/i;
function isBlogContentPath(pathname: string, search: string): boolean {
  const path = decodeURIComponent(pathname).toLowerCase();
  if (BLOCKED_PATHS.test(path) || /(^|[?&])(page|view|tab)=(login|register|signup|request)/i.test(search)) return false;
  return ALLOWED_PATHS.test(path) || /\/$/.test(path) === false && /\.html?$/.test(path) && ALLOWED_PATHS.test(search);
}

export function BlogTab() {
  const webRef = useRef<WebView>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [attempt, setAttempt] = useState(0);
  const [page, setPage] = useState<'blog' | 'faq'>('blog');
  const activeUrl = page === 'faq' ? FAQ_URL : BLOG_URL;

  const openExternal = (url: string) => {
    if (!url || url === 'about:blank' || url.startsWith('javascript:')) return;
    void Linking.openURL(url).catch(() => Alert.alert('بازکردن پیوند انجام نشد', 'لطفاً اتصال اینترنت و برنامهٔ مرورگر را بررسی کنید.'));
  };

  const shouldStartNavigation = (request: { url: string }) => {
    const target = request.url;
    if (target === 'about:blank' || target.startsWith('blob:') || target.startsWith('data:')) return true;
    try {
      const destination = new URL(target);
      const internalHost = destination.hostname === 'chimikhayi.ir' || destination.hostname === 'www.chimikhayi.ir';
      if (internalHost) {
        // Stay inside blog/FAQ content. Any other page of the site (register, post a request, login ...)
        // is silently blocked so the user can never get stuck on the website.
        if (!isBlogContentPath(destination.pathname, destination.search)) return false;
        if (destination.protocol === 'https:') return true;
        if (destination.protocol === 'http:') {
          const secureUrl = `https://chimikhayi.ir${destination.pathname}${destination.search}${destination.hash}`;
          webRef.current?.injectJavaScript(`window.location.replace(${JSON.stringify(secureUrl)}); true;`);
          return false;
        }
      }
    } catch {
      return false;
    }
    openExternal(target);
    return false;
  };

  const handleOpenWindow = (url: string) => {
    try {
      const target = new URL(url);
      if (target.protocol === 'https:' && ['chimikhayi.ir', 'www.chimikhayi.ir'].includes(target.hostname)) {
        if (isBlogContentPath(target.pathname, target.search)) webRef.current?.injectJavaScript(`window.location.href=${JSON.stringify(url)}; true;`);
        return;
      }
    } catch { /* Invalid or non-web links are handled by openExternal. */ }
    openExternal(url);
  };

  const retry = () => {
    setError(false);
    setLoading(true);
    setAttempt((value) => value + 1);
  };

  const handleError = () => {
    setLoading(false);
    setError(true);
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <View style={styles.header}><View style={styles.headerIcon}><MaterialCommunityIcons name={page === 'faq' ? 'frequently-asked-questions' : 'text-box-outline'} size={20} color={COLORS.primaryDark} /></View><View style={styles.headerCopy}><Text style={styles.title}>{page === 'faq' ? 'سوالات متداول' : 'وبلاگ چی میخوای'}</Text><Text style={styles.subtitle}>{page === 'faq' ? 'راهنمای استفاده از پلتفرم' : 'راهنماها و تازه‌های بازار'}</Text></View><Pressable onPress={() => { setError(false); setLoading(true); setPage((current) => current === 'blog' ? 'faq' : 'blog'); }} style={styles.reloadButton} accessibilityLabel={page === 'faq' ? 'بازگشت به وبلاگ' : 'نمایش سوالات متداول'}><MaterialCommunityIcons name={page === 'faq' ? 'arrow-right' : 'help-circle-outline'} size={19} color={COLORS.primaryDark} /></Pressable><Pressable onPress={retry} style={styles.reloadButton} accessibilityLabel="بارگذاری دوباره"><MaterialCommunityIcons name="reload" size={19} color={COLORS.primaryDark} /></Pressable></View>
      <View style={styles.webContainer}>
        <WebView
          key={attempt}
          ref={webRef}
          source={{ uri: activeUrl }}
          onLoadStart={() => { setLoading(true); setError(false); }}
          onLoadEnd={() => setLoading(false)}
          onError={handleError}
          onHttpError={(event) => { try { if (new URL(event.nativeEvent.url).pathname === new URL(activeUrl).pathname) handleError(); } catch { /* Ignore malformed subresource URLs. */ } }}
          startInLoadingState
          renderLoading={() => <View style={styles.loading}><ActivityIndicator size="large" color={COLORS.primary} /><Text style={styles.loadingText}>در حال بارگذاری وبلاگ...</Text></View>}
          javaScriptEnabled
          domStorageEnabled
          sharedCookiesEnabled
          injectedJavaScriptBeforeContentLoaded={HIDE_SITE_CHROME + REMOVE_CTAS}
          injectedJavaScript={HIDE_SITE_CHROME + REMOVE_CTAS}
          onShouldStartLoadWithRequest={shouldStartNavigation}
          onOpenWindow={(event) => handleOpenWindow(event.nativeEvent.targetUrl)}
          onNavigationStateChange={() => webRef.current?.injectJavaScript(HIDE_SITE_CHROME + REMOVE_CTAS)}
          style={styles.webView}
        />
        {loading && <View pointerEvents="none" style={styles.loadingOverlay}><ActivityIndicator size="large" color={COLORS.primary} /><Text style={styles.loadingText}>در حال بارگذاری وبلاگ...</Text></View>}
        {error && <View style={styles.errorOverlay}><View style={styles.errorIcon}><MaterialCommunityIcons name="wifi-alert" size={24} color={COLORS.danger} /></View><Text style={styles.errorTitle}>وبلاگ بارگذاری نشد</Text><Text style={styles.errorText}>اتصال اینترنت را بررسی کنید و دوباره تلاش کنید.</Text><Pressable onPress={retry} style={styles.retryButton}><MaterialCommunityIcons name="reload" size={16} color="#fff" /><Text style={styles.retryText}>تلاش دوباره</Text></Pressable></View>}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.background },
  header: { minHeight: 65, flexDirection: 'row-reverse', alignItems: 'center', gap: 10, paddingHorizontal: 16, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#EEEAE1' },
  headerIcon: { width: 39, height: 39, borderRadius: 14, backgroundColor: '#F4E9C9', alignItems: 'center', justifyContent: 'center' },
  headerCopy: { flex: 1 },
  title: { fontFamily: 'VazirmatnBold', fontSize: 13, color: COLORS.text, textAlign: 'right' },
  subtitle: { fontFamily: 'Vazirmatn', fontSize: 9, color: COLORS.muted, textAlign: 'right', marginTop: 1 },
  reloadButton: { width: 36, height: 36, borderRadius: 12, backgroundColor: COLORS.background, alignItems: 'center', justifyContent: 'center' },
  webContainer: { flex: 1, position: 'relative', backgroundColor: '#fff' },
  webView: { flex: 1, backgroundColor: '#fff' },
  loading: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center', gap: 9, backgroundColor: '#fff' },
  loadingOverlay: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center', gap: 9, backgroundColor: 'rgba(255,255,255,0.92)' },
  loadingText: { fontFamily: 'Vazirmatn', fontSize: 10, color: COLORS.muted },
  errorOverlay: { ...StyleSheet.absoluteFillObject, alignItems: 'center', justifyContent: 'center', padding: 25, backgroundColor: COLORS.background },
  errorIcon: { width: 52, height: 52, borderRadius: 18, alignItems: 'center', justifyContent: 'center', backgroundColor: '#FEF2F2', marginBottom: 10 },
  errorTitle: { fontFamily: 'VazirmatnBold', fontSize: 14, color: COLORS.text },
  errorText: { fontFamily: 'Vazirmatn', fontSize: 10, color: COLORS.muted, textAlign: 'center', marginTop: 4, lineHeight: 19 },
  retryButton: { flexDirection: 'row-reverse', alignItems: 'center', gap: 6, backgroundColor: COLORS.primaryDark, paddingHorizontal: 15, paddingVertical: 9, borderRadius: 12, marginTop: 13 },
  retryText: { fontFamily: 'VazirmatnBold', fontSize: 10, color: '#fff' },
});
