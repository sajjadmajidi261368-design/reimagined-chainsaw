import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Alert, Pressable, ScrollView, StyleSheet, Switch, Text, View } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Notifications from 'expo-notifications';
import Constants from 'expo-constants';
import * as Device from 'expo-device';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import type { DashboardStackParamList } from '../navigation/DashboardStackNavigator';
import { useAuthStore } from '../store/authStore';
import { COLORS } from '../theme/colors';

type Props = NativeStackScreenProps<DashboardStackParamList, 'Settings'>;
const MESSAGE_PREF_KEY = 'chimikhayi.preferences.messagePush';
const PUSH_BACKEND_READY = false;

export function SettingsScreen({ navigation }: Props) {
  const user = useAuthStore((state) => state.user);
  const [messagePush, setMessagePush] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    void AsyncStorage.getItem(MESSAGE_PREF_KEY).then((value) => setMessagePush(value === '1'));
  }, []);

  const setMessageNotifications = async (enabled: boolean) => {
    if (!enabled) {
      setMessagePush(false);
      await AsyncStorage.setItem(MESSAGE_PREF_KEY, '0');
      await AsyncStorage.removeItem('chimikhayi.pendingExpoPushToken');
      return;
    }
    setBusy(true);
    try {
      if (!Device.isDevice) throw new Error('برای فعال‌سازی اعلان، اپ را روی گوشی واقعی اجرا کنید.');
      if (process.env.EXPO_OS === 'android') {
        await Notifications.setNotificationChannelAsync('messages', {
          name: 'پیام‌های چی میخوای',
          importance: Notifications.AndroidImportance.HIGH,
          vibrationPattern: [0, 250, 250, 250],
          lightColor: '#D4A017',
        });
      }
      let permission = await Notifications.getPermissionsAsync();
      if (permission.status !== 'granted') permission = await Notifications.requestPermissionsAsync();
      if (permission.status !== 'granted') throw new Error('مجوز اعلان در تنظیمات گوشی داده نشد.');
      const projectId = Constants.easConfig?.projectId ?? Constants.expoConfig?.extra?.eas?.projectId;
      if (!projectId || projectId.includes('REPLACE_WITH')) throw new Error('شناسهٔ پروژهٔ Expo هنوز در تنظیمات EAS ثبت نشده است.');
      const token = (await Notifications.getExpoPushTokenAsync({ projectId })).data;
      await AsyncStorage.setItem('chimikhayi.pendingExpoPushToken', token);
      await AsyncStorage.setItem(MESSAGE_PREF_KEY, '1');
      setMessagePush(true);
      if (PUSH_BACKEND_READY) {
        Alert.alert('اعلان پیام فعال شد', 'اعلان‌های پیام برای این دستگاه فعال هستند.');
      } else {
        Alert.alert('اعلان‌ها به‌زودی 🔔', 'در نسخه‌های بعدی اعلان فعال می‌شود.', [{ text: 'باشه' }]);
      }
    } catch {
      setMessagePush(false);
      await AsyncStorage.setItem(MESSAGE_PREF_KEY, '0').catch(() => undefined);
      Alert.alert('اعلان‌ها به‌زودی 🔔', 'در نسخه‌های بعدی اعلان فعال می‌شود.', [{ text: 'باشه' }]);
    } finally {
      setBusy(false);
    }
  };

  return (
    <SafeAreaView style={styles.safeArea} edges={['top']}>
      <View style={styles.header}>
        <Pressable onPress={() => navigation.goBack()} style={styles.headerButton} accessibilityLabel="بازگشت"><MaterialCommunityIcons name="arrow-right" size={22} color={COLORS.text} /></Pressable>
        <Text style={styles.headerTitle}>تنظیمات حساب</Text>
        <View style={styles.headerButton} />
      </View>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={styles.sectionTitle}>حساب کاربری</Text>
        <Pressable onPress={() => navigation.navigate('ProfileEdit')} style={styles.actionRow}>
          <View style={styles.rowIcon}><MaterialCommunityIcons name="account-edit-outline" size={19} color={COLORS.primaryDark} /></View>
          <View style={styles.rowCopy}><Text style={styles.rowTitle}>پروفایل</Text><Text style={styles.rowHint}>ویرایش نام و تصویر؛ نقش و شماره ثابت می‌مانند</Text></View>
          <MaterialCommunityIcons name="chevron-left" size={20} color={COLORS.muted} />
        </Pressable>
        <Pressable onPress={() => navigation.navigate('Kyc')} style={styles.actionRow}>
          <View style={styles.rowIcon}><MaterialCommunityIcons name="shield-check-outline" size={19} color={COLORS.primaryDark} /></View>
          <View style={styles.rowCopy}><Text style={styles.rowTitle}>احراز هویت و ستارهٔ اعتماد</Text><Text style={styles.rowHint}>کد ملی، تصویر مدارک و اطلاعات کسب‌وکار؛ با هر مرحله سطح اعتماد شما بالاتر می‌رود</Text></View>
          <MaterialCommunityIcons name="chevron-left" size={20} color={COLORS.muted} />
        </Pressable>

        <Text style={[styles.sectionTitle, styles.sectionGap]}>اعلان‌ها</Text>
        <View style={styles.notificationCard}>
          <View style={styles.notificationTop}>
            <View style={styles.rowIcon}><MaterialCommunityIcons name="bell-ring-outline" size={19} color={COLORS.primaryDark} /></View>
            <View style={styles.rowCopy}><Text style={styles.rowTitle}>اعلان پیام جدید</Text><Text style={styles.rowHint}>اعلان سیستمی برای پیام‌های گفتگو</Text></View>
            {busy ? <ActivityIndicator size="small" color={COLORS.primary} /> : <Switch value={messagePush} onValueChange={(value) => void setMessageNotifications(value)} trackColor={{ false: '#D6D3D1', true: '#E4C66C' }} thumbColor={messagePush ? COLORS.primaryDark : '#fff'} />}
          </View>
          <View style={styles.notice}><MaterialCommunityIcons name="information-outline" size={16} color="#92400E" /><Text style={styles.noticeText}>{PUSH_BACKEND_READY ? 'اعلان‌های این دستگاه فعال هستند.' : 'در نسخه‌های بعدی اعلان فعال می‌شود.'}</Text></View>
        </View>
        <View style={styles.readOnlyCard}><MaterialCommunityIcons name="account-lock-outline" size={19} color={COLORS.muted} /><Text style={styles.readOnlyText}>نقش حساب و شمارهٔ همراه از این بخش قابل تغییر نیستند.</Text></View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: COLORS.background },
  header: { minHeight: 56, paddingHorizontal: 17, flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between', borderBottomWidth: 1, borderBottomColor: '#EEEAE1', backgroundColor: '#fff' },
  headerButton: { width: 38, height: 38, borderRadius: 13, backgroundColor: COLORS.background, borderWidth: 1, borderColor: COLORS.border, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { fontFamily: 'VazirmatnBold', fontSize: 14, color: COLORS.text },
  content: { padding: 17, paddingBottom: 30 },
  sectionTitle: { fontFamily: 'VazirmatnBold', fontSize: 12, color: COLORS.text, textAlign: 'right', marginBottom: 9 },
  sectionGap: { marginTop: 19 },
  actionRow: { minHeight: 68, flexDirection: 'row-reverse', alignItems: 'center', gap: 10, paddingHorizontal: 11, paddingVertical: 10, backgroundColor: '#fff', borderRadius: 15, borderWidth: 1, borderColor: '#EAE6DC', marginBottom: 8 },
  rowIcon: { width: 37, height: 37, borderRadius: 13, backgroundColor: '#F4E9C9', alignItems: 'center', justifyContent: 'center' },
  rowCopy: { flex: 1 },
  rowTitle: { fontFamily: 'VazirmatnBold', fontSize: 10, color: COLORS.text, textAlign: 'right' },
  rowHint: { fontFamily: 'Vazirmatn', fontSize: 8, color: COLORS.muted, textAlign: 'right', marginTop: 2, lineHeight: 14 },
  notificationCard: { padding: 12, backgroundColor: '#fff', borderRadius: 16, borderWidth: 1, borderColor: '#EAE6DC' },
  notificationTop: { flexDirection: 'row-reverse', alignItems: 'center', gap: 9 },
  notice: { flexDirection: 'row-reverse', gap: 6, alignItems: 'flex-start', marginTop: 10, padding: 9, borderRadius: 11, backgroundColor: '#FFFBEB' },
  noticeText: { flex: 1, fontFamily: 'Vazirmatn', fontSize: 8, lineHeight: 15, color: '#78350F', textAlign: 'right' },
  readOnlyCard: { flexDirection: 'row-reverse', alignItems: 'center', gap: 7, marginTop: 12, padding: 11, backgroundColor: '#F5F5F4', borderRadius: 12 },
  readOnlyText: { flex: 1, fontFamily: 'Vazirmatn', fontSize: 8, color: COLORS.muted, textAlign: 'right' },
});
