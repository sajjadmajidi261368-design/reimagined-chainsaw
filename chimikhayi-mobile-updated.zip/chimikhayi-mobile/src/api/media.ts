export const SITE_ORIGIN = 'https://chimikhayi.ir';

/** Resolve API media paths against the website origin, preserving absolute URLs. */
export function mediaUrl(value?: string | null): string | undefined {
  const raw = value?.trim();
  if (!raw) return undefined;
  if (/^(data|blob):/i.test(raw)) return raw;
  if (/^https?:\/\//i.test(raw)) return raw;
  if (raw.startsWith('//')) return `https:${raw}`;

  try {
    return new URL(raw.replace(/\\/g, '/'), `${SITE_ORIGIN}/`).toString();
  } catch {
    return `${SITE_ORIGIN}/${raw.replace(/^\/+/, '')}`;
  }
}
