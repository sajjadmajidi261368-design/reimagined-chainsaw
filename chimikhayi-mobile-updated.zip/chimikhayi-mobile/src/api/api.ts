export const API_BASE_URL = 'https://chimikhayi.ir/api/';

export type ApiErrorCode = 'auth' | 'quota_exceeded' | string;

export class ApiError extends Error {
  code?: ApiErrorCode;
  status?: number;

  constructor(message: string, code?: ApiErrorCode, status?: number) {
    super(message);
    this.name = 'ApiError';
    this.code = code;
    this.status = status;
  }
}

export type RegistrationPayload = {
  name: string;
  mobile: string;
  password: string;
  role: 'buyer' | 'supplier' | 'broker';
  is_broker?: number;
};

export type OpenRequest = {
  id: number | string;
  title: string;
  user_id?: number | string;
  buyer_id?: number | string;
  buyer_name?: string | null;
  buyer_avatar?: string | null;
  avatar_url?: string | null;
  files?: RequestFile[] | null;
  category?: string;
  category_name?: string;
  description?: string;
  province?: string;
  quantity?: string | number;
  unit?: string;
  status?: string;
};

export type OpenRequestsResult = OpenRequest[] | {
  requests?: OpenRequest[];
  data?: OpenRequest[];
  items?: OpenRequest[];
};

export type MyRequestItem = OpenRequest & {
  offers_count?: number | string;
  created_at?: string;
};

export type MyOfferItem = {
  id: number | string;
  request_id?: number | string;
  request_title?: string;
  title?: string;
  price: number | string;
  currency?: string;
  delivery_time?: string | number;
  status?: 'pending' | 'accepted' | 'rejected' | string;
  created_at?: string;
  description?: string;
  buyer_name?: string;
  allow_chat?: boolean | number | string;
  allow_phone?: boolean | number | string;
};

export type MyRequestsResult = MyRequestItem[] | { requests?: MyRequestItem[]; data?: MyRequestItem[]; items?: MyRequestItem[] };
export type MyOffersResult = MyOfferItem[] | { offers?: MyOfferItem[]; data?: MyOfferItem[]; items?: MyOfferItem[]; offers_count?: number | string };

export type RequestFile = string | { url?: string; path?: string; name?: string; type?: string; ext?: string };

export type RequestOffer = {
  id: number | string;
  request_id?: number | string;
  supplier_id?: number | string;
  supplier_name?: string;
  price: number | string;
  currency?: string;
  delivery_time?: string | number;
  description?: string;
  supplier_level?: string;
  status?: string;
  allow_chat?: boolean | number | string;
  allow_phone?: boolean | number | string;
  buyer_mobile?: string | null;
};

export type RequestDetails = {
  id: number | string;
  title: string;
  status?: string;
  buyer_id?: number | string;
  user_id?: number | string;
  buyer_name?: string;
  buyer_avatar?: string | null;
  buyer_mobile?: string | null;
  allow_chat?: boolean | number | string;
  allow_phone?: boolean | number | string;
  avatar_url?: string | null;
  category?: string;
  category_name?: string;
  description?: string;
  quantity?: string | number;
  unit?: string;
  payment_type?: string;
  province?: string;
  files?: RequestFile[] | null;
  offers?: RequestOffer[];
  buyer?: { id?: number | string; name?: string | null; full_name?: string | null; avatar?: string | null; avatar_url?: string | null };
  user?: { id?: number | string; name?: string | null; full_name?: string | null; avatar?: string | null; avatar_url?: string | null };
  name?: string | null;
  full_name?: string | null;
  user_name?: string | null;
  display_name?: string | null;
};

export type RequestDetailResult = RequestDetails | {
  request?: RequestDetails;
  data?: RequestDetails;
  offers?: RequestOffer[];
};

export type ChatThread = {
  id?: number | string;
  request_id: number | string;
  peer_id: number | string;
  peer_name: string;
  peer_avatar?: string | null;
  request_title: string;
  last_message?: string | null;
  last_message_at?: string | null;
  unread_count?: number | string;
  allow_chat?: boolean | number | string;
  chat_allowed?: boolean | number | string;
};

export type ChatMessage = {
  id: number | string;
  request_id: number | string;
  sender_id?: number | string;
  receiver_id?: number | string;
  message: string;
  created_at?: string;
  file_name?: string;
  file_url?: string;
  file_type?: string;
  file_path?: string;
  url?: string;
  mime_type?: string;
  is_read?: boolean | number | string;
  user_id?: number | string;
  from_id?: number | string;
  from_user_id?: number | string;
  author_id?: number | string;
  is_mine?: boolean | number | string;
  sender?: { id?: number | string; user_id?: number | string } | number | string;
};

export type ChatFileUploadResult = {
  success?: boolean;
  file_name?: string;
  file_url?: string;
  file_path?: string;
  url?: string;
  path?: string;
  file_type?: string;
  mime_type?: string;
  name?: string;
  type?: string;
  file?: { file_name?: string; name?: string; file_url?: string; file_path?: string; url?: string; path?: string; file_type?: string; mime_type?: string; type?: string };
  data?: { file_name?: string; name?: string; file_url?: string; file_path?: string; url?: string; path?: string; file_type?: string; mime_type?: string; type?: string };
  message?: string;
};

export type ChatsResult = ChatThread[] | { chats?: ChatThread[]; data?: ChatThread[]; items?: ChatThread[] };
export type MessagesResult = ChatMessage[] | {
  messages?: ChatMessage[];
  data?: ChatMessage[];
  items?: ChatMessage[];
  allow_chat?: boolean | number | string;
  chat_allowed?: boolean | number | string;
  request_status?: string;
  status?: string;
};
export type SendMessageResult = { success?: boolean; data?: ChatMessage; message?: ChatMessage | string };

type ApiEnvelope<T> = { ok: true } & T | { ok: false; error?: string; code?: ApiErrorCode };
type RequestOptions = { method?: 'GET' | 'POST' | 'PUT' | 'DELETE'; body?: unknown };

export async function apiRequest<T>(endpoint: string, options: RequestOptions = {}): Promise<T> {
  const cleanEndpoint = endpoint.replace(/^\/+/, '');
  const url = `${API_BASE_URL}${cleanEndpoint}`;
  const isFormData = typeof FormData !== 'undefined' && options.body instanceof FormData;
  const headers: Record<string, string> = isFormData ? {} : { 'Content-Type': 'application/json' };
  const body = options.body === undefined
    ? undefined
    : isFormData
      ? options.body as FormData
      : JSON.stringify(options.body);

  let response: Response;
  try {
    response = await fetch(url, {
      method: options.method ?? 'GET',
      credentials: 'include',
      headers,
      ...(body === undefined ? {} : { body }),
    });
  } catch {
    throw new ApiError('ارتباط با سرور برقرار نشد. اتصال اینترنت را بررسی کنید.');
  }

  let result: ApiEnvelope<T>;
  try {
    result = await response.json() as ApiEnvelope<T>;
  } catch {
    throw new ApiError('پاسخ سرور قابل خواندن نیست.', undefined, response.status);
  }

  if (!response.ok || result.ok === false) {
    const errorResult = result as { ok: false; error?: string; code?: ApiErrorCode };
    throw new ApiError(errorResult.error || `خطای سرور (${response.status})`, errorResult.code, response.status);
  }

  return result as T;
}


export type AppNotification = {
  id: number | string;
  title?: string;
  message?: string;
  body?: string;
  content?: string;
  created_at?: string;
  is_read?: boolean | number | string;
  type?: string;
  from_name?: string;
  sender_name?: string;
};

export type NotificationsResult =
  | AppNotification[]
  | { notifications?: AppNotification[]; data?: AppNotification[]; items?: AppNotification[]; messages?: AppNotification[] };

export const api = {
  me: () => apiRequest<{ user: import('../store/authStore').User | null }>('me.php'),
  login: (username: string, password: string) => apiRequest<{ user: import('../store/authStore').User }>('login.php', {
    method: 'POST',
    body: { username, password },
  }),
  // Best-effort: ends the PHP session so the cookie can't restore the user on the next launch.
  logout: () => apiRequest<{ message?: string }>('logout.php', { method: 'POST', body: {} }),
  register: (payload: RegistrationPayload) => apiRequest<{ message?: string; user?: import('../store/authStore').User }>('register.php', {
    method: 'POST',
    body: { ...payload, is_broker: payload.is_broker ?? (payload.role === 'broker' ? 1 : 0) },
  }),
  verifyOtp: (payload: RegistrationPayload, otp: string) => apiRequest<{ user: import('../store/authStore').User }>('register.php', {
    method: 'POST',
    body: { ...payload, is_broker: payload.is_broker ?? (payload.role === 'broker' ? 1 : 0), otp },
  }),
  getOpenRequests: () => apiRequest<OpenRequestsResult>('get_requests.php?type=open'),
  getRequest: (id: number | string) => apiRequest<RequestDetailResult>(`get_request.php?id=${encodeURIComponent(String(id))}`),
  makeOffer: (payload: { request_id: string | number; price: string; delivery: string; description: string }) => apiRequest<{ offer?: RequestOffer; message?: string }>('make_offer.php', {
    method: 'POST',
    body: payload,
  }),
  toggleOfferPermission: (payload: { offer_id: string | number; type: 'chat' | 'phone' }) => apiRequest<{ allow_chat?: boolean | number | string; allow_phone?: boolean | number | string; message?: string }>('toggle_offer_permission.php', {
    method: 'POST',
    body: payload,
  }),
  acceptOffer: (offer_id: string | number) => apiRequest<{ message?: string; success?: boolean }>('accept_offer.php', {
    method: 'POST',
    body: { offer_id },
  }),
  getChats: () => apiRequest<ChatsResult>('get_my_chats.php'),
  /** اعلان‌های ادمین / پشتیبانی — چند نام رایج endpoint پشتیبانی می‌شود. */
  getNotifications: async () => {
    const candidates = ['get_notifications.php', 'notifications.php', 'get_my_notifications.php', 'admin_messages.php'];
    let lastError: unknown;
    for (const endpoint of candidates) {
      try {
        return await apiRequest<NotificationsResult>(endpoint);
      } catch (error) {
        lastError = error;
        if (error instanceof ApiError && error.code === 'auth') throw error;
        // 404 / missing endpoint → try next
      }
    }
    // No dedicated endpoint; return empty list so UI can still show admin chat threads.
    if (lastError) return [] as NotificationsResult;
    return [] as NotificationsResult;
  },
  getMessages: (requestId: string | number, peerId?: string | number) => apiRequest<MessagesResult>(
    `get_messages.php?request_id=${encodeURIComponent(String(requestId))}${peerId === undefined ? '' : `&peer_id=${encodeURIComponent(String(peerId))}`}`,
  ),
  sendMessage: (payload: { request_id: string | number; receiver_id?: string | number; message: string; file_name?: string; file_url?: string; file_type?: string }) => apiRequest<SendMessageResult>('send_message.php', {
    method: 'POST',
    body: payload,
  }),
  uploadChatFile: (formData: FormData) => apiRequest<ChatFileUploadResult>('upload_chat_file.php', {
    method: 'POST',
    body: formData,
  }),
  markRead: (payload: { request_id: string | number; peer_id: string | number }) => apiRequest<{ success?: boolean; message?: string }>('mark_read.php', {
    method: 'POST',
    body: payload,
  }),
  markNotificationRead: async (id: number | string) => {
    const candidates = ['mark_notification_read.php', 'read_notification.php', 'notification_read.php'];
    for (const endpoint of candidates) {
      try {
        return await apiRequest<{ success?: boolean; message?: string }>(endpoint, { method: 'POST', body: { id, notification_id: id } });
      } catch (error) {
        if (error instanceof ApiError && error.code === 'auth') throw error;
      }
    }
    return { success: true };
  },
  markAllNotificationsRead: async () => {
    const candidates = ['mark_all_notifications_read.php', 'read_all_notifications.php', 'notifications_read_all.php'];
    for (const endpoint of candidates) {
      try {
        return await apiRequest<{ success?: boolean; message?: string }>(endpoint, { method: 'POST', body: {} });
      } catch (error) {
        if (error instanceof ApiError && error.code === 'auth') throw error;
      }
    }
    return { success: true };
  },
  getMyRequests: () => apiRequest<MyRequestsResult>('get_requests.php?type=mine'),
  getMyOffers: () => apiRequest<MyOffersResult>('get_my_offers.php'),
  postRequest: (payload: FormData) => apiRequest<{ request?: MyRequestItem; message?: string; success?: boolean }>('post_request.php', {
    method: 'POST',
    body: payload,
  }),
  updateRequest: (payload: FormData) => apiRequest<{ request?: MyRequestItem; message?: string; success?: boolean }>('update_request.php', {
    method: 'POST',
    body: payload,
  }),
  deleteRequest: (id: number | string) => apiRequest<{ success?: boolean; message?: string }>('delete_request.php', {
    method: 'POST',
    body: { request_id: id, id },
  }),
  uploadVerificationFiles: (formData: FormData) => apiRequest<{ files?: Array<{ url?: string; name?: string }>; data?: { files?: Array<{ url?: string; name?: string }> }; message?: string }>('upload_verification.php', {
    method: 'POST',
    body: formData,
  }),
  // The extra fields (fullName, companyNationalId, documentTypes, levels) are additive; PHP ignores keys it doesn't read.
  submitKyc: (payload: { companyName: string; nationalId: string; landline: string; address: string; documents: string[]; fullName?: string; companyNationalId?: string; documentTypes?: string[]; levels?: string[] }) => apiRequest<{ message?: string; success?: boolean; status?: string; user?: import('../store/authStore').User; data?: { user?: import('../store/authStore').User; status?: string; message?: string } }>('update_verification.php', {
    method: 'POST',
    body: payload,
  }),
  updateProfile: (payload: { name: string }) => apiRequest<{ name?: string; user?: import('../store/authStore').User; message?: string }>('update_profile.php', {
    method: 'POST',
    body: payload,
  }),
  uploadAvatar: (formData: FormData) => apiRequest<{ avatar_url?: string; user?: import('../store/authStore').User; success?: boolean; message?: string }>('upload_avatar.php', {
    method: 'POST',
    body: formData,
  }),
};
