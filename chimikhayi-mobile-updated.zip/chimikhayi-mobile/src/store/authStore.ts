import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ApiError, api, type RegistrationPayload } from '../api/api';

const LOGGED_OUT_KEY = 'chimikhayi.session.loggedOut';

export type UserRole = 'buyer' | 'supplier' | 'broker';
export type User = {
  id: number | string;
  name: string;
  mobile: string;
  role: UserRole;
  is_broker?: number | boolean | string;
  avatar?: string | null;
  avatar_url?: string | null;
  company_name?: string;
  national_id?: string;
  landline?: string;
  address?: string;
  level?: string;
  trust_score?: number | string;
  is_verified?: boolean | number | string;
  verified?: boolean | number | string;
  offers_count?: number | string;
};

type AuthState = {
  user: User | null;
  initialized: boolean;
  busy: boolean;
  pendingRegistration: RegistrationPayload | null;
  initialize: () => Promise<void>;
  login: (mobile: string, password: string) => Promise<void>;
  register: (data: RegistrationPayload) => Promise<void>;
  verifyOtp: (otp: string) => Promise<void>;
  clearPendingRegistration: () => void;
  updateUser: (patch: Partial<User>) => void;
  logout: () => void;
};

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  initialized: false,
  busy: false,
  pendingRegistration: null,
  initialize: async () => {
    try {
      // If the user logged out here, don't silently restore a server session that may have
      // outlived the logout (e.g. the cookie is still valid because logout.php is missing).
      if (await AsyncStorage.getItem(LOGGED_OUT_KEY) === '1') {
        set({ user: null, initialized: true });
        return;
      }
    } catch {
      // Storage unavailable: fall through to the normal session check.
    }
    try {
      const result = await api.me();
      set({ user: result.user ?? null, initialized: true });
    } catch (error) {
      if (!(error instanceof ApiError) || error.code !== 'auth') {
        // Offline or an unavailable API should not trap the user on a loading screen.
      }
      set({ user: null, initialized: true });
    }
  },
  login: async (mobile, password) => {
    set({ busy: true });
    try {
      const result = await api.login(mobile, password);
      void AsyncStorage.removeItem(LOGGED_OUT_KEY).catch(() => undefined);
      set({ user: result.user, busy: false });
    } catch (error) {
      set({ busy: false });
      throw error;
    }
  },
  register: async (data) => {
    set({ busy: true });
    try {
      const payload = { ...data, is_broker: data.is_broker ?? (data.role === 'broker' ? 1 : 0) };
      await api.register(payload);
      set({ pendingRegistration: payload, busy: false });
    } catch (error) {
      set({ busy: false });
      throw error;
    }
  },
  verifyOtp: async (otp) => {
    const payload = get().pendingRegistration;
    if (!payload) throw new Error('اطلاعات ثبت‌نام پیدا نشد؛ لطفاً دوباره ثبت‌نام کنید.');
    set({ busy: true });
    try {
      const result = await api.verifyOtp(payload, otp);
      void AsyncStorage.removeItem(LOGGED_OUT_KEY).catch(() => undefined);
      set({ user: result.user, pendingRegistration: null, busy: false });
    } catch (error) {
      set({ busy: false });
      throw error;
    }
  },
  clearPendingRegistration: () => set({ pendingRegistration: null }),
  updateUser: (patch) => set((state) => {
    if (!state.user) return state;
    const next = { ...state.user, ...patch };
    const sameKeys = Object.keys(state.user).length === Object.keys(next).length;
    const unchanged = sameKeys && Object.keys(next).every((key) => state.user?.[key as keyof User] === next[key as keyof User]);
    return unchanged ? state : { user: next };
  }),
  logout: () => {
    // Clear local state first so the UI leaves the signed-in area immediately,
    // then ask the server to end the session (failures must not block logout).
    set({ user: null, pendingRegistration: null });
    void AsyncStorage.setItem(LOGGED_OUT_KEY, '1').catch(() => undefined);
    void api.logout().catch(() => undefined);
  },
}));
