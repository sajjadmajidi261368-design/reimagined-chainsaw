import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { HomeScreen } from '../screens/HomeScreen';
import { RequestDetailScreen } from '../screens/RequestDetailScreen';
import { MakeOfferScreen } from '../screens/MakeOfferScreen';
import { OfferDetailScreen } from '../screens/OfferDetailScreen';
import type { RequestOffer } from '../api/api';

export type HomeStackParamList = {
  Home: undefined;
  RequestDetail: { requestId: number | string };
  MakeOffer: {
    requestId: number | string;
    buyerId?: number | string;
    buyerName?: string;
    buyerAvatar?: string;
    buyerMobile?: string | null;
    requestTitle?: string;
    allowChat?: boolean;
    allowPhone?: boolean;
  };
  OfferDetail: { offerId: number | string; requestId: number | string; offer: RequestOffer };
};

const Stack = createNativeStackNavigator<HomeStackParamList>();

export function HomeStackNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false, animation: 'slide_from_left', contentStyle: { backgroundColor: '#FAFAF9' } }}>
      <Stack.Screen name="Home" component={HomeScreen} />
      <Stack.Screen name="RequestDetail" component={RequestDetailScreen} />
      <Stack.Screen name="MakeOffer" component={MakeOfferScreen} />
      <Stack.Screen name="OfferDetail" component={OfferDetailScreen} />
    </Stack.Navigator>
  );
}
