import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { DashboardScreen } from '../screens/DashboardScreen';
import { PostRequestScreen } from '../screens/PostRequestScreen';
import { KycScreen } from '../screens/KycScreen';
import { ProfileEditScreen } from '../screens/ProfileEditScreen';
import { SettingsScreen } from '../screens/SettingsScreen';
import { SentOffersScreen } from '../screens/SentOffersScreen';
import { SentOfferDetailScreen } from '../screens/SentOfferDetailScreen';
import type { MyOfferItem } from '../api/api';

export type DashboardStackParamList = {
  Dashboard: undefined;
  PostRequest: { requestId?: number | string } | undefined;
  Kyc: undefined;
  ProfileEdit: undefined;
  Settings: undefined;
  SentOffers: undefined;
  SentOfferDetail: { offer: MyOfferItem };
};

const Stack = createNativeStackNavigator<DashboardStackParamList>();

export function DashboardStackNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false, animation: 'slide_from_left', contentStyle: { backgroundColor: '#FAFAF9' } }}>
      <Stack.Screen name="Dashboard" component={DashboardScreen} />
      <Stack.Screen name="PostRequest" component={PostRequestScreen} />
      <Stack.Screen name="Kyc" component={KycScreen} />
      <Stack.Screen name="ProfileEdit" component={ProfileEditScreen} />
      <Stack.Screen name="Settings" component={SettingsScreen} />
      <Stack.Screen name="SentOffers" component={SentOffersScreen} />
      <Stack.Screen name="SentOfferDetail" component={SentOfferDetailScreen} />
    </Stack.Navigator>
  );
}
