import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { getFocusedRouteNameFromRoute } from '@react-navigation/native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { HomeStackNavigator } from './HomeStackNavigator';
import { MessagesStackNavigator } from './MessagesStackNavigator';
import { DashboardStackNavigator } from './DashboardStackNavigator';
import { PricingStackNavigator } from './PricingStackNavigator';
import { BlogTab } from '../screens/BlogTab';
import { COLORS } from '../theme/colors';

export type MainTabParamList = {
  HomeTab: undefined;
  Messages: undefined;
  Dashboard: undefined;
  Pricing: undefined;
  Blog: undefined;
};

const Tab = createBottomTabNavigator<MainTabParamList>();
type IconName = keyof typeof MaterialCommunityIcons.glyphMap;
const TAB_META: Record<keyof MainTabParamList, { label: string; icon: IconName; activeIcon: IconName }> = {
  HomeTab: { label: 'خانه', icon: 'home-variant-outline', activeIcon: 'home-variant' },
  Messages: { label: 'پیام‌ها', icon: 'message-text-outline', activeIcon: 'message-text' },
  Dashboard: { label: 'داشبورد', icon: 'view-dashboard-outline', activeIcon: 'view-dashboard' },
  Pricing: { label: 'تعرفه‌ها', icon: 'credit-card-outline', activeIcon: 'credit-card' },
  Blog: { label: 'وبلاگ', icon: 'text-box-outline', activeIcon: 'text-box' },
};

export function MainTabNavigator() {
  return (
    <Tab.Navigator
      initialRouteName="HomeTab"
      screenOptions={({ route }) => {
        const meta = TAB_META[route.name];
        const focusedChild = getFocusedRouteNameFromRoute(route);
        const hideTabBar = route.name === 'Messages' && focusedChild === 'ChatRoom';
        return {
          headerShown: false,
          tabBarLabel: meta.label,
          tabBarActiveTintColor: COLORS.primary,
          tabBarInactiveTintColor: COLORS.muted,
          tabBarLabelStyle: { fontFamily: 'VazirmatnMedium', fontSize: 9, marginTop: 1 },
          tabBarIcon: ({ focused, color, size }) => <MaterialCommunityIcons name={focused ? meta.activeIcon : meta.icon} size={size + (focused ? 1 : 0)} color={color} />,
          tabBarStyle: { height: 65, paddingTop: 7, paddingBottom: 7, backgroundColor: '#FFFFFF', borderTopColor: '#EAE6DC', borderTopWidth: 1, elevation: 12, ...(hideTabBar ? { display: 'none' as const } : {}) },
          tabBarItemStyle: { paddingVertical: 1 },
        };
      }}
    >
      <Tab.Screen name="HomeTab" component={HomeStackNavigator} />
      <Tab.Screen name="Messages" component={MessagesStackNavigator} />
      <Tab.Screen name="Dashboard" component={DashboardStackNavigator} />
      <Tab.Screen name="Pricing" component={PricingStackNavigator} />
      <Tab.Screen name="Blog" component={BlogTab} />
    </Tab.Navigator>
  );
}
