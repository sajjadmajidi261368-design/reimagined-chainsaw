import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { ChatsListScreen } from '../screens/ChatsListScreen';
import { ChatRoomScreen } from '../screens/ChatRoomScreen';

export type MessagesStackParamList = {
  Chats: undefined;
  ChatRoom: {
    requestId: string | number;
    peerId: string | number;
    peerName: string;
    requestTitle: string;
    peerAvatar?: string;
    allowChat: boolean;
    /** won: پیشنهاد برنده (چت همیشه باز) · lost: پیشنهاد دیگری انتخاب شده (چت بسته) */
    outcome?: 'won' | 'lost';
  };
};

const Stack = createNativeStackNavigator<MessagesStackParamList>();

export function MessagesStackNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false, animation: 'slide_from_left', contentStyle: { backgroundColor: '#FAFAF9' } }}>
      <Stack.Screen name="Chats" component={ChatsListScreen} />
      <Stack.Screen name="ChatRoom" component={ChatRoomScreen} />
    </Stack.Navigator>
  );
}
