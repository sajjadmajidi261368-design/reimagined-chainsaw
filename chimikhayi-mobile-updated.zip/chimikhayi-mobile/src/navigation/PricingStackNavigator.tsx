import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { PricingScreen } from '../screens/PricingScreen';
import { PaymentCheckoutScreen } from '../screens/PaymentCheckoutScreen';

export type PricingStackParamList = {
  Pricing: undefined;
  Checkout: { planName: string; price: number };
};

const Stack = createNativeStackNavigator<PricingStackParamList>();

export function PricingStackNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false, animation: 'slide_from_left', contentStyle: { backgroundColor: '#FAFAF9' } }}>
      <Stack.Screen name="Pricing" component={PricingScreen} />
      <Stack.Screen name="Checkout" component={PaymentCheckoutScreen} />
    </Stack.Navigator>
  );
}
