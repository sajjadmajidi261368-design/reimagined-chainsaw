import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import type { TrustSummary } from '../utils/trust';

export function TrustStars({ stars, size = 15, mutedColor = '#6B5B2A' }: { stars: number; size?: number; mutedColor?: string }) {
  return (
    <View style={styles.stars} accessibilityLabel={`${stars} ستاره از ۵`}>
      {[1, 2, 3, 4, 5].map((index) => (
        <MaterialCommunityIcons key={index} name={index <= stars ? 'star' : 'star-outline'} size={size} color={index <= stars ? '#F4C542' : mutedColor} />
      ))}
    </View>
  );
}

type Props = {
  summary: TrustSummary;
  onPress?: () => void;
  actionLabel?: string;
  /** Compact: stars, bar and hint only. Full: also lists every verification step. */
  full?: boolean;
};

export function TrustCard({ summary, onPress, actionLabel, full = false }: Props) {
  const percent = Math.max(0, Math.min(100, summary.score));
  const content = (
    <>
      <View style={styles.top}>
        <View style={styles.topCopy}>
          <Text style={styles.eyebrow}>ستارهٔ اعتماد</Text>
          <Text style={styles.level}>{summary.levelLabel}</Text>
        </View>
        <View style={styles.scoreBox}>
          <Text style={styles.scoreValue}>{summary.score.toLocaleString('fa-IR')}</Text>
          <Text style={styles.scoreUnit}>از ۱۰۰</Text>
        </View>
      </View>
      <View style={styles.starsRow}><TrustStars stars={summary.stars} size={full ? 24 : 20} /></View>
      <View style={styles.track}><View style={[styles.fill, { width: `${percent}%` }]} /></View>
      {summary.nextHint ? <Text style={styles.hint}>{summary.nextHint}</Text> : <Text style={styles.hint}>حساب شما در بالاترین سطح اعتماد قرار دارد.</Text>}
      {full ? (
        <View style={styles.steps}>
          {summary.steps.map((step) => (
            <View key={step.id} style={styles.step}>
              <View style={[styles.stepDot, step.done && styles.stepDotDone]}>
                <MaterialCommunityIcons name={step.done ? 'check' : 'lock-outline'} size={13} color={step.done ? '#1F1706' : '#A8A29E'} />
              </View>
              <View style={styles.stepCopy}>
                <Text style={[styles.stepTitle, !step.done && styles.stepTitleMuted]}>{step.title}</Text>
                <Text style={styles.stepHint}>{step.hint}</Text>
              </View>
              <Text style={[styles.stepPoints, step.done && styles.stepPointsDone]}>+{step.points.toLocaleString('fa-IR')}</Text>
            </View>
          ))}
        </View>
      ) : null}
      {actionLabel && onPress ? (
        <View style={styles.action}><Text style={styles.actionText}>{actionLabel}</Text><MaterialCommunityIcons name="chevron-left" size={17} color="#1F1706" /></View>
      ) : null}
    </>
  );

  if (onPress) {
    return <Pressable onPress={onPress} style={({ pressed }) => [styles.card, pressed && { opacity: 0.9 }]}>{content}</Pressable>;
  }
  return <View style={styles.card}>{content}</View>;
}

const styles = StyleSheet.create({
  stars: { flexDirection: 'row-reverse', alignItems: 'center', gap: 2 },
  card: { padding: 15, borderRadius: 20, backgroundColor: '#211B10', marginBottom: 14 },
  top: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between' },
  topCopy: { flex: 1 },
  eyebrow: { fontFamily: 'VazirmatnMedium', fontSize: 9, color: '#E4C66C', textAlign: 'right' },
  level: { fontFamily: 'VazirmatnBold', fontSize: 15, color: '#FFFDF6', textAlign: 'right', marginTop: 1 },
  scoreBox: { alignItems: 'center', paddingHorizontal: 11, paddingVertical: 5, borderRadius: 13, backgroundColor: 'rgba(212,160,23,0.18)' },
  scoreValue: { fontFamily: 'VazirmatnBold', fontSize: 17, color: '#F4C542' },
  scoreUnit: { fontFamily: 'Vazirmatn', fontSize: 7, color: '#D6D3D1', marginTop: -2 },
  starsRow: { alignItems: 'flex-end', marginTop: 10 },
  track: { height: 7, borderRadius: 4, backgroundColor: 'rgba(255,255,255,0.12)', marginTop: 11, overflow: 'hidden', flexDirection: 'row-reverse' },
  fill: { height: 7, borderRadius: 4, backgroundColor: '#F4C542' },
  hint: { fontFamily: 'Vazirmatn', fontSize: 9, lineHeight: 17, color: '#D6D3D1', textAlign: 'right', marginTop: 9 },
  steps: { marginTop: 13, paddingTop: 11, borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.12)', gap: 9 },
  step: { flexDirection: 'row-reverse', alignItems: 'center', gap: 9 },
  stepDot: { width: 24, height: 24, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.1)', alignItems: 'center', justifyContent: 'center' },
  stepDotDone: { backgroundColor: '#F4C542' },
  stepCopy: { flex: 1 },
  stepTitle: { fontFamily: 'VazirmatnBold', fontSize: 10, color: '#FFFDF6', textAlign: 'right' },
  stepTitleMuted: { color: '#A8A29E' },
  stepHint: { fontFamily: 'Vazirmatn', fontSize: 8, lineHeight: 14, color: '#A8A29E', textAlign: 'right', marginTop: 1 },
  stepPoints: { fontFamily: 'VazirmatnBold', fontSize: 9, color: '#78716C' },
  stepPointsDone: { color: '#F4C542' },
  action: { alignSelf: 'flex-end', flexDirection: 'row-reverse', alignItems: 'center', gap: 3, marginTop: 12, paddingHorizontal: 13, paddingVertical: 7, borderRadius: 11, backgroundColor: '#F4C542' },
  actionText: { fontFamily: 'VazirmatnBold', fontSize: 10, color: '#1F1706' },
});
