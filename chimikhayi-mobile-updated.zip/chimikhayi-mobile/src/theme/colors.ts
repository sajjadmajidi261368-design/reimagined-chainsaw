export const COLORS = {
  primary: '#D4A017',
  primaryDark: '#A16207',
  background: '#FAFAF9',
  surface: '#FFFFFF',
  text: '#1A1A1A',
  muted: '#78716C',
  border: '#E7E5E4',
  success: '#10B981',
  danger: '#EF4444',
  warning: '#F59E0B',
} as const;
